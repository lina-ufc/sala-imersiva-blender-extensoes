"""Peças em disco: as peças das cenas do storyboard cujos pontos ficam num bake de Geometry Nodes em disco, ao lado do .blend
da peça, em dois níveis (o leve, para a janela, e o inteiro, para o render). Quem gera é o pecas_em_disco.py do
nuvens-blender.

Na peça liberada com Library Override, o Blender deixa vazia a pasta do bake do modificador (`bake_directory`), e a peça
chega sem pontos, sem erro. Ao abrir um arquivo e quando uma peça é liberada, o complemento copia a pasta da peça vinculada
para a liberada, relativa ao arquivo aberto (absoluta se ele ainda não foi gravado), e faz o modificador ler de novo.

O painel Peças em disco, na aba Sala, avisa quando falta o arquivo de um nível ou quando uma peça visível chega com 0 pontos
na janela; Renderizar a fita avisa o mesmo no relatório, com os pontos que o render recebeu. A escolha do nível é do próprio
grupo da peça: o leve na janela e o inteiro no render.
"""
from collections.abc import Callable
from pathlib import Path

import bpy

from .arquivos_do_bake import Nivel, niveis_sem_arquivo

_sem_arquivo: list[str] = []
_sem_pontos: list[str] = []


def modificadores_com_bake(objeto: bpy.types.Object) -> list[bpy.types.NodesModifier]:
    """Os modificadores de Geometry Nodes do objeto que leem um bake em disco."""
    return [m for m in objeto.modifiers if m.type == "NODES" and m.bake_target == "DISK" and m.bakes]


def _pasta_da_peca_vinculada(objeto: bpy.types.Object, modificador: bpy.types.NodesModifier) -> str:
    """A pasta do bake que a peça vinculada guarda, relativa ao arquivo aberto, ou vazia se ela não guarda nenhuma."""
    referencia = objeto.override_library.reference
    do_vinculado = referencia.modifiers.get(modificador.name) if referencia is not None else None
    if do_vinculado is None or not do_vinculado.bake_directory:
        return ""
    absoluta = bpy.path.abspath(do_vinculado.bake_directory, library=referencia.library)
    if not bpy.data.filepath:
        return absoluta
    return bpy.path.relpath(absoluta)


def sem_pasta() -> list[tuple[bpy.types.Object, bpy.types.NodesModifier]]:
    """As peças liberadas que leem um bake em disco com a pasta dele vazia."""
    return [(o, m) for o in bpy.data.objects if o.override_library is not None
            for m in modificadores_com_bake(o) if not m.bake_directory]


def _bibliotecas(objetos: list[bpy.types.Object]) -> set[bpy.types.Library]:
    return {o.override_library.reference.library for o in objetos
            if o.override_library is not None and o.override_library.reference is not None}


def recarregar(objetos: list[bpy.types.Object]) -> None:
    """Faz as peças lerem o bake de novo. Mudar a pasta, reatribuir o grupo ou marcar o objeto não basta: o modificador
    guarda que não achou o bake; só recarregar o .blend da peça vinculada o faz ler (a pasta liberada fica)."""
    for biblioteca in _bibliotecas(objetos):
        biblioteca.reload()


def preencher() -> list[str]:
    """Põe a pasta do bake nas peças liberadas que estão sem ela e recarrega as peças preenchidas."""
    preenchidas = []
    for objeto, modificador in sem_pasta():
        pasta = _pasta_da_peca_vinculada(objeto, modificador)
        if not pasta:
            continue
        modificador.bake_directory = pasta
        preenchidas.append(objeto)
    nomes = [o.name for o in preenchidas]
    recarregar(preenchidas)
    return nomes


def niveis_que_faltam(cena: bpy.types.Scene) -> list[str]:
    """Os níveis sem arquivo, nas peças da cena que leem um bake em disco."""
    faltam = []
    for objeto in cena.objects:
        for modificador in modificadores_com_bake(objeto):
            if not modificador.bake_directory:
                faltam.append(f"{objeto.name}: sem a pasta do bake")
                continue
            pasta = Path(bpy.path.abspath(modificador.bake_directory, library=objeto.library))
            niveis = [Nivel(b.node.name if b.node is not None else str(b.bake_id), b.bake_id) for b in modificador.bakes]
            faltam += [f"{objeto.name}: falta o {n.nome} em {pasta / str(n.bake_id)}" for n in niveis_sem_arquivo(pasta, niveis)]
    return faltam


def pontos_por_peca(grafo: bpy.types.Depsgraph) -> dict[str, int]:
    """Os pontos que cada peça visível com bake em disco recebe nesse grafo (o da janela ou o do render)."""
    contagem = {}
    for avaliado in grafo.objects:
        if avaliado.type != "MESH" or not modificadores_com_bake(avaliado.original):
            continue
        geometria = avaliado.evaluated_geometry()
        contagem[avaliado.original.name] = 0 if geometria.pointcloud is None else len(geometria.pointcloud.points)
    return contagem


def contador_do_render(contagem: dict[str, int]) -> Callable[[bpy.types.Scene, bpy.types.Depsgraph], None]:
    """Para `frame_change_post`, que no render recebe o grafo do render: os pontos de cada peça como o render os recebe."""
    @bpy.app.handlers.persistent
    def contar(_cena: bpy.types.Scene, grafo: bpy.types.Depsgraph) -> None:
        if grafo.mode == "RENDER":
            contagem.update(pontos_por_peca(grafo))
    return contar


def _conferir_arquivos() -> None:
    cena = bpy.context.scene
    _sem_arquivo[:] = niveis_que_faltam(cena) if cena is not None else []


def _redesenhar() -> None:
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _preencher_depois(com_desfazer: bool) -> None:
    preenchidas = preencher()
    _conferir_arquivos()
    _redesenhar()
    if not preenchidas:
        return
    print(f"Nuvens do LInA: pasta do bake preenchida em {len(preenchidas)} peças: {', '.join(preenchidas)}")
    if com_desfazer and bpy.context.window_manager.windows:
        with bpy.context.temp_override(window=bpy.context.window_manager.windows[0]):
            bpy.ops.ed.undo_push(message="Carregar peças em disco")


@bpy.app.handlers.persistent
def _ao_abrir(*_argumentos: object) -> None:
    _sem_pontos.clear()
    bpy.app.timers.register(lambda: _preencher_depois(com_desfazer=False), first_interval=0.0)


@bpy.app.handlers.persistent
def _ao_atualizar(_cena: bpy.types.Scene, grafo: bpy.types.Depsgraph) -> None:
    if grafo.mode != "VIEWPORT":
        return
    _sem_pontos[:] = sorted(nome for nome, pontos in pontos_por_peca(grafo).items() if pontos == 0)
    if not grafo.id_type_updated("OBJECT") or not sem_pasta():
        return
    # Mudar dados dentro do handler do depsgraph não é permitido: o preenchimento roda logo depois, fora dele.
    bpy.app.timers.register(lambda: _preencher_depois(com_desfazer=True), first_interval=0.0)


class SALA_OT_carregar_pecas_em_disco(bpy.types.Operator):
    bl_idname = "sala.carregar_pecas_em_disco"
    bl_label = "Carregar peças em disco"
    bl_description = ("Põe a pasta do bake nas peças liberadas que estão sem ela, faz as peças lerem os pontos de novo e "
                      "confere os arquivos dos níveis")
    bl_options = {"UNDO"}   # noqa: RUF012

    def execute(self, _contexto: bpy.types.Context) -> set[str]:
        preenchidas = preencher()
        recarregar([o for o in bpy.context.scene.objects if modificadores_com_bake(o)])
        _conferir_arquivos()
        if _sem_arquivo:
            self.report({"WARNING"}, f"{len(_sem_arquivo)} níveis sem arquivo; veja o painel Peças em disco")
        else:
            self.report({"INFO"}, f"Peças em disco carregadas; pasta preenchida em {len(preenchidas)}")
        return {"FINISHED"}


class SALA_PT_pecas_em_disco(bpy.types.Panel):
    bl_label = "Peças em disco"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Sala"
    bl_order = 2

    @classmethod
    def poll(cls, contexto: bpy.types.Context) -> bool:
        return any(modificadores_com_bake(o) for o in contexto.scene.objects)

    def draw(self, contexto: bpy.types.Context) -> None:
        layout = self.layout
        com_bake = sum(1 for o in contexto.scene.objects if modificadores_com_bake(o))
        if not _sem_arquivo and not _sem_pontos:
            layout.label(text=f"{com_bake} peças em disco, todas com pontos", icon="CHECKMARK")
        coluna = layout.column(align=True)
        for linha in _sem_arquivo:
            coluna.label(text=linha, icon="ERROR")
        for nome in _sem_pontos:
            coluna.label(text=f"{nome}: 0 pontos na janela", icon="ERROR")
        layout.operator(SALA_OT_carregar_pecas_em_disco.bl_idname, icon="FILE_REFRESH")


CLASSES = (SALA_OT_carregar_pecas_em_disco, SALA_PT_pecas_em_disco)
HANDLERS = ((bpy.app.handlers.load_post, _ao_abrir), (bpy.app.handlers.depsgraph_update_post, _ao_atualizar))


def register() -> None:
    for classe in CLASSES:
        bpy.utils.register_class(classe)
    for lista, funcao in HANDLERS:
        lista.append(funcao)


def unregister() -> None:
    for lista, funcao in HANDLERS:
        lista.remove(funcao)
    for classe in reversed(CLASSES):
        bpy.utils.unregister_class(classe)
