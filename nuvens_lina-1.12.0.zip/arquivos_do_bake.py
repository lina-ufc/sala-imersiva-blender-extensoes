"""Os arquivos de um bake de Geometry Nodes em disco. Não depende do Blender, para os testes.

O Blender grava cada nó Bake numa pasta com o número dele (`bake_id`) dentro da pasta do bake do modificador, com os
dados em `meta/` e `blobs/`. Sem nada em `meta/`, o nó não tem o que ler, e a peça chega vazia, sem erro.
"""
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Nivel:
    nome: str      # o nome do nó Bake (o nível leve ou o inteiro)
    bake_id: int


def niveis_sem_arquivo(pasta_do_bake: Path, niveis: list[Nivel]) -> list[Nivel]:
    """Os níveis cujo bake não está na pasta."""
    return [n for n in niveis if not any((pasta_do_bake / str(n.bake_id) / "meta").glob("*"))]
