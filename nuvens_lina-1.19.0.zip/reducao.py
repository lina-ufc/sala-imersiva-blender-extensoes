"""Redução das peças com efeito no Modo leve (desde a 1.19.0; até a 1.18, uma cópia reduzida só da sessão).

A peça com efeito (um modificador ligado na janela além do "Pontos da nuvem", ou qualquer um na peça nativa) fica no Geometry
Nodes, que relê a nuvem inteira a cada quadro. Com o Modo leve ligado, `modo_leve` põe na própria peça, liberada (Library
Override) ou local, um modificador de Geometry Nodes no topo da pilha, antes dos efeitos do artista, ligado só na janela
(`show_render` desligado: o F12, o `render.py` e o *Renderizar a fita* não o veem). Ele entrega uma parte dos pontos da peça,
a da entrada `entrada_da_parte`, e os efeitos do artista, que ficam ligados, trabalham só com ela. Nada novo aparece no
Outliner: nem objeto nem coleção.

Os pontos que ficam são um a cada `total / N`, pela ordem gravada na peça: o nó *Points* cria os N pontos e o *Sample Index*
traz, de cada um, a posição e cada atributo de ponto da peça (a cor, o raio e os outros), então o custo depende de N e não do
tamanho da peça. Os N primeiros pontos não serviriam: na peça em níveis (`niveis.py`) eles só são uma amostra da peça inteira
quando o corte cai no fim de um nível (no meio dele, uns oitavos da caixa ficam cheios e outros vazios), e na peça sem níveis
seguem a ordem da captação. Um a cada `total / N` é uma amostra espalhada nas duas: na peça em níveis, os pontos de cada nó
estão embaralhados. O número de cada ponto na peça inteira vai no atributo `atributo_do_id` (o que a peça já tinha nele ou,
sem ele, o índice), para os efeitos que sorteiam por ponto sortearem como no render.

O grupo de nós é criado aqui, na sessão, um por conjunto de atributos de ponto (o Geometry Nodes não percorre os atributos
sozinho: cada um pede o seu nó), e leva a propriedade `propriedade_do_grupo` com esse conjunto. O modificador sai antes de
salvar e volta depois (`modo_leve`); sem usuário, o grupo não vai para o arquivo. O que um salvamento automático gravar é
tirado ao abrir (`apagar_restos`).
"""
import json

import bpy
import numpy as np

from . import dados, pontos_da_peca

LEVE = dados.modo_leve()
REDUCAO = LEVE.reducao

# Tipo do atributo de ponto na peça -> tipo com que o Geometry Nodes o lê e o amostra. O valor é gravado de volta no tipo da
# peça (a cor em byte é lida em float e gravada em byte).
_LEITURA = {"FLOAT": "FLOAT", "INT": "INT", "INT8": "INT", "BOOLEAN": "BOOLEAN", "FLOAT_VECTOR": "FLOAT_VECTOR",
            "FLOAT2": "FLOAT_VECTOR", "FLOAT_COLOR": "FLOAT_COLOR", "BYTE_COLOR": "FLOAT_COLOR", "QUATERNION": "QUATERNION",
            "FLOAT4X4": "FLOAT4X4"}
_POSICAO = "position"
_TOLERANCIA = 1e-6

_caixas: dict[str, tuple[tuple[str, int], np.ndarray, np.ndarray]] = {}   # pela peça: a caixa dos pontos dela, sem efeito


def caixa(nome: str, objeto: bpy.types.Object) -> tuple[np.ndarray, np.ndarray]:
    """A caixa dos pontos da própria peça (coordenadas dela), sem os efeitos: a distância ao olho que escolhe o degrau não
    muda com a animação do efeito. Lida uma vez por nuvem."""
    chave = pontos_da_peca.chave(objeto)
    guardada = _caixas.get(nome)
    if guardada is not None and guardada[0] == chave:
        return guardada[1], guardada[2]
    if chave[1] == 0:
        raise ValueError(f"{nome}: a peça não tem pontos")
    posicao = pontos_da_peca.posicoes(objeto.data)
    _caixas[nome] = (chave, posicao.min(0), posicao.max(0))
    return _caixas[nome][1], _caixas[nome][2]


def esquecer_as_caixas() -> None:
    _caixas.clear()


def e_da_reducao(modificador: bpy.types.Modifier) -> bool:
    return modificador.type == "NODES" and modificador.node_group is not None \
        and modificador.node_group.get(REDUCAO.propriedade_do_grupo) is not None


def _da_reducao(objeto: bpy.types.Object) -> list[bpy.types.NodesModifier]:
    return [m for m in objeto.modifiers if e_da_reducao(m)]


def tem(objeto: bpy.types.Object) -> bool:
    return any(e_da_reducao(m) for m in objeto.modifiers)


def _atributos(objeto: bpy.types.Object) -> tuple[tuple[str, str], ...]:
    """Os atributos de ponto que a redução leva (além da posição e do id, que ela trata à parte), em ordem de nome."""
    atributos = tuple(sorted((n, t) for n, t in pontos_da_peca.atributos(objeto.data) if n not in (_POSICAO, REDUCAO.atributo_do_id)))
    sem_tipo = [f"{n} ({t})" for n, t in atributos if t not in _LEITURA]
    if sem_tipo:
        raise ValueError(f"atributo de ponto que a redução não sabe levar: {', '.join(sem_tipo)}")
    return atributos


def _no(grupo: bpy.types.GeometryNodeTree, tipo: str, **campos: object) -> bpy.types.Node:
    no = grupo.nodes.new(tipo)
    for campo, valor in campos.items():
        setattr(no, campo, valor)
    return no


def _conta(grupo: bpy.types.GeometryNodeTree, operacao: str, a: bpy.types.NodeSocket,
           b: bpy.types.NodeSocket | None = None) -> bpy.types.NodeSocket:
    no = _no(grupo, "ShaderNodeMath", operation=operacao)
    grupo.links.new(a, no.inputs[0])
    if b is not None:
        grupo.links.new(b, no.inputs[1])
    return no.outputs[0]


def _amostra(grupo: bpy.types.GeometryNodeTree, geometria: bpy.types.NodeSocket, tipo: str, valor: bpy.types.NodeSocket,
             indice: bpy.types.NodeSocket) -> bpy.types.NodeSocket:
    no = _no(grupo, "GeometryNodeSampleIndex", data_type=tipo, domain="POINT", clamp=True)
    grupo.links.new(geometria, no.inputs["Geometry"])
    grupo.links.new(valor, no.inputs["Value"])
    grupo.links.new(indice, no.inputs["Index"])
    return no.outputs["Value"]


def _guardar(grupo: bpy.types.GeometryNodeTree, geometria: bpy.types.NodeSocket, nome: str, tipo: str,
             valor: bpy.types.NodeSocket) -> bpy.types.NodeSocket:
    no = _no(grupo, "GeometryNodeStoreNamedAttribute", data_type=tipo, domain="POINT")
    no.inputs["Name"].default_value = nome
    grupo.links.new(geometria, no.inputs["Geometry"])
    grupo.links.new(valor, no.inputs["Value"])
    return no.outputs["Geometry"]


def _montar(grupo: bpy.types.GeometryNodeTree, atributos: tuple[tuple[str, str], ...]) -> None:
    entrada, saida = _no(grupo, "NodeGroupInput"), _no(grupo, "NodeGroupOutput")
    peca, parte = entrada.outputs[0], entrada.outputs[1]
    na_nuvem = _no(grupo, "GeometryNodeAttributeDomainSize", component="POINTCLOUD")
    na_malha = _no(grupo, "GeometryNodeAttributeDomainSize", component="MESH")
    grupo.links.new(peca, na_nuvem.inputs[0])
    grupo.links.new(peca, na_malha.inputs[0])
    total = _conta(grupo, "ADD", na_nuvem.outputs["Point Count"], na_malha.outputs["Point Count"])
    quantos = _conta(grupo, "MAXIMUM", _conta(grupo, "ROUND", _conta(grupo, "MULTIPLY", total, parte)))
    quantos.node.inputs[1].default_value = 1.0
    passo = _conta(grupo, "DIVIDE", total, quantos)
    indice = _conta(grupo, "FLOOR", _conta(grupo, "MULTIPLY", _no(grupo, "GeometryNodeInputIndex").outputs[0], passo))

    pontos = _no(grupo, "GeometryNodePoints")
    grupo.links.new(quantos, pontos.inputs["Count"])
    grupo.links.new(_amostra(grupo, peca, "FLOAT_VECTOR", _no(grupo, "GeometryNodeInputPosition").outputs[0], indice),
                    pontos.inputs["Position"])
    # A peça antiga (malha só de vértices) segue malha, para o "Pontos da nuvem" dela.
    vertices = _no(grupo, "GeometryNodePointsToVertices")
    grupo.links.new(pontos.outputs[0], vertices.inputs["Points"])
    e_malha = _no(grupo, "FunctionNodeCompare", data_type="INT", operation="GREATER_THAN")
    grupo.links.new(na_malha.outputs["Point Count"], e_malha.inputs["A"])
    escolha = _no(grupo, "GeometryNodeSwitch", input_type="GEOMETRY")
    grupo.links.new(e_malha.outputs[0], escolha.inputs["Switch"])
    grupo.links.new(pontos.outputs[0], escolha.inputs["False"])
    grupo.links.new(vertices.outputs[0], escolha.inputs["True"])
    geometria = escolha.outputs[0]

    for nome, tipo in atributos:
        lido = _no(grupo, "GeometryNodeInputNamedAttribute", data_type=_LEITURA[tipo])
        lido.inputs["Name"].default_value = nome
        geometria = _guardar(grupo, geometria, nome, tipo, _amostra(grupo, peca, _LEITURA[tipo], lido.outputs["Attribute"], indice))
    # O nó ID dá o `id` da peça ou, sem ele, o índice: o número de cada ponto na peça inteira.
    geometria = _guardar(grupo, geometria, REDUCAO.atributo_do_id, "INT",
                         _amostra(grupo, peca, "INT", _no(grupo, "GeometryNodeInputID").outputs[0], indice))
    # Os pontos novos não têm material: o da peça vem pela entrada, que `por` preenche.
    material = _no(grupo, "GeometryNodeSetMaterial")
    grupo.links.new(geometria, material.inputs["Geometry"])
    grupo.links.new(entrada.outputs[2], material.inputs["Material"])
    grupo.links.new(material.outputs[0], saida.inputs[0])


def _grupo(atributos: tuple[tuple[str, str], ...]) -> bpy.types.GeometryNodeTree:
    """O grupo de redução para este conjunto de atributos: o que já existe na sessão ou um novo."""
    assinatura = json.dumps(atributos)
    for grupo in bpy.data.node_groups:
        if grupo.library is None and grupo.get(REDUCAO.propriedade_do_grupo) == assinatura:
            return grupo
    grupo = bpy.data.node_groups.new(REDUCAO.nome_do_grupo.format(atributos=", ".join(n for n, _ in atributos)), "GeometryNodeTree")
    grupo[REDUCAO.propriedade_do_grupo] = assinatura
    grupo.interface.new_socket("Geometry", in_out="INPUT", socket_type="NodeSocketGeometry")
    parte = grupo.interface.new_socket(REDUCAO.entrada_da_parte, in_out="INPUT", socket_type="NodeSocketFloat")
    parte.min_value, parte.max_value, parte.default_value = 0.0, 1.0, 1.0
    grupo.interface.new_socket(REDUCAO.entrada_do_material, in_out="INPUT", socket_type="NodeSocketMaterial")
    grupo.interface.new_socket("Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")
    _montar(grupo, atributos)
    return grupo


def _topo(objeto: bpy.types.Object) -> int:
    """O topo da pilha para a redução: na liberada, depois dos modificadores que vêm da biblioteca (o Library Override guarda
    o modificador local pelo que vem antes dele); na local, o primeiro."""
    return sum(1 for m in objeto.modifiers if m.is_override_data and not e_da_reducao(m))


def por(objeto: bpy.types.Object, parte: float) -> None:
    """Deixa na peça exatamente um modificador de redução, no topo da pilha, com a `parte` dos pontos. Só escreve o que
    está diferente, porque cada escrita faz o Blender avaliar a peça de novo e chamar a classificação."""
    grupo = _grupo(_atributos(objeto))
    nossos = _da_reducao(objeto)
    for sobra in nossos[1:]:
        objeto.modifiers.remove(sobra)   # um desfazer pode trazer dois
    modificador = nossos[0] if nossos else objeto.modifiers.new(REDUCAO.nome_do_modificador, "NODES")
    if modificador.node_group != grupo:
        modificador.node_group = grupo
    if modificador.show_render or not modificador.show_viewport:
        modificador.show_render, modificador.show_viewport = False, True
    if modificador.show_in_editmode:
        modificador.show_in_editmode = False
    entrada = getattr(modificador.properties.inputs, _identificador(grupo, REDUCAO.entrada_da_parte))
    if abs(entrada.value - parte) > _TOLERANCIA:   # a entrada guarda float de 32 bits
        entrada.value = parte
    entrada = getattr(modificador.properties.inputs, _identificador(grupo, REDUCAO.entrada_do_material))
    material = _material(objeto)
    if entrada.value != material:
        entrada.value = material
    onde, topo = list(objeto.modifiers).index(modificador), _topo(objeto)
    if onde != topo:
        objeto.modifiers.move(onde, topo)


def _identificador(grupo: bpy.types.GeometryNodeTree, nome: str) -> str:
    return next(i.identifier for i in grupo.interface.items_tree if i.item_type == "SOCKET" and i.in_out == "INPUT" and i.name == nome)


def _material(objeto: bpy.types.Object) -> bpy.types.Material | None:
    """O material da peça, que os pontos novos levam. As peças têm um só; com mais, a redução não saberia qual vai em cada
    ponto."""
    materiais = objeto.data.materials
    if len(materiais) > 1:
        raise ValueError(f"a peça tem {len(materiais)} materiais; a redução só leva um")
    return materiais[0] if materiais else None


def tirar(objeto: bpy.types.Object) -> None:
    for modificador in _da_reducao(objeto):
        objeto.modifiers.remove(modificador)


def tirar_de_todas() -> None:
    """Tira a redução de todas as peças e apaga os grupos dela (antes de salvar, ao desligar e ao abrir um arquivo)."""
    for objeto in bpy.data.objects:
        if objeto.library is None:
            tirar(objeto)
    for grupo in [g for g in bpy.data.node_groups if g.library is None and g.get(REDUCAO.propriedade_do_grupo) is not None]:
        bpy.data.node_groups.remove(grupo)


def apagar_restos() -> None:
    """Ao abrir um arquivo: tira a redução que um salvamento automático tenha gravado e apaga a cópia reduzida, a coleção
    dela e os dados reduzidos que um salvamento automático da 1.17 ou da 1.18 tenha gravado."""
    tirar_de_todas()
    _caixas.clear()
    restos = LEVE.restos_da_copia
    for copia in [o for o in bpy.data.objects if o.get(restos.propriedade_da_copia) is not None]:
        bpy.data.objects.remove(copia)
    for colecao in [c for c in bpy.data.collections if c.get(restos.propriedade_da_copia) is not None]:
        bpy.data.collections.remove(colecao)
    for colecao_de_dados in (bpy.data.meshes, bpy.data.pointclouds):
        for reduzida in [d for d in colecao_de_dados if d.get(restos.propriedade_da_amostra) is not None and d.users == 0]:
            colecao_de_dados.remove(reduzida)
