"""Seleção por clique nas peças desenhadas pela placa no Modo leve.

No clique, desenha numa textura fora da tela, do tamanho da região, `desenho_na_placa.desenhar_para_selecao` e lê os
pixels num quadrado de lado 2 × `raio_da_selecao_px` + 1 (`modo_leve` no `dados.json`) em volta do mouse: fica o número
diferente de 0 mais perto do centro (um clique pode cair num vão entre pontos; risco 6). O número (RGBA de 8 bits, byte
menos significativo no vermelho) menos 1 é a posição da peça em `desenho_na_placa.pecas_na_placa()`; sem nenhum número, é
clique fora das peças, que segue para a seleção normal do Blender.

O operador `sala.selecionar_na_placa` fica no clique esquerdo da 3D View (e com Shift, para somar), só com o Modo leve
ligado e no modo objeto:
- Peça liberada (sem biblioteca, ou com Library Override): seleciona e torna ativa; Shift soma, ou tira se já era a ativa.
- Peça só vinculada: não se seleciona sem o olho aberto, e a placa a desenha. Então o olho dela abre, ela vai ao Geometry
  Nodes (entra em `devolvidas_ao_geometry_nodes()`, que o `modo_leve` respeita: não a desenha pela placa nem a toma por
  mexida à mão) e fica selecionada, para o artista liberá-la (Library Override > Make). Ao perder a seleção, o `modo_leve`
  a devolve à placa e fecha o olho dela: quem fecha o olho é só ele; aqui só se abre.
- Fora das peças: o clique segue para a seleção normal do Blender (PASS_THROUGH).

`peca_sob_o_mouse` numera pelo mesmo `desenho_na_placa.pecas_na_placa()` que o desenho de números usa, na mesma chamada.
"""
import time
from collections.abc import Callable

import bpy
import gpu
import numpy as np

from . import dados, desenho_na_placa, vizinhanca
from .desenho_na_placa import Vista

LEVE = dados.modo_leve()

# As peças só vinculadas que a seleção devolveu ao Geometry Nodes, por `name_full`, e quanto durou o último clique (ms).
_devolvidas: set[str] = set()
ultimo_clique_ms: float = 0.0
# Quem o clique avisa depois de mudar a seleção (o `modo_leve` põe aqui o `reclassificar`); sem ele, a classificação espera o
# próximo aviso do Blender.
ao_mudar_a_selecao: Callable[[], None] | None = None


def modo_leve_ligado() -> bool:
    return bool(getattr(bpy.context.window_manager, desenho_na_placa.PROPRIEDADE_DO_BOTAO, False))


def devolvidas_ao_geometry_nodes() -> frozenset[str]:
    """As peças só vinculadas selecionadas agora: o desenho pela placa não as desenha, o Geometry Nodes sim."""
    return frozenset(_devolvidas)


def _vista_da_regiao(contexto: bpy.types.Context) -> Vista:
    região, rv3d = contexto.region, contexto.region_data
    planos = tuple(tuple(float(c) for c in plano) for plano in rv3d.clip_planes) if rv3d.use_clip_planes else ()
    return Vista(rv3d.view_matrix.copy(), rv3d.window_matrix.copy(), região.width, região.height, planos)


def peca_sob_o_mouse(contexto: bpy.types.Context, x_px: int, y_px: int) -> str | None:
    """O nome completo da peça desenhada pela placa sob o ponto (x, y) da região, ou None."""
    vista = _vista_da_regiao(contexto)
    janela = vizinhanca.janela_de_leitura(x_px, y_px, LEVE.raio_da_selecao_px, vista.largura_px, vista.altura_px)
    if janela is None:
        return None
    x0, y0, largura, altura = janela
    fora = gpu.types.GPUOffScreen(vista.largura_px, vista.altura_px, format="RGBA8")   # ele segura as texturas
    try:
        with fora.bind():
            quadro = gpu.state.active_framebuffer_get()
            quadro.clear(color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
            gpu.state.depth_test_set("LESS_EQUAL")
            gpu.state.depth_mask_set(True)
            gpu.state.blend_set("NONE")
            gpu.state.program_point_size_set(True)
            try:
                desenho_na_placa.desenhar_para_selecao(vista)
            finally:
                gpu.state.depth_test_set("NONE")
                gpu.state.depth_mask_set(False)
                gpu.state.program_point_size_set(False)
            lido = quadro.read_color(x0, y0, largura, altura, 4, 0, "UBYTE")
            lido.dimensions = largura * altura * 4
            bloco = np.array(lido, dtype=np.uint8).reshape(altura, largura, 4)
    finally:
        fora.free()
    numero = vizinhanca.numero_mais_perto(bloco, x_px - x0, y_px - y0)
    if numero == 0:
        return None
    pecas = desenho_na_placa.pecas_na_placa()
    if numero > len(pecas):
        raise ValueError(f"a seleção leu o número {numero}, mas o Modo leve desenha só {len(pecas)} peças")
    return pecas[numero - 1]


def _objeto(nome_completo: str) -> bpy.types.Object | None:
    return next((o for o in bpy.data.objects if o.name_full == nome_completo), None)


def devolver_todas() -> None:
    """Esquece as peças devolvidas ao Geometry Nodes (ao desligar o modo ou abrir outro arquivo). O olho delas fica como está:
    quem o fecha, se a peça voltar à placa, é o `modo_leve`."""
    _devolvidas.clear()


def conferir_devolvidas() -> None:
    """Tira das devolvidas as peças que não estão mais selecionadas (ou que sumiram): elas voltam à placa."""
    for nome in [n for n in _devolvidas if (o := _objeto(n)) is None or not o.select_get()]:
        _devolvidas.discard(nome)


def _selecionar(contexto: bpy.types.Context, objeto: bpy.types.Object, somar: bool) -> None:
    camada = contexto.view_layer
    if objeto.library is not None:
        objeto.hide_set(False)
        _devolvidas.add(objeto.name_full)
    if somar and objeto.select_get() and camada.objects.active is objeto:
        objeto.select_set(False)
        return
    if not somar:
        for outro in list(contexto.selected_objects):
            outro.select_set(False)
    objeto.select_set(True)
    camada.objects.active = objeto


class SALA_OT_selecionar_na_placa(bpy.types.Operator):
    bl_idname = "sala.selecionar_na_placa"
    bl_label = "Selecionar peça desenhada pela placa"
    bl_options = {"UNDO"}   # noqa: RUF012

    somar: bpy.props.BoolProperty(name="Somar", default=False)   # type: ignore[valid-type]

    @classmethod
    def poll(cls, contexto: bpy.types.Context) -> bool:
        return (modo_leve_ligado() and contexto.area is not None and contexto.area.type == "VIEW_3D"
                and contexto.region_data is not None and contexto.mode == "OBJECT")

    def invoke(self, contexto: bpy.types.Context, evento: bpy.types.Event) -> set[str]:
        global ultimo_clique_ms
        inicio = time.perf_counter()
        nome = peca_sob_o_mouse(contexto, evento.mouse_region_x, evento.mouse_region_y)
        ultimo_clique_ms = (time.perf_counter() - inicio) * 1000
        if nome is None:
            return {"PASS_THROUGH"}
        objeto = _objeto(nome)
        if objeto is None:
            raise ValueError(f"a peça {nome!r} sob o mouse não existe mais no arquivo")
        _selecionar(contexto, objeto, self.somar)
        if ao_mudar_a_selecao is not None:
            ao_mudar_a_selecao()
        return {"FINISHED"}


_atalhos: list[tuple[bpy.types.KeyMap, bpy.types.KeyMapItem]] = []


def register() -> None:
    bpy.utils.register_class(SALA_OT_selecionar_na_placa)
    teclado = bpy.context.window_manager.keyconfigs.addon
    if teclado is None:   # Blender sem janela
        return
    mapa = teclado.keymaps.new(name="3D View", space_type="VIEW_3D")
    for somar in (False, True):
        item = mapa.keymap_items.new(SALA_OT_selecionar_na_placa.bl_idname, "LEFTMOUSE", "PRESS", shift=somar)
        item.properties.somar = somar
        _atalhos.append((mapa, item))


def unregister() -> None:
    for mapa, item in _atalhos:
        mapa.keymap_items.remove(item)
    _atalhos.clear()
    bpy.utils.unregister_class(SALA_OT_selecionar_na_placa)
