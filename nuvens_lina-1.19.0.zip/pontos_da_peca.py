"""Os pontos de uma peça, nas duas formas que o Modo leve aceita (desde a 1.18.0): a antiga, malha só de vértices com o
modificador "Pontos da nuvem", e a nativa, objeto Point Cloud com o atributo da cor (`tipo_da_peca_nativa` e `atributo_da_cor`
no dados.json), sem modificador próprio. Ler um atributo de ponto (posição, cor, raio e os outros) passa só por `ler`, para
a placa (`desenho_na_placa`) e a redução (`reducao`) tratarem as duas formas igual."""
import bpy
import numpy as np

from . import placa_dados

PLACA = placa_dados.placa()
Dados = bpy.types.Mesh | bpy.types.PointCloud

# Tipo de atributo: (campo do foreach, números por ponto, tipo no numpy). A cor em byte vai por `color_srgb`, que lê o byte
# como está.
TIPOS: dict[str, tuple[str, int, type]] = {
    "FLOAT": ("value", 1, np.float32), "INT": ("value", 1, np.int32), "INT8": ("value", 1, np.int32),
    "BOOLEAN": ("value", 1, np.bool_), "FLOAT_VECTOR": ("vector", 3, np.float32), "FLOAT2": ("vector", 2, np.float32),
    "FLOAT_COLOR": ("color", 4, np.float32), "BYTE_COLOR": ("color_srgb", 4, np.float32),
    "INT32_2D": ("value", 2, np.int32), "QUATERNION": ("value", 4, np.float32)}


def e_nativa(objeto: bpy.types.Object) -> bool:
    return objeto.type == PLACA.tipo_da_peca_nativa and PLACA.atributo_da_cor in objeto.data.attributes


def modificador_dos_pontos(objeto: bpy.types.Object) -> bpy.types.NodesModifier | None:
    """O "Pontos da nuvem" da peça antiga; None na nativa e em qualquer objeto que não seja malha."""
    if objeto.type != "MESH":
        return None
    for modificador in objeto.modifiers:
        if modificador.type == "NODES" and modificador.node_group is not None \
                and modificador.node_group.name.startswith(PLACA.nome_do_grupo):
            return modificador
    return None


def e_peca(objeto: bpy.types.Object) -> bool:
    """Se o objeto é uma peça (malha antiga com modificador ou nuvem nativa)."""
    return modificador_dos_pontos(objeto) is not None or e_nativa(objeto)


def quantos(dados: Dados) -> int:
    """Os pontos da peça: os vértices da malha ou os pontos da nuvem."""
    return len(dados.points) if isinstance(dados, bpy.types.PointCloud) else len(dados.vertices)


def chave(objeto: bpy.types.Object) -> tuple[str, int]:
    """Os dados da peça (name_full) e quantos pontos eles têm: outra chave quer dizer outra nuvem."""
    return objeto.data.name_full, quantos(objeto.data)


def atributos(dados: Dados) -> list[tuple[str, str]]:
    """(nome, tipo) dos atributos de ponto da peça, sem os internos do Blender (começados por ponto)."""
    return [(a.name, a.data_type) for a in dados.attributes if a.domain == "POINT" and not a.name.startswith(".")]


def ler(dados: Dados, nome: str, escolhidos: np.ndarray | None = None, cor_em_srgb: bool = False) -> np.ndarray:
    """Um atributo de ponto, (pontos, números por ponto), só dos `escolhidos` se vierem. `cor_em_srgb` lê qualquer cor em sRGB."""
    atributo = dados.attributes.get(nome)
    if atributo is None:
        raise ValueError(f"{dados.name}: a peça não tem o atributo de ponto {nome!r}")
    if atributo.data_type not in TIPOS:
        raise ValueError(f"{dados.name}: o atributo {nome!r} é do tipo {atributo.data_type}, que o complemento não sabe ler")
    campo, por_ponto, numpy = TIPOS[atributo.data_type]
    if cor_em_srgb and campo in ("color", "color_srgb"):
        campo = "color_srgb"
    tudo = np.empty(quantos(dados) * por_ponto, numpy)
    atributo.data.foreach_get(campo, tudo)
    tudo = tudo.reshape(-1, por_ponto)
    return tudo if escolhidos is None else tudo[escolhidos]


def posicoes(dados: Dados, escolhidos: np.ndarray | None = None) -> np.ndarray:
    """As posições dos pontos (n, 3)."""
    return ler(dados, "position", escolhidos=escolhidos)


def cores(dados: Dados, escolhidos: np.ndarray | None = None, cor_em_srgb: bool = True) -> np.ndarray:
    """A cor de cada ponto (n, 4). Com `cor_em_srgb=True`, lê a cor em sRGB."""
    return ler(dados, PLACA.atributo_da_cor, escolhidos=escolhidos, cor_em_srgb=cor_em_srgb)


def raios(dados: Dados, escolhidos: np.ndarray | None = None) -> np.ndarray | None:
    """O atributo de raio de cada ponto (n,), se existir (na nativa); None na antiga."""
    if isinstance(dados, bpy.types.PointCloud) or PLACA.atributo_do_raio in dados.attributes:
        return ler(dados, PLACA.atributo_do_raio, escolhidos=escolhidos).ravel()
    return None

