"""Dissolver, Esticar e Pintar de uma cor feitos no desenho de cada ponto pela placa (vertex shader), com os valores
animados do modificador lidos a cada quadro. O render continua saindo dos grupos de nós (`ferramentas.py`).

Contrato entre as frentes do Modo leve: o desenho (`desenho_na_placa.py`) junta `GLSL` ao shader dele e, no vertex shader,
chama `aplicar_efeitos(posicao, cor, numero_do_ponto)` antes de projetar o ponto; antes de desenhar uma peça, passa ao
shader o que `valores_da_peca` devolve. Os valores vão num uniform buffer (UBO), e não em push constants, que passam de 128
bytes com a luz e os efeitos (riscos 1 e 2): o desenho declara a struct `EfeitosDaPeca`, com um `vec4` por item de
`UNIFORMS`, na ordem deles (layout std140 sem enchimento), liga o buffer com o nome `efeitos` e `GLSL` lê
`efeitos.<nome>`. O corpo é da frente dos efeitos.
"""
from dataclasses import dataclass

import bpy


@dataclass(frozen=True)
class Uniform:
    tipo: str       # sempre "VEC4": um campo da struct EfeitosDaPeca; valores menores ocupam os primeiros componentes
    nome: str


GLSL = ""
"""Funções GLSL; define `void aplicar_efeitos(inout vec3 posicao, inout vec3 cor, uint numero_do_ponto)`, nas coordenadas
da malha, aplicando os efeitos da peça na ordem dos modificadores."""

UNIFORMS: tuple[Uniform, ...] = ()
"""Os campos de `EfeitosDaPeca` que `GLSL` lê, iguais para toda peça; o que a peça não usa vai desligado em
`valores_da_peca`."""

PRECISA_DO_NUMERO_DO_PONTO: frozenset[str] = frozenset()
"""Grupos de efeito que sorteiam por ponto e precisam do número do ponto (o `id`, ou o índice) como atributo de vértice."""


def efeitos_da_peca(objeto: bpy.types.Object) -> list[str] | None:
    """Os grupos de efeito da peça que a placa sabe fazer, na ordem dos modificadores ligados na janela, depois de
    "Pontos da nuvem". None se a peça tem algum modificador que a placa não sabe fazer: ela fica no Geometry Nodes."""
    raise NotImplementedError


def valores_da_peca(objeto: bpy.types.Object) -> dict[str, tuple[float, float, float, float]]:
    """O valor de cada nome de `UNIFORMS` para a peça, no quadro atual (já com a animação avaliada), em 4 componentes."""
    raise NotImplementedError
