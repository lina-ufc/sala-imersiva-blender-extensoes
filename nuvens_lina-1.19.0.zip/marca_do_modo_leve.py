"""O que o Modo leve mudou numa peça e como devolver só isso. Sem bpy, para testar sem o Blender.

Ao tirar a peça do desenho do Blender, o Modo leve muda até dois campos dela: liberada ou local, o `show_viewport` do
"Pontos da nuvem" (para desligado) e o `display_type` (para caixa, `BOUNDS`); só vinculada, o olho (fechado). A peça em nuvem
de pontos nativa (Point Cloud, desde a 1.18.0) não tem o "Pontos da nuvem": a marca dela fica com `modificador` None, e só
o `display_type` (e os efeitos) contam. Na 1.17 e na
1.18, a peça com efeito que virava cópia reduzida tinha desligado na janela também cada outro modificador que estava ligado,
cujos nomes iam em `desligados`; desde a 1.19.0 a peça com efeito só ganha o modificador de redução (`reducao.py`) e nada
vai em `desligados`, que fica para devolver o que um salvamento automático dessas versões gravou. A `Marca` guarda o valor que cada campo tinha antes. Devolver olha campo por campo: volta ao valor de antes só o campo que ainda está
como o Modo leve o deixou; o campo que o artista mudou depois fica como ele quis.

As marcas das peças aplicadas também vão para o arquivo, num texto JSON na camada de vista (`PROPRIEDADE`): o salvamento
automático não chama o `save_pre` e grava as peças aplicadas, e numa sessão nova é a marca que diz ao complemento, ao abrir,
o que ele tinha mudado. A marca não fica na peça porque a propriedade personalizada posta num objeto liberado (Library
Override) some ao reabrir o arquivo (medido no Blender 5.2 em 12/11/2026); a camada de vista é do arquivo do artista e
guarda a propriedade.
"""
import json
from dataclasses import asdict, dataclass, field

PROPRIEDADE = "nuvens_modo_leve_aplicado"
CAIXA = "BOUNDS"
MODOS = ("override", "vinculada")


@dataclass(frozen=True)
class Marca:
    """Os valores de antes de o Modo leve aplicar a peça."""
    modo: str                    # "override" (liberada ou local) ou "vinculada"
    modificador: bool | None = True   # show_viewport do "Pontos da nuvem"; None na peça nativa, que não o tem
    display: str = "TEXTURED"    # display_type do objeto
    oculto: bool = False         # o olho, na camada de vista da marca
    desligados: tuple[str, ...] = ()   # os outros modificadores que estavam ligados na janela e o Modo leve desligou


@dataclass(frozen=True)
class Agora:
    """Os mesmos campos, como a peça está agora; `modificador` é None se a peça não tem o "Pontos da nuvem" (nativa, ou o perdeu). `efeitos` é o
    `show_viewport` de cada outro modificador, pelo nome."""
    modificador: bool | None
    display: str
    oculto: bool
    efeitos: dict[str, bool] = field(default_factory=dict)


@dataclass(frozen=True)
class Devolucao:
    """O valor a pôr em cada campo; None deixa o campo como está."""
    modificador: bool | None = None
    display: str | None = None
    oculto: bool | None = None
    religar: tuple[str, ...] = ()   # os modificadores a ligar de novo na janela


def _ainda_desligados(marca: Marca, agora: Agora) -> tuple[str, ...]:
    return tuple(nome for nome in marca.desligados if agora.efeitos.get(nome) is False)


def o_que_devolver(marca: Marca, agora: Agora) -> Devolucao:
    if marca.modo == "vinculada":
        return Devolucao(oculto=marca.oculto if agora.oculto else None)
    return Devolucao(modificador=marca.modificador if marca.modificador is not None and agora.modificador is False else None,
                     display=marca.display if agora.display == CAIXA else None, religar=_ainda_desligados(marca, agora))


def parece_aplicada(marca: Marca, agora: Agora) -> bool:
    """Todos os campos que o Modo leve muda estão como ele os deixa."""
    if marca.modo == "vinculada":
        return agora.oculto
    modificador = marca.modificador is None or agora.modificador is False
    return modificador and agora.display == CAIXA and _ainda_desligados(marca, agora) == marca.desligados


def ler(texto: str | None) -> dict[str, Marca]:
    """As marcas guardadas na camada de vista, pelo nome completo do objeto; vazio sem a propriedade. A marca gravada antes
    da 1.17.0 não tem `desligados`: vale vazio."""
    if texto is None:
        return {}
    marcas = {}
    for nome, campos in json.loads(texto).items():
        marca = Marca(**{**campos, "desligados": tuple(campos.get("desligados", ()))})
        if marca.modo not in MODOS:
            raise ValueError(f"{PROPRIEDADE}: modo desconhecido {marca.modo!r} em {nome!r}")
        marcas[nome] = marca
    return marcas


def escrever(marcas: dict[str, Marca]) -> str:
    return json.dumps({nome: asdict(marca) for nome, marca in sorted(marcas.items())}, ensure_ascii=False)
