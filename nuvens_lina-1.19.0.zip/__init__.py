"""Complemento do Blender do Filme da Nuvem. Cada parte é um módulo com register e unregister:

- ao_soltar: a coleção marcada (a Sala) chega liberada com Library Override quando é solta do Asset Browser.
- visor: o editor do visor da sala: a janela com a sala simulada, vista do olho do público, e a fita das cinco telas.
- ao_vivo: as cinco telas do visor desenhadas como a 3D View, no shading escolhido para o visor.
- renderizar: o que sai pelo motor da cena e cria coisas no arquivo: Renderizar a fita e as câmeras da cena.
- marcas: as arestas da sala, a letra de cada parede e o teto, desenhados por cima da vista do olho do visor.
- leve: apaga das cenas as propriedades que as versões até a 1.16 gravavam.
- modo_leve: o botão Modo leve, que desenha as nuvens sem efeito direto pela placa (desenho_na_placa) e reduz as com efeito
  por um modificador só da janela (reducao), malha com o Pontos da nuvem ou nuvem de pontos nativa (pontos_da_peca).
- selecao_na_placa: o clique que seleciona a peça desenhada pela placa, com o Modo leve ligado.
- opcoes: as escolhas do Modo leve, guardadas nas cenas do arquivo.

Uma parte nova (por exemplo a trava das tomadas no Gitea) entra como outro módulo nesta lista.
"""
from . import (
    ao_soltar,
    ao_vivo,
    leve,
    marcas,
    modo_leve,
    opcoes,
    renderizar,
    selecao_na_placa,
    visor,
)

PARTES = (ao_soltar, visor, ao_vivo, renderizar, marcas, leve, modo_leve, selecao_na_placa)


def register() -> None:
    modo_leve.registrar_o_painel_da_aba()   # primeiro painel da aba Sala: entre os de mesma ordem vale o registro
    for parte in PARTES:
        parte.register()
    opcoes.registrar(modo_leve.definicoes(None, None))


def unregister() -> None:
    opcoes.desregistrar()
    for parte in reversed(PARTES):
        parte.unregister()
