"""A sala simulada, vista do olho (o Image Editor da Sala, que o desenho cobre inteiro, no formato da área): cada superfície
com o desenho dela ao vivo (ao_vivo.py), e por cima as arestas da sala, a letra de cada parede, o teto e a porta. Na fita
(o Image Editor com a imagem do visor), o contorno e a letra de cada parede, o contorno do piso e a porta. Não criam objeto
nem mudam a cena ou a imagem: são só desenho; as marcas se ligam e desligam no painel (Arestas, Letras, Teto, Divisórias,
Porta)."""
import math

import blf
import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Matrix, Vector

from . import ao_vivo, visor
from .visor import VISOR

_desenhos: list[tuple[type, object]] = []


def superficies(sala: bpy.types.Object) -> dict[str, list[Vector]]:
    """Os cantos de cada superfície da sala, no mundo, pelo nome dela (o mesmo da câmera: "Parede A", "Piso")."""
    cantos: dict[str, list[Vector]] = {}
    for filho in sala.children:
        if filho.type != "MESH" or not filho.name.startswith(VISOR.prefixo_da_superficie):
            continue
        nome = filho.name.removeprefix(VISOR.prefixo_da_superficie)
        cantos[nome] = [filho.matrix_world @ v.co for v in filho.data.vertices]
    return cantos


def _altura(ponto: Vector, sala: bpy.types.Object) -> float:
    return ponto.dot(sala.matrix_world.to_3x3().col[2].normalized())


def _em_volta(cantos: list[Vector]) -> list[Vector]:
    """Os cantos do retângulo na ordem em volta do centro."""
    centro = sum(cantos, Vector()) / len(cantos)
    eixo_a = (cantos[0] - centro).normalized()
    eixo_b = (cantos[1] - centro) - (cantos[1] - centro).project(eixo_a)
    eixo_b = eixo_b.normalized() if eixo_b.length > 1e-9 else eixo_a.orthogonal().normalized()
    return sorted(cantos, key=lambda p: math.atan2((p - centro).dot(eixo_b), (p - centro).dot(eixo_a)))


def _bordas(cantos: list[Vector]) -> list[Vector]:
    """As quatro bordas do retângulo, em pares de pontos, na ordem dos cantos em volta do centro."""
    em_volta = _em_volta(cantos)
    pares: list[Vector] = []
    for i, ponto in enumerate(em_volta):
        pares += [ponto, em_volta[(i + 1) % len(em_volta)]]
    return pares


def _projecao(sala: bpy.types.Object, cantos: dict[str, list[Vector]]) -> dict[str, tuple[list[Vector], list[tuple[float, float]]]]:
    """Os triângulos de cada superfície e, em cada canto, onde ele cai na imagem da câmera dela: a direita e o cima da
    imagem nos da câmera."""
    cameras = {c[VISOR.propriedade_da_superficie]: c for c in visor.cameras_da_sala(sala)}
    projecao: dict[str, tuple[list[Vector], list[tuple[float, float]]]] = {}
    for nome, pontos in cantos.items():
        giro = cameras[nome].matrix_world.to_3x3()
        direita, cima = giro.col[0].normalized(), giro.col[1].normalized()
        us, vs = [p.dot(direita) for p in pontos], [p.dot(cima) for p in pontos]
        em_volta = _em_volta(pontos)
        na_imagem = [((p.dot(direita) - min(us)) / (max(us) - min(us)), (p.dot(cima) - min(vs)) / (max(vs) - min(vs)))
                     for p in em_volta]
        indices = (0, 1, 2, 0, 2, 3)
        projecao[nome] = ([em_volta[i] for i in indices], [na_imagem[i] for i in indices])
    return projecao


def _porta_em_fracao() -> list[tuple[float, float]]:
    """O vão da porta (as quatro bordas), as bordas do encosto entre as duas folhas e a barra, em pares de pontos, em
    fração da imagem da parede dela."""
    esquerda, direita, topo, barra, barra_0, barra_1, encosto_0, encosto_1 = visor.SALA.porta_na_parede()
    cantos = [(esquerda, 0.0), (direita, 0.0), (direita, topo), (esquerda, topo)]
    pares: list[tuple[float, float]] = []
    for i, canto in enumerate(cantos):
        pares += [canto, cantos[(i + 1) % 4]]
    return [*pares, (encosto_0, 0.0), (encosto_0, topo), (encosto_1, 0.0), (encosto_1, topo), (barra_0, barra), (barra_1, barra)]


def _porta_na_cena(sala: bpy.types.Object, cantos: dict[str, list[Vector]]) -> list[Vector]:
    """A porta no mundo, sobre a parede dela, com a direita e o cima da câmera dessa parede."""
    nome = visor.SALA.porta.parede
    camera = next(c for c in visor.cameras_da_sala(sala) if c[VISOR.propriedade_da_superficie] == nome)
    giro = camera.matrix_world.to_3x3()
    direita, cima = giro.col[0].normalized(), giro.col[1].normalized()
    pontos = cantos[nome]
    us, vs = [p.dot(direita) for p in pontos], [p.dot(cima) for p in pontos]
    origem = min(pontos, key=lambda p: p.dot(direita) + p.dot(cima))
    largura, altura = max(us) - min(us), max(vs) - min(vs)
    return [origem + direita * (x * largura) + cima * (y * altura) for x, y in _porta_em_fracao()]


def _desenhar_linhas(pontos: list[tuple[float, float, float]], cor: tuple[float, float, float, float], espessura: float) -> None:
    sombreador = gpu.shader.from_builtin("POLYLINE_UNIFORM_COLOR")
    lote = batch_for_shader(sombreador, "LINES", {"pos": pontos})
    regiao = bpy.context.region
    sombreador.uniform_float("viewportSize", (regiao.width, regiao.height))
    sombreador.uniform_float("lineWidth", espessura)
    sombreador.uniform_float("color", cor)
    lote.draw(sombreador)


def _desenhar_a_projecao(sala: bpy.types.Object, cantos: dict[str, list[Vector]]) -> None:
    # As texturas já saem com a gestão de cor da vista; o sombreador só as copia.
    sombreador = gpu.shader.from_builtin("IMAGE")
    for nome, (posicoes, uvs) in _projecao(sala, cantos).items():
        textura = ao_vivo.textura(nome)
        if textura is None:
            continue
        lote = batch_for_shader(sombreador, "TRIS", {"pos": [tuple(p) for p in posicoes], "texCoord": uvs})
        sombreador.uniform_sampler("image", textura)
        lote.draw(sombreador)


def _desenhar_a_sala(sala: bpy.types.Object, cantos: dict[str, list[Vector]]) -> None:
    """As superfícies, o teto, as arestas e a porta, com a vista e a projeção do olho já carregadas. Sem teste de
    profundidade: de dentro da sala, nenhuma superfície fica atrás de outra."""
    opcoes = bpy.context.scene.visor_da_sala
    _desenhar_a_projecao(sala, cantos)
    gpu.state.blend_set("ALPHA")
    if VISOR.superficie_do_piso in cantos:
        paredes = [p for nome, ps in cantos.items() if nome != VISOR.superficie_do_piso for p in ps]
        piso = cantos[VISOR.superficie_do_piso]
        subir = max(_altura(p, sala) for p in paredes) - max(_altura(p, sala) for p in piso)
        acima = sala.matrix_world.to_3x3().col[2].normalized() * subir
        teto = [p + acima for p in _bordas(piso)[::2]]
        sombreador = gpu.shader.from_builtin("UNIFORM_COLOR")
        lote = batch_for_shader(sombreador, "TRIS", {"pos": [tuple(p) for p in teto]}, indices=[(0, 1, 2), (0, 2, 3)])
        sombreador.uniform_float("color", VISOR.cor_do_teto if opcoes.teto else (*VISOR.cor_fora_da_sala, 1.0))
        lote.draw(sombreador)
    if opcoes.arestas:
        linhas = [tuple(p) for ps in cantos.values() for p in _bordas(ps)]
        _desenhar_linhas(linhas, VISOR.cor_das_arestas, VISOR.espessura_das_arestas_px)
    if opcoes.porta:
        _desenhar_linhas([tuple(p) for p in _porta_na_cena(sala, cantos)], VISOR.cor_da_porta, VISOR.espessura_da_porta_px)
    gpu.state.blend_set("NONE")


def _desenhar_letras(sala: bpy.types.Object, cantos: dict[str, list[Vector]], olho_na_tela: Matrix) -> None:
    """A letra de cada parede acima do meio do topo dela, se ele está à frente do olho."""
    regiao = bpy.context.region
    blf.size(0, VISOR.tamanho_das_letras_px)
    blf.color(0, *VISOR.cor_das_letras)
    for nome, pontos in cantos.items():
        if nome == VISOR.superficie_do_piso:
            continue
        alturas = sorted(pontos, key=lambda p: _altura(p, sala))
        topo = olho_na_tela @ ((alturas[-1] + alturas[-2]) / 2).to_4d()
        if topo.w <= 0:
            continue
        x = (topo.x / topo.w + 1.0) / 2.0 * regiao.width
        y = (topo.y / topo.w + 1.0) / 2.0 * regiao.height
        letra = nome.split()[-1]
        blf.position(0, x - blf.dimensions(0, letra)[0] / 2, y + VISOR.letras_acima_do_topo_px, 0)
        blf.draw(0, letra)


def _desenhar_o_olho() -> None:
    """No Image Editor da Sala: o fundo cobre a área inteira, e a sala simulada vai por cima, vista do olho."""
    contexto = bpy.context
    if not visor.mostra(contexto.space_data, {VISOR.nome_do_olho}):
        return
    regiao = contexto.region
    sombreador = gpu.shader.from_builtin("UNIFORM_COLOR")
    fundo = batch_for_shader(sombreador, "TRIS", {"pos": [(0.0, 0.0), (regiao.width, 0.0), (regiao.width, regiao.height),
                                                          (0.0, regiao.height)]}, indices=[(0, 1, 2), (0, 2, 3)])
    sombreador.uniform_float("color", (*VISOR.cor_fora_da_sala, 1.0))
    fundo.draw(sombreador)
    cena = contexto.scene
    try:
        sala = visor.sala_do_visor(cena)
        cantos = superficies(sala)
        olho = visor.olho(cena)
    except RuntimeError as erro:
        blf.size(0, VISOR.tamanho_das_letras_px)
        blf.color(0, *VISOR.cor_das_letras)
        blf.position(0, VISOR.letras_acima_do_topo_px, regiao.height / 2, 0)
        blf.draw(0, str(erro))
        return
    projecao = visor.projecao_do_olho(cena.visor_da_sala.campo, regiao.width, regiao.height)
    vista = olho.inverted()
    estado_da_profundidade = gpu.state.depth_test_get()
    gpu.state.depth_test_set("NONE")
    with gpu.matrix.push_pop(), gpu.matrix.push_pop_projection():
        gpu.matrix.load_matrix(vista)
        gpu.matrix.load_projection_matrix(projecao)
        _desenhar_a_sala(sala, cantos)
    gpu.state.depth_test_set(estado_da_profundidade)
    if cena.visor_da_sala.letras:
        _desenhar_letras(sala, cantos, projecao @ vista)


def retangulos_da_fita(primeira: str) -> dict[str, tuple[float, float, float, float]]:
    """Onde cada superfície fica na fita, em fração da imagem (x0, y0, x1, y1, com y de baixo para cima), pela mesma conta
    da fita ao vivo e de Renderizar a fita (`visor.lugares_na_fita`)."""
    lugares = visor.lugares_na_fita(primeira)
    largura, altura = visor.tamanho_da_fita()
    return {nome: (x / largura, y / altura, min(1.0, (x + w) / largura), (y + h) / altura)
            for nome, (x, y, w, h) in lugares.items()}


def _desenhar_na_fita() -> None:
    opcoes = bpy.context.scene.visor_da_sala
    if not visor.mostra(bpy.context.space_data, {VISOR.nome_da_imagem, VISOR.nome_do_render}):
        return
    if not (opcoes.divisorias or opcoes.letras or opcoes.porta):
        return
    try:
        retangulos = retangulos_da_fita(opcoes.primeira_da_fita)
    except RuntimeError:
        return
    regiao = bpy.context.region
    no_ecra = regiao.view2d.view_to_region
    if opcoes.divisorias:
        linhas = []
        for x0, y0, x1, y1 in retangulos.values():
            cantos = [no_ecra(x0, y0, clip=False), no_ecra(x1, y0, clip=False), no_ecra(x1, y1, clip=False),
                      no_ecra(x0, y1, clip=False)]
            for i, canto in enumerate(cantos):
                linhas += [(*canto, 0.0), (*cantos[(i + 1) % 4], 0.0)]
        gpu.state.blend_set("ALPHA")
        _desenhar_linhas(linhas, VISOR.cor_das_divisorias, VISOR.espessura_das_divisorias_px)
        gpu.state.blend_set("NONE")
    if opcoes.porta:
        x0, y0, x1, y1 = retangulos[visor.SALA.porta.parede]
        linhas = [(*no_ecra(x0 + x * (x1 - x0), y0 + y * (y1 - y0), clip=False), 0.0) for x, y in _porta_em_fracao()]
        gpu.state.blend_set("ALPHA")
        _desenhar_linhas(linhas, VISOR.cor_da_porta, VISOR.espessura_da_porta_px)
        gpu.state.blend_set("NONE")
    if opcoes.letras:
        blf.size(0, VISOR.tamanho_das_letras_px)
        blf.color(0, *VISOR.cor_das_letras)
        for nome, (x0, _y0, x1, y1) in retangulos.items():
            if nome == VISOR.superficie_do_piso:
                continue
            letra = nome.split()[-1]
            x, y = no_ecra((x0 + x1) / 2, y1, clip=False)
            blf.position(0, x - blf.dimensions(0, letra)[0] / 2, y + VISOR.letras_acima_do_topo_px, 0)
            blf.draw(0, letra)


def register() -> None:
    _desenhos.append((bpy.types.SpaceImageEditor,
                      bpy.types.SpaceImageEditor.draw_handler_add(_desenhar_o_olho, (), "WINDOW", "POST_PIXEL")))
    _desenhos.append((bpy.types.SpaceImageEditor,
                      bpy.types.SpaceImageEditor.draw_handler_add(_desenhar_na_fita, (), "WINDOW", "POST_PIXEL")))


def unregister() -> None:
    for espaco, desenho in _desenhos:
        espaco.draw_handler_remove(desenho, "WINDOW")
    _desenhos.clear()
