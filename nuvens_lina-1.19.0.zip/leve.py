"""O que sobrou dos *Pontos na janela*: apagar das cenas as propriedades que as versões até a 1.16 gravavam, e o redesenho
das 3D Views que o Modo leve pede.

Até a 1.16, a parte dos pontos na janela ia para uma propriedade da cena (`propriedade_da_cena`), que o grupo "Pontos da
nuvem" lia por um driver para reduzir a peça na janela; a 1.13 gravava também as do foco (`propriedades_da_cena`). Com a
cópia reduzida (1.17.0), essa redução dobraria: o complemento as apaga das cenas onde ainda estiverem (arquivos antigos). Sem
elas, o grupo deixa a peça inteira.

O controle *Pontos nas peças com efeito* (até a 1.14, *Pontos na janela*; propriedade `pontos_na_janela`) saiu na 1.18.0: a
peça com efeito segue a mesma *Densidade* das peças na placa (`modo_leve.py`; desde a 1.19.0, pela redução, `reducao.py`). Um arquivo que ainda guarda o valor dele nas
`opcoes_da_janela` da cena abre normalmente: o Blender guarda o valor sem dono e ninguém o lê.
"""
import bpy

from . import dados

LEVE = dados.modo_leve()
ANTIGAS = (LEVE.propriedade_da_cena, *LEVE.propriedades_da_cena.values())


def redesenhar() -> None:
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def apagar_das_cenas() -> None:
    """Apaga das cenas do arquivo as propriedades que as versões até a 1.16 gravavam. O driver do grupo dos pontos só relê o
    valor com a cena e o grupo marcados (medido sem janela em 09/11/2026), então os dois são avisados."""
    mudou = False
    for cena in bpy.data.scenes:
        if cena.library is not None:
            continue
        for nome in [n for n in ANTIGAS if n in cena]:
            del cena[nome]
            cena.update_tag()
            mudou = True
    if not mudou:
        return
    for grupo in bpy.data.node_groups:
        if grupo.bl_idname == "GeometryNodeTree" and LEVE.nome_do_no in grupo.nodes:
            grupo.update_tag()
    redesenhar()


@bpy.app.handlers.persistent
def _ao_abrir(_arquivo: str, _grafo: object = None) -> None:
    apagar_das_cenas()


def _apagar_ao_ligar() -> None:
    apagar_das_cenas()


def register() -> None:
    bpy.app.handlers.load_post.append(_ao_abrir)
    # Ao ligar o complemento com um arquivo já aberto (instalar ou atualizar a extensão), nenhum load_post roda.
    bpy.app.timers.register(_apagar_ao_ligar, first_interval=0.0)


def unregister() -> None:
    if _ao_abrir in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_ao_abrir)
