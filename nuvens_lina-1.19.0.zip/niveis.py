"""Níveis dos pontos de uma peça, para o Modo leve desenhar mais pontos perto e menos longe sem ler a peça inteira.

A peça é regravada uma vez (`niveis.py`, na raiz do repositório) com os vértices e a cor `Col` numa ordem nova, sem tirar nem
acrescentar ponto: primeiro uma amostra da peça inteira (o nó 0, nível 0), depois as amostras de cada oitavo da caixa dela
(nível 1), e assim por diante, como no Potree. Cada nó guarda uma amostra dos pontos que caem na caixa dele; os filhos guardam
o resto. Dentro de cada nó os pontos ficam embaralhados, então os primeiros N de um nó são uma amostra espalhada dele.

A tabela dos nós fica na própria malha, na propriedade `PROPRIEDADE` (um dicionário de listas, que o Blender grava como
propriedade de ID). Sem bpy, para os testes rodarem fora do Blender.

Contrato entre as frentes do Modo leve: as assinaturas e o formato abaixo são fixos; o corpo das funções é da frente dos
níveis. Na placa, a posição compacta vai em 4 componentes de 16 bits (o 4º livre): o Metal não aceita atributo de 3
componentes de 16 bits (cai com passo ímpar ou chega zerado ao shader). `compactar` devolve os 3 eixos; quem envia completa o 4º.
"""
from dataclasses import dataclass

import numpy as np

PROPRIEDADE = "nuvens_niveis"
VERSAO_DO_FORMATO = 1
CHAVES = ("versao", "inicio", "contagem", "nivel", "pai", "minimo", "maximo")
MAIOR_INTEIRO_DA_PROPRIEDADE = 2**31 - 1    # o Blender grava lista de inteiros da propriedade em 32 bits
MAIOR_COMPACTO = 65535


@dataclass(frozen=True)
class RegrasDosNiveis:
    """Vêm do dados.json (`modo_leve.niveis`)."""
    pontos_por_no: int          # amostra que cada nó guarda; o nó com menos pontos que isso não se divide
    nivel_maximo: int
    semente: int                # do embaralhamento dentro de cada nó; a mesma peça sai sempre na mesma ordem


@dataclass(frozen=True)
class Tabela:
    """Um nó por linha, em ordem: o nó i ocupa os pontos inicio[i] até inicio[i] + contagem[i] - 1 da peça regravada.
    Os nós de um nível vêm todos antes dos do nível seguinte, e o pai vem antes dos filhos."""
    inicio: np.ndarray      # int64 (n,)
    contagem: np.ndarray    # int64 (n,)
    nivel: np.ndarray       # int32 (n,)
    pai: np.ndarray         # int32 (n,); -1 no nó 0
    minimo: np.ndarray      # float32 (n, 3), caixa do nó nas coordenadas da malha
    maximo: np.ndarray      # float32 (n, 3)

    def para_propriedade(self) -> dict[str, int | list[int] | list[float]]:
        """O dicionário gravado em `PROPRIEDADE` (caixas achatadas em listas de 3n números)."""
        if len(self.inicio) and int(self.inicio[-1] + self.contagem[-1]) > MAIOR_INTEIRO_DA_PROPRIEDADE:
            raise ValueError(f"peça com {int(self.inicio[-1] + self.contagem[-1]):,} pontos: a propriedade do Blender só guarda "
                             f"inteiros até {MAIOR_INTEIRO_DA_PROPRIEDADE:,}")
        return {
            "versao": VERSAO_DO_FORMATO,
            "inicio": self.inicio.tolist(),
            "contagem": self.contagem.tolist(),
            "nivel": self.nivel.tolist(),
            "pai": self.pai.tolist(),
            "minimo": self.minimo.ravel().tolist(),
            "maximo": self.maximo.ravel().tolist(),
        }

    @staticmethod
    def de_propriedade(valor: dict) -> "Tabela":
        """Lê o que `para_propriedade` gravou. Erro se faltar chave ou a versão não for `VERSAO_DO_FORMATO`."""
        faltam = [chave for chave in CHAVES if chave not in valor]
        if faltam:
            raise ValueError(f"tabela dos níveis sem {faltam}")
        if int(valor["versao"]) != VERSAO_DO_FORMATO:
            raise ValueError(f"tabela dos níveis na versão {valor['versao']}; este código lê a {VERSAO_DO_FORMATO}")
        return Tabela(
            inicio=np.asarray(valor["inicio"], np.int64),
            contagem=np.asarray(valor["contagem"], np.int64),
            nivel=np.asarray(valor["nivel"], np.int32),
            pai=np.asarray(valor["pai"], np.int32),
            minimo=np.asarray(valor["minimo"], np.float32).reshape(-1, 3),
            maximo=np.asarray(valor["maximo"], np.float32).reshape(-1, 3),
        )


@dataclass(frozen=True)
class Niveis:
    ordem: np.ndarray       # int64 (N,): o ponto k da peça regravada é o ponto ordem[k] da peça original
    tabela: Tabela


def montar(pontos: np.ndarray, regras: RegrasDosNiveis) -> Niveis:
    """Os níveis de uma peça a partir das posições (float32 (N, 3), coordenadas da malha). `ordem` é uma permutação de
    0..N-1: nenhum ponto some nem se repete.

    Os pontos são embaralhados uma vez (semente das regras) e, depois, só reordenados por ordenações estáveis: dentro de cada
    nó continuam na ordem do embaralhamento. A cada nível, cada nó fica com os primeiros `pontos_por_no` dos seus (ou com
    todos, se não passarem disso ou se o nível for o máximo) e o resto desce para o oitavo da caixa em que cai. A caixa de um
    nó é a justa dos pontos dele e dos que descem dele, então cabe na do pai."""
    if pontos.ndim != 2 or pontos.shape[1] != 3:
        raise ValueError(f"esperava posições (N, 3); veio {pontos.shape}")
    if regras.pontos_por_no < 1 or regras.nivel_maximo < 0:
        raise ValueError(f"regras dos níveis inválidas: {regras}")
    total = len(pontos)
    pontos = np.ascontiguousarray(pontos, np.float32)
    restantes = np.random.default_rng(regras.semente).permutation(total)
    posicoes = pontos[restantes]    # andam junto com `restantes`, para não buscar cada ponto ao acaso a cada nível
    # Os grupos de `restantes` são os nós do nível: o nó j ocupa restantes[limites[j]:limites[j + 1]].
    limites = np.array([0, total], np.int64)
    pais = np.array([-1], np.int64)
    minimos = pontos.min(0, keepdims=True) if total else np.zeros((1, 3), np.float32)
    maximos = pontos.max(0, keepdims=True) if total else np.zeros((1, 3), np.float32)

    ordens: list[np.ndarray] = []
    inicio: list[np.ndarray] = []
    contagem: list[np.ndarray] = []
    nivel: list[np.ndarray] = []
    pai: list[np.ndarray] = []
    minimo: list[np.ndarray] = []
    maximo: list[np.ndarray] = []
    escritos = 0
    no_do_nivel = 0
    for n in range(regras.nivel_maximo + 1):
        quantos = np.diff(limites)
        ficam = quantos if n == regras.nivel_maximo else np.minimum(quantos, regras.pontos_por_no)
        posicao_no_no = np.arange(len(restantes), dtype=np.int64) - np.repeat(limites[:-1], quantos)
        fica = posicao_no_no < np.repeat(ficam, quantos)
        ordens.append(restantes[fica])
        inicio.append(escritos + np.concatenate([[0], np.cumsum(ficam)[:-1]]).astype(np.int64))
        contagem.append(ficam.astype(np.int64))
        nivel.append(np.full(len(quantos), n, np.int32))
        pai.append(pais)
        minimo.append(minimos)
        maximo.append(maximos)
        escritos += int(ficam.sum())

        descem = ~fica
        if not descem.any():
            break
        no = np.repeat(np.arange(len(quantos), dtype=np.int64), quantos)[descem]
        restantes, posicoes = restantes[descem], posicoes[descem]
        meio = ((minimos.astype(np.float64) + maximos) / 2).astype(np.float32)
        oitavo = np.zeros(len(no), np.int8)
        for eixo in range(3):
            oitavo |= (posicoes[:, eixo] > meio[no, eixo]).astype(np.int8) << eixo
        destino = _destino_por_oitavo(no, oitavo, len(quantos))
        restantes[destino], posicoes[destino] = restantes.copy(), posicoes.copy()
        chave = np.empty(len(no), np.int64)
        chave[destino] = no * 8 + oitavo
        comeco = np.flatnonzero(np.concatenate([[True], chave[1:] != chave[:-1]]))
        limites = np.concatenate([comeco, [len(restantes)]]).astype(np.int64)
        pais = (no_do_nivel + chave[comeco] // 8).astype(np.int64)
        minimos = np.minimum.reduceat(posicoes, comeco, axis=0)
        maximos = np.maximum.reduceat(posicoes, comeco, axis=0)
        no_do_nivel += len(quantos)

    ordem = np.concatenate(ordens).astype(np.int64)
    if len(ordem) != total:
        raise AssertionError(f"os níveis ficaram com {len(ordem):,} de {total:,} pontos")
    tabela = Tabela(
        inicio=np.concatenate(inicio), contagem=np.concatenate(contagem), nivel=np.concatenate(nivel),
        pai=np.concatenate(pai).astype(np.int32),
        minimo=np.concatenate(minimo).astype(np.float32), maximo=np.concatenate(maximo).astype(np.float32),
    )
    return Niveis(ordem=ordem, tabela=tabela)


def _destino_por_oitavo(no: np.ndarray, oitavo: np.ndarray, nos: int) -> np.ndarray:
    """Para onde vai cada ponto numa ordenação estável por (nó, oitavo), sem ordenar pela chave inteira: `no` já vem em ordem
    crescente, e o lugar de um ponto é o começo do grupo (nó, oitavo) mais quantos do mesmo grupo vieram antes dele. Agrupar
    pelo oitavo (int8) usa a ordenação por contagem do numpy, que é linear."""
    chave = no * 8 + oitavo
    comeco_do_grupo = np.concatenate([[0], np.cumsum(np.bincount(chave, minlength=nos * 8))[:-1]])
    por_oitavo = np.argsort(oitavo, kind="stable")
    agrupada = chave[por_oitavo]
    comeco = np.flatnonzero(np.concatenate([[True], agrupada[1:] != agrupada[:-1]]))
    antes = np.arange(len(chave), dtype=np.int64) - np.repeat(comeco, np.diff(np.concatenate([comeco, [len(chave)]])))
    destino = np.empty(len(chave), np.int64)
    destino[por_oitavo] = comeco_do_grupo[agrupada] + antes
    return destino


def _escala(minimo: np.ndarray, maximo: np.ndarray) -> np.ndarray:
    extensao = np.asarray(maximo, np.float64) - np.asarray(minimo, np.float64)
    return np.where(extensao > 0, extensao, 1.0) / MAIOR_COMPACTO


def compactar(pontos: np.ndarray, minimo: np.ndarray, maximo: np.ndarray) -> np.ndarray:
    """Posições de um nó em 16 bits por eixo, relativas à caixa dele: uint16 (n, 3), 0 no mínimo e 65535 no máximo."""
    passos = (np.asarray(pontos, np.float64) - np.asarray(minimo, np.float64)) / _escala(minimo, maximo)
    return np.clip(np.rint(passos), 0, MAIOR_COMPACTO).astype(np.uint16)


def descompactar(compactos: np.ndarray, minimo: np.ndarray, maximo: np.ndarray) -> np.ndarray:
    """O inverso de `compactar`, em float32 (n, 3); o erro fica abaixo de um passo de 16 bits da caixa."""
    return (np.asarray(minimo, np.float64) + compactos.astype(np.float64) * _escala(minimo, maximo)).astype(np.float32)
