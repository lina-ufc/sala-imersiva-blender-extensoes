"""As escolhas do artista no Modo leve, guardadas no arquivo.

Os controles continuam no Window Manager, que vale para a sessão e para todas as cenas do arquivo. A cada mudança, o
`modo_leve` passa o valor também à `PropertyGroup` `opcoes_da_janela` de cada cena do arquivo, que o Blender grava no
`.blend`; antes de salvar, todas as cenas recebem de novo os valores (uma cena criada depois da última mudança também). Ao
abrir um arquivo (`load_post`), o `modo_leve` lê as escolhas da cena aberta e as aplica. Num arquivo de antes, sem
elas, a PropertyGroup devolve o padrão, que é o valor de partida do dados.json.

Só a escolha vai para o arquivo. As peças na placa e o que o Modo leve muda nelas não vão.
"""
from collections.abc import Iterable

import bpy

Propriedade = object   # o que bpy.props.*Property devolve (bpy.props._PropertyDeferred), que o Blender não expõe como tipo
Valor = int | float | bool

NOME_NA_CENA = "opcoes_da_janela"
_registrado: dict[str, type[bpy.types.PropertyGroup] | None] = {"classe": None}


def _cenas_do_arquivo() -> list[bpy.types.Scene]:
    return [cena for cena in bpy.data.scenes if cena.library is None]


def guardar(gerenciador: bpy.types.WindowManager, nomes: Iterable[str]) -> None:
    """Passa os valores de `nomes` do Window Manager às opções de cada cena do arquivo; só grava o que mudou."""
    valores = {nome: getattr(gerenciador, nome) for nome in nomes}
    for cena in _cenas_do_arquivo():
        guardadas = getattr(cena, NOME_NA_CENA)
        for nome, valor in valores.items():
            if getattr(guardadas, nome) != valor:
                setattr(guardadas, nome, valor)


def ler(cena: bpy.types.Scene, nomes: Iterable[str]) -> dict[str, Valor]:
    """As escolhas que a cena guarda; num arquivo de antes, os valores de partida."""
    guardadas = getattr(cena, NOME_NA_CENA)
    return {nome: getattr(guardadas, nome) for nome in nomes}


@bpy.app.handlers.persistent
def _antes_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    classe = _registrado["classe"]
    assert classe is not None, "o handler só fica registrado junto com a PropertyGroup"
    guardar(bpy.context.window_manager, classe.__annotations__)


def registrar(definicoes: dict[str, Propriedade]) -> None:
    """Cria a PropertyGroup das cenas com as mesmas definições dos controles do Window Manager, sem o update deles."""
    classe = type("OpcoesDaJanela", (bpy.types.PropertyGroup,), {"__annotations__": dict(definicoes)})
    bpy.utils.register_class(classe)
    setattr(bpy.types.Scene, NOME_NA_CENA, bpy.props.PointerProperty(type=classe))
    _registrado["classe"] = classe
    bpy.app.handlers.save_pre.append(_antes_de_salvar)


def desregistrar() -> None:
    classe = _registrado["classe"]
    if classe is None:
        return
    if _antes_de_salvar in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.remove(_antes_de_salvar)
    delattr(bpy.types.Scene, NOME_NA_CENA)
    bpy.utils.unregister_class(classe)
    _registrado["classe"] = None
