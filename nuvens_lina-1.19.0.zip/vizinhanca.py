"""A parte da seleção por clique que não depende do Blender: do bloco de pixels lido em volta do mouse, o número da peça.

Sem importar `bpy` nem outros módulos do complemento, para o teste importá-lo direto.
"""
import numpy as np


def numeros_do_bloco(bloco: np.ndarray) -> np.ndarray:
    """Os números de um bloco RGBA de 8 bits (altura, largura, 4), com o byte menos significativo no vermelho."""
    if bloco.ndim != 3 or bloco.shape[2] != 4 or bloco.dtype != np.uint8:
        raise ValueError(f"o bloco precisa ser uint8 (altura, largura, 4); veio {bloco.dtype} {bloco.shape}")
    return np.ascontiguousarray(bloco).view("<u4")[..., 0]


def numero_mais_perto(bloco: np.ndarray, centro_x: int, centro_y: int) -> int:
    """O número diferente de 0 mais perto do pixel (centro_x, centro_y) do bloco; 0 se o bloco só tem fundo."""
    numeros = numeros_do_bloco(bloco)
    ys, xs = np.nonzero(numeros)
    if len(xs) == 0:
        return 0
    distancias = (xs - centro_x) ** 2 + (ys - centro_y) ** 2
    return int(numeros[ys[np.argmin(distancias)], xs[np.argmin(distancias)]])


def janela_de_leitura(x: int, y: int, raio: int, largura: int, altura: int) -> tuple[int, int, int, int] | None:
    """O quadrado (x0, y0, largura, altura) de lado 2 × raio + 1 em volta de (x, y), cortado pela região; None se o ponto
    fica fora dela."""
    if not (0 <= x < largura and 0 <= y < altura):
        return None
    x0, y0 = max(x - raio, 0), max(y - raio, 0)
    x1, y1 = min(x + raio, largura - 1), min(y + raio, altura - 1)
    return x0, y0, x1 - x0 + 1, y1 - y0 + 1
