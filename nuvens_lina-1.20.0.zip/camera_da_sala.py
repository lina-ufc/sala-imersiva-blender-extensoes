"""A câmera da sala inteira do storyboard (`sala_camera.osl`, no nuvens-blender) com as medidas da sala de complemento/sala.json.

A câmera guarda dois tipos de parâmetro. Os da sala (medidas, olho do público, tamanhos em pixels) não são dela: este
módulo os escreve a partir do sala.json ao abrir um arquivo e antes de cada render, e o render.py do nuvens-blender, antes de
desenhar. Os do artista (`horizonte`, `alongamento`, `perto`, `aproximacao`) ficam na câmera e não são tocados.

Uma câmera é da sala quando é do tipo personalizado (OSL) e tem os parâmetros `horizonte` e `alongamento`. Câmera vinculada
de outro arquivo não se escreve: ela recebe os valores no arquivo dela.

Sem importar nada do complemento, para o render.py carregá-lo sozinho.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

import bpy

if TYPE_CHECKING:
    from .dados import Sala

PARAMETROS_DO_ARTISTA = ("horizonte", "alongamento")


def valores_da_sala(sala: Sala) -> dict[str, float | int]:
    """Os parâmetros da sala, na ordem do OSL: a parede A dá o comprimento, a B a largura, e os pixels são os do master."""
    a, b = sala.paredes[0], sala.paredes[1]
    return {"comprimento": a.largura_m, "largura": b.largura_m, "altura": a.altura_m, "olho": sala.altura_do_olho_m,
            "px_longa": a.largura_px, "px_curta": b.largura_px, "px_altura": a.altura_px, "px_piso": sala.piso.altura_px}


def eh_da_sala(dados: bpy.types.Camera) -> bool:
    return dados.type == "CUSTOM" and all(p in dados.cycles_custom for p in PARAMETROS_DO_ARTISTA)


def escrever(dados: bpy.types.Camera, sala: Sala) -> None:
    """Escreve na câmera os parâmetros da sala que estiverem diferentes."""
    for chave, valor in valores_da_sala(sala).items():
        if chave not in dados.cycles_custom:
            raise KeyError(f'a câmera "{dados.name}" não tem o parâmetro "{chave}" de sala_camera.osl: o OSL dela é de antes')
        if dados.cycles_custom[chave] != valor:
            dados.cycles_custom[chave] = valor


def escrever_em_todas(sala: Sala) -> int:
    """Escreve a sala nas câmeras da sala deste arquivo; devolve quantas."""
    cameras = [c for c in bpy.data.cameras if c.library is None and eh_da_sala(c)]
    for dados in cameras:
        escrever(dados, sala)
    return len(cameras)


@bpy.app.handlers.persistent
def _escrever_a_sala(*_: object) -> None:
    from . import dados
    escrever_em_todas(dados.sala())


HANDLERS = (bpy.app.handlers.load_post, bpy.app.handlers.render_init)


def register() -> None:
    for lista in HANDLERS:
        lista.append(_escrever_a_sala)


def unregister() -> None:
    for lista in HANDLERS:
        if _escrever_a_sala in lista:
            lista.remove(_escrever_a_sala)
