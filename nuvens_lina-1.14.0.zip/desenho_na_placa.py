"""Desenho das peças pela placa no Modo leve: o que a 3D View, o visor ao vivo e a seleção por clique chamam.

Contrato entre as frentes do Modo leve: as assinaturas de `Vista`, `pecas_na_placa`, `desenhar` e `desenhar_para_selecao` são
fixas. Quem desenha numa textura fora da tela (o visor, `ao_vivo.py`, e a seleção, `selecao_na_placa.py`) liga a textura e
chama estas funções com as matrizes da câmera dela; nenhuma delas liga ou desliga textura por conta própria.

Cada ponto tem uma sorte fixa (`campo_de_visao.sorte_de_cada_ponto`) e aparece quando ela fica abaixo da parte que a
distância dele ao olho pede (`pela_distancia`): todos perto, cada vez menos longe, sem salto, porque os pontos de longe são parte
dos de perto. A peça é lida da malha uma vez (`preparar`) e posta em ordem de sorte fora da linha principal do Blender; depois
vai à placa em pedaços (`enviar_um_pedaco`), do começo dessa ordem, e o começo dela é exatamente o conjunto de pontos que uma
parte pede. Chegar perto só acrescenta pedaços, afastar só desenha menos deles, e nada é lido nem enviado de novo; os pedaços
de cima saem quando falta memória (`soltar_sobras`). Por ponto vão a posição em 16 bits dentro da caixa da peça, com a sorte no
quarto componente, e a cor em 8 bits: 12 bytes, como mostraram os riscos no Metal (posição de 3 componentes de 16 bits quebra). A cada quadro, cada peça à vista vai num pedido de desenho só: matrizes, luzes e planos de recorte seguem num buffer
uniforme (UBO) por pedido, tirado de um anel que dá a volta só depois de `ubos_em_anel` pedidos, porque reescrever um buffer
já usado no mesmo quadro estragaria os pedidos anteriores. Cada ponto é um disco com a normal de uma esfera (`gl_PointCoord`),
`discard` fora do círculo e profundidade da esfera em `gl_FragDepth`, iluminado por até `luzes_maximas` luzes da cena e pelo
céu (luz difusa, sem sombra nem névoa: é uma prévia). Os efeitos entram pelo contrato de `efeitos_na_placa`.

Peça fora do campo de visão não é desenhada. A parte pela distância é multiplicada pela que a janela pede (`Pontos na janela`,
se o botão deles está ligado, e `Pontos no render (%)`, a menor).
"""
import time
import zlib
from concurrent.futures import Future, ThreadPoolExecutor, wait
from dataclasses import dataclass, field

import bpy
import gpu
import numpy as np
from mathutils import Matrix, Vector

from . import campo_de_visao, efeitos_na_placa, placa_dados

PLACA = placa_dados.placa()

# Propriedades do Window Manager que o Modo leve registra (modo_leve.py) e o desenho e a seleção leem a cada pedido.
PROPRIEDADE_DO_BOTAO = "modo_leve"
PROPRIEDADE_DA_ESCALA = "modo_leve_escala_do_ponto"
PROPRIEDADE_DA_LUZ = "modo_leve_com_luz"
PROPRIEDADE_DA_CHEIA = "modo_leve_cheia_ate_m"
PROPRIEDADE_DA_PARTE_MINIMA = "modo_leve_parte_minima"
PROPRIEDADE_DOS_PONTOS_NA_JANELA = "pontos_na_janela"   # leve.py
PROPRIEDADE_DO_BOTAO_DOS_PONTOS = "pontos_na_janela_ligados"   # leve.py; desligado, a placa não reduz


@dataclass(frozen=True)
class Vista:
    """De onde se desenha: a 3D View, uma superfície do visor ou a textura da seleção."""
    matriz_da_vista: Matrix         # mundo para câmera
    matriz_de_projecao: Matrix      # câmera para recorte
    largura_px: int
    altura_px: int
    planos_de_recorte: tuple[tuple[float, float, float, float], ...]   # os do Alt+B, no mundo; vazio sem recorte


@dataclass
class Entrada:
    """Uma peça que o Modo leve entrega ao desenho. `visivel` é falso para a peça que o artista escondeu."""
    nome: str                 # name_full do objeto
    objeto: bpy.types.Object
    tamanho_cm: float         # o Tamanho do ponto (cm) do modificador
    fracao: float             # o Pontos no render (%) do modificador, de 0 a 1
    visivel: bool = True
    so_na_selecao: bool = False   # a peça selecionada que o Geometry Nodes desenha: sem desenho, mas com número, para o clique achá-la


BYTES_POR_PONTO = 12


@dataclass
class Pedaco:
    lote: gpu.types.GPUBatch
    vbo: gpu.types.GPUVertBuf
    pontos: int


@dataclass
class Carregada:
    """Uma peça preparada: os pontos em ordem de sorte, prontos para ir à placa, e os pedaços que já foram."""
    chave: tuple[str, int]    # a malha e o número de vértices dela: outra chave pede preparar de novo
    total: int                # os da malha
    minimo: np.ndarray        # caixa da peça inteira, coordenadas da malha
    maximo: np.ndarray
    posicao: np.ndarray       # (total, 4) uint16, em ordem de sorte, com a sorte no quarto componente
    cor: np.ndarray           # (total, 4) uint8, na mesma ordem
    acumulado: np.ndarray     # campo_de_visao.acumulado_da_sorte
    pedacos: list[Pedaco] = field(default_factory=list)
    usada_em: float = 0.0     # a última vez que foi desenhada

    @property
    def enviados(self) -> int:
        return sum(p.pontos for p in self.pedacos)


@dataclass(frozen=True)
class _Lida:
    chave: tuple[str, int]
    posicao: np.ndarray       # float32 (total, 3)
    cor: np.ndarray           # float32 (total, 4), sRGB
    semente: int


class SemEspaco(RuntimeError):
    """A peça não cabe na memória máxima da placa que o Modo leve pode usar."""


@dataclass
class _Estado:
    entradas: list[Entrada] = field(default_factory=list)
    luzes: list[bpy.types.Object] = field(default_factory=list)
    ambiente: tuple[float, float, float] | None = None
    carregadas: dict[str, Carregada] = field(default_factory=dict)
    em_preparo: dict[str, Future] = field(default_factory=dict)
    shader: gpu.types.GPUShader | None = None
    aneis: dict[str, list[gpu.types.GPUUniformBuf]] = field(default_factory=lambda: {"parametros": [], "efeitos": []})
    proximo_do_anel: int = 0
    bytes_na_placa: int = 0
    mascara: gpu.types.GPUOffScreen | None = None       # a silhueta das peças selecionadas, do tamanho da região
    sombreador_do_contorno: gpu.types.GPUShader | None = None
    quadro_do_contorno: gpu.types.GPUBatch | None = None


_E = _Estado()


# O layout do buffer `Parametros` (std140, em floats). A struct do GLSL tem os mesmos campos na mesma ordem.
_VISTA, _PROJECAO, _MODELO = 0, 16, 32
_MINIMO, _TAMANHO, _GERAL, _EXTRA, _NUMERO, _AMBIENTE, _CIMA, _DENSIDADE = 48, 52, 56, 60, 64, 68, 72, 76
_LUZES = 80
_PLANOS = _LUZES + 8 * PLACA.luzes_maximas
_FLOATS_DOS_PARAMETROS = _PLANOS + 4 * PLACA.planos_maximos

_GLSL_DOS_TIPOS = f"""
struct Parametros {{
  mat4 vista;
  mat4 projecao;
  mat4 modelo;
  vec4 minimo;       // xyz: canto da caixa da peça (malha); w: raio do ponto no mundo
  vec4 tamanho;      // xyz: tamanho da caixa; w: altura da região em pixels
  vec4 geral;        // x: 1 na seleção; y: número de luzes; z: ponto mínimo em px; w: ponto máximo em px
  vec4 extra;        // x: número de planos de recorte; y: 1 com luz da cena; z: 1 no contorno; w: quanto o ponto cresce no contorno
  vec4 numero;       // a cor do número da peça, na seleção; a cor do contorno, no contorno
  vec4 ambiente;     // rgb: o céu, linear
  vec4 cima;         // xyz: o zênite, nas coordenadas da vista
  vec4 densidade;    // x: cheia até (m); y: parte mínima; z: parte da janela
  vec4 luzes[{2 * PLACA.luzes_maximas}];   // por luz: [xyz posição ou direção na vista, w 1 se é sol], [rgb cor vezes força]
  vec4 planos[{PLACA.planos_maximos}];
}};
struct EfeitosDaPeca {{
{''.join(f'  vec4 {u.nome};' + chr(10) for u in efeitos_na_placa.UNIFORMS)}  vec4 reservado;
}};
"""

_SEM_EFEITOS = "void aplicar_efeitos(inout vec3 posicao, inout vec3 cor, uint numero_do_ponto) {}\n"

_GLSL_DO_VERTICE = f"""
void main()
{{
  vec3 p = parametros.minimo.xyz + pos.xyz * parametros.tamanho.xyz;
  vec3 c = cor.rgb;
  aplicar_efeitos(p, c, uint(gl_VertexID));
  vec4 mundo = parametros.modelo * vec4(p, 1.0);
  bool recortado = false;
  int n_planos = int(parametros.extra.x);
  for (int i = 0; i < {PLACA.planos_maximos}; i++) {{
    if (i < n_planos && dot(parametros.planos[i].xyz, mundo.xyz) + parametros.planos[i].w < 0.0) {{
      recortado = true;
    }}
  }}
  vec4 v = parametros.vista * mundo;
  float longe = max(length(v.xyz), 1e-4);
  float pela_distancia = longe <= parametros.densidade.x ? 1.0
      : max(parametros.densidade.y, (parametros.densidade.x / longe) * (parametros.densidade.x / longe));
  if (pos.w >= pela_distancia * parametros.densidade.z) {{
    recortado = true;
  }}
  vec4 clip = parametros.projecao * v;
  float w = max(clip.w, 1e-4);
  float escala_px = parametros.projecao[1][1] * parametros.tamanho.w;
  float diametro = clamp(parametros.minimo.w * escala_px / w, parametros.geral.z, parametros.geral.w);
  if (parametros.extra.z > 0.5) {{
    diametro = min(diametro * parametros.extra.w, parametros.geral.w);
  }}
  centro_v = v.xyz;
  raio_v = diametro * w / escala_px;
  cor_v = c;
  gl_Position = recortado ? vec4(2.0, 2.0, 2.0, 1.0) : clip;
  gl_PointSize = diametro;
}}
"""

_GLSL_DO_FRAGMENTO = f"""
vec3 srgb_para_linear(vec3 c)
{{
  return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), c));
}}

vec3 linear_para_srgb(vec3 c)
{{
  c = clamp(c, 0.0, 1.0);
  return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), c));
}}

void main()
{{
  vec2 d = gl_PointCoord * 2.0 - 1.0;
  d.y = -d.y;
  float r2 = dot(d, d);
  if (r2 > 1.0) {{
    discard;
  }}
  vec3 normal = vec3(d, sqrt(1.0 - r2));
  vec3 ponto = centro_v + normal * raio_v;
  vec4 na_tela = parametros.projecao * vec4(ponto, 1.0);
  gl_FragDepth = (na_tela.z / na_tela.w) * 0.5 + 0.5;
  if (parametros.geral.x > 0.5) {{
    saida = parametros.numero;
  }}
  else {{
    vec3 albedo = srgb_para_linear(cor_v);
    vec3 luz = vec3(1.0);
    if (parametros.extra.y > 0.5) {{
      luz = parametros.ambiente.rgb * (0.5 + 0.5 * dot(normal, parametros.cima.xyz));
      int n_luzes = int(parametros.geral.y);
      for (int i = 0; i < {PLACA.luzes_maximas}; i++) {{
        if (i < n_luzes) {{
          vec4 onde = parametros.luzes[2 * i];
          vec4 cor_da_luz = parametros.luzes[2 * i + 1];
          vec3 para_a_luz = onde.xyz;
          float atenuacao = 1.0;
          if (onde.w < 0.5) {{
            vec3 q = onde.xyz - ponto;
            float distancia2 = max(dot(q, q), 1e-6);
            para_a_luz = q * inversesqrt(distancia2);
            atenuacao = 1.0 / distancia2;
          }}
          luz += cor_da_luz.rgb * atenuacao * max(dot(normal, para_a_luz), 0.0);
        }}
      }}
    }}
    saida = vec4(linear_para_srgb(albedo * luz), 1.0);
  }}
}}
"""


def _criar_o_shader() -> gpu.types.GPUShader:
    interface = gpu.types.GPUStageInterfaceInfo("modo_leve_iface")
    interface.smooth("VEC3", "cor_v")
    interface.flat("VEC3", "centro_v")
    interface.flat("FLOAT", "raio_v")
    info = gpu.types.GPUShaderCreateInfo()
    info.typedef_source(_GLSL_DOS_TIPOS)
    info.uniform_buf(0, "Parametros", "parametros")
    info.uniform_buf(1, "EfeitosDaPeca", "efeitos")
    info.vertex_in(0, "VEC4", "pos")
    info.vertex_in(1, "VEC4", "cor")
    info.vertex_out(interface)
    info.fragment_out(0, "VEC4", "saida")
    info.depth_write("ANY")
    info.vertex_source((efeitos_na_placa.GLSL or _SEM_EFEITOS) + _GLSL_DO_VERTICE)
    info.fragment_source(_GLSL_DO_FRAGMENTO)
    return gpu.shader.create_from_info(info)


def _buffer(valores: np.ndarray) -> gpu.types.Buffer:
    return gpu.types.Buffer("FLOAT", len(valores), np.ascontiguousarray(valores, np.float32))


def _ubo_do_anel(nome: str, valores: np.ndarray) -> gpu.types.GPUUniformBuf:
    anel = _E.aneis[nome]
    indice = _E.proximo_do_anel % PLACA.ubos_em_anel
    if indice >= len(anel):
        anel.append(gpu.types.GPUUniformBuf(_buffer(valores)))
    else:
        anel[indice].update(_buffer(valores))
    return anel[indice]


def definir_a_cena(entradas: list[Entrada], luzes: list[bpy.types.Object], ambiente: tuple[float, float, float] | None) -> None:
    """As peças que o desenho deve mostrar, as luzes e o céu da cena. Quem chama (modo_leve.py) refaz isso a cada mudança,
    e depois de cada desfazer, quando as referências aos objetos morrem."""
    _E.entradas = sorted(entradas, key=lambda e: e.nome)
    _E.luzes = luzes
    _E.ambiente = ambiente


_PREPARO = ThreadPoolExecutor(max_workers=1, thread_name_prefix="modo_leve")


def carregada(nome: str, objeto: bpy.types.Object) -> bool:
    """A peça tem pelo menos um pedaço na placa, da malha que o objeto tem agora."""
    c = _E.carregadas.get(nome)
    return c is not None and c.chave == _chave(objeto) and bool(c.pedacos)


def preparada(nome: str, objeto: bpy.types.Object) -> bool:
    c = _E.carregadas.get(nome)
    return c is not None and c.chave == _chave(objeto)


def em_preparo(nome: str) -> bool:
    return nome in _E.em_preparo


def _na_placa(nome: str) -> bool:
    c = _E.carregadas.get(nome)
    return c is not None and bool(c.pedacos)


def _chave(objeto: bpy.types.Object) -> tuple[str, int]:
    return objeto.data.name_full, len(objeto.data.vertices)


def bytes_na_placa() -> int:
    return _E.bytes_na_placa


def _soltar_pedacos(c: Carregada, ate: int) -> None:
    """Tira os pedaços de cima até a peça ficar com no máximo `ate` pontos na placa (sempre pedaços inteiros)."""
    while c.pedacos and c.enviados - c.pedacos[-1].pontos >= ate:
        _E.bytes_na_placa -= c.pedacos.pop().pontos * BYTES_POR_PONTO


def liberar(nome: str) -> None:
    c = _E.carregadas.pop(nome, None)
    if c is not None:
        _soltar_pedacos(c, 0)
    futuro = _E.em_preparo.pop(nome, None)
    if futuro is not None:
        futuro.cancel()


def liberar_tudo() -> None:
    """Solta as peças, o shader e os buffers: a placa volta a ser do Blender."""
    for futuro in _E.em_preparo.values():
        futuro.cancel()
    _E.em_preparo.clear()
    _E.carregadas.clear()
    _E.entradas = []
    _E.luzes = []
    _E.shader = None
    _E.aneis = {"parametros": [], "efeitos": []}
    _E.proximo_do_anel = 0
    _E.bytes_na_placa = 0
    if _E.mascara is not None:
        _E.mascara.free()
    _E.mascara = None
    _E.sombreador_do_contorno = None
    _E.quadro_do_contorno = None


def preparar(nome: str, objeto: bpy.types.Object) -> None:
    """Lê a posição e a cor da malha (precisa da linha principal) e põe a peça em ordem de sorte num processo de fundo; o
    resultado chega por `recolher`."""
    malha = objeto.data
    total = len(malha.vertices)
    if total == 0:
        raise ValueError(f"{nome}: a peça não tem pontos")
    if PLACA.atributo_da_cor not in malha.attributes:
        raise ValueError(f"{nome}: a malha não tem o atributo de cor {PLACA.atributo_da_cor!r}")
    posicao = np.empty(total * 3, np.float32)
    malha.attributes["position"].data.foreach_get("vector", posicao)
    cor = np.empty(total * 4, np.float32)
    malha.attributes[PLACA.atributo_da_cor].data.foreach_get("color_srgb", cor)
    lida = _Lida(_chave(objeto), posicao.reshape(-1, 3), cor.reshape(-1, 4), (PLACA.semente + zlib.crc32(nome.encode())) & 0xFFFFFFFF)
    liberar(nome)
    _E.em_preparo[nome] = _PREPARO.submit(_ordenar, lida)


def _ordenar(lida: _Lida) -> Carregada:
    """Fora da linha principal: só numpy, que solta o Python enquanto conta."""
    total = len(lida.posicao)
    sorte = campo_de_visao.sorte_de_cada_ponto(total, lida.semente)
    ordem = np.argsort(sorte, kind="stable")
    minimo, maximo = lida.posicao.min(0), lida.posicao.max(0)
    compacta = campo_de_visao.compactar(lida.posicao, minimo, maximo)
    compacta[:, 3] = sorte
    # Reordenar os dados já compactados, um inteiro de 8 ou 4 bytes por ponto, é bem mais rápido que reordenar os floats.
    posicao = compacta.view(np.uint64).ravel()[ordem].view(np.uint16).reshape(-1, 4)
    cor = campo_de_visao.cor_em_bytes(lida.cor).view(np.uint32).ravel()[ordem].view(np.uint8).reshape(-1, 4)
    return Carregada(lida.chave, total, minimo, maximo, posicao, cor, campo_de_visao.acumulado_da_sorte(sorte))


def dar_vez_ao_preparo() -> None:
    """Espera um pouco pelo preparo em segundo plano. A linha principal do Blender segura o Python enquanto não espera nada,
    e a linha de fundo só anda nessas esperas."""
    if _E.em_preparo:
        wait(list(_E.em_preparo.values()), timeout=PLACA.espera_pelo_preparo_s)


def recolher() -> list[tuple[str, Exception | None]]:
    """As peças cujo preparo terminou, com o erro de cada uma (None quando deu certo)."""
    prontas: list[tuple[str, Exception | None]] = []
    for nome, futuro in list(_E.em_preparo.items()):
        if not futuro.done():
            continue
        del _E.em_preparo[nome]
        erro = futuro.exception()
        if erro is None:
            _E.carregadas[nome] = futuro.result()
        prontas.append((nome, erro))   # type: ignore[arg-type]
    return prontas


def pontos_pedidos(nome: str, parte: float) -> int:
    return campo_de_visao.pontos_ate(_E.carregadas[nome].acumulado, parte)


def pontos_enviados(nome: str) -> int:
    c = _E.carregadas.get(nome)
    return 0 if c is None else c.enviados


def soltar_sobras(pedidos: dict[str, int], precisa_bytes: int) -> None:
    """Abre espaço na placa tirando, das peças que têm mais pontos do que pedem agora, os pedaços de cima, a peça usada há
    mais tempo primeiro, até caberem `precisa_bytes` a mais."""
    limite = PLACA.memoria_maxima_mb * 1024 * 1024
    com_sobra = sorted((c.usada_em, nome) for nome, c in _E.carregadas.items() if c.enviados > pedidos.get(nome, 0))
    for _, nome in com_sobra:
        if _E.bytes_na_placa + precisa_bytes <= limite:
            return
        _soltar_pedacos(_E.carregadas[nome], pedidos.get(nome, 0))


def enviar_um_pedaco(nome: str, ate: int, pedidos: dict[str, int]) -> int:
    """Manda à placa o pedaço seguinte da peça, de até `pontos_por_envio` pontos, sem passar de `ate`. Levanta SemEspaco
    quando nem soltando as sobras das outras peças ele cabe. Devolve quantos pontos foram."""
    c = _E.carregadas[nome]
    inicio = c.enviados
    fim = min(ate, c.total, inicio + PLACA.pela_distancia.pontos_por_envio)
    if fim <= inicio:
        return 0
    precisa = (fim - inicio) * BYTES_POR_PONTO
    if _E.bytes_na_placa + precisa > PLACA.memoria_maxima_mb * 1024 * 1024:
        soltar_sobras(pedidos, precisa)
        if _E.bytes_na_placa + precisa > PLACA.memoria_maxima_mb * 1024 * 1024:
            raise SemEspaco(nome)
    formato = gpu.types.GPUVertFormat()
    formato.attr_add(id="pos", comp_type="U16", len=4, fetch_mode="INT_TO_FLOAT_UNIT")
    formato.attr_add(id="cor", comp_type="U8", len=4, fetch_mode="INT_TO_FLOAT_UNIT")
    vbo = gpu.types.GPUVertBuf(formato, fim - inicio)
    vbo.attr_fill("pos", c.posicao[inicio:fim])
    vbo.attr_fill("cor", c.cor[inicio:fim])
    c.pedacos.append(Pedaco(gpu.types.GPUBatch(type="POINTS", buf=vbo), vbo, fim - inicio))
    _E.bytes_na_placa += precisa
    if _E.shader is None:
        _E.shader = _criar_o_shader()
    return fim - inicio


def caixa_carregada(nome: str) -> tuple[np.ndarray, np.ndarray] | None:
    c = _E.carregadas.get(nome)
    return None if c is None else (c.minimo, c.maximo)


def pela_distancia() -> tuple[float, float]:
    """Os controles do painel: até quantos metros do olho aparecem todos os pontos e a parte mínima de longe, de 0 a 1."""
    gerenciador = bpy.context.window_manager
    return float(getattr(gerenciador, PROPRIEDADE_DA_CHEIA)), float(getattr(gerenciador, PROPRIEDADE_DA_PARTE_MINIMA)) / 100


def parte_da_janela() -> float:
    """A parte que os Pontos na janela pedem (1 com o botão deles desligado)."""
    gerenciador = bpy.context.window_manager
    if not getattr(gerenciador, PROPRIEDADE_DO_BOTAO_DOS_PONTOS):
        return 1.0
    return getattr(gerenciador, PROPRIEDADE_DOS_PONTOS_NA_JANELA) / 100


def ambiente_da_cena(cena: bpy.types.Scene) -> tuple[float, float, float] | None:
    """O céu que ilumina: a cor vezes a força do nó Background mais claro do mundo; a cor do mundo sem nós; None sem mundo."""
    mundo = cena.world
    if mundo is None:
        return None
    if not mundo.use_nodes:
        return tuple(mundo.color)   # type: ignore[return-value]
    melhor, brilho = None, -1.0
    for no in mundo.node_tree.nodes:
        if no.bl_idname != "ShaderNodeBackground":
            continue
        cor = no.inputs["Color"].default_value
        forca = no.inputs["Strength"].default_value
        valor = (cor[0] * forca, cor[1] * forca, cor[2] * forca)
        luminancia = 0.2126 * valor[0] + 0.7152 * valor[1] + 0.0722 * valor[2]
        if luminancia > brilho:
            melhor, brilho = valor, luminancia
    return melhor


Luz = tuple[tuple[float, float, float, float], tuple[float, float, float, float]]
ZENITE = Vector((0.0, 0.0, 1.0))


def _luzes_na_vista(matriz_da_vista: Matrix) -> list[Luz]:
    """Até `luzes_maximas` luzes, as de mais força primeiro: (posição ou direção na vista com w 1 se é sol, cor vezes força).
    O sol vale a força em W/m² como o Cycles a entende (força 1 deixa um plano branco de frente em 1); as outras luzes valem a
    potência em watts dividida por `divisor_da_luz_de_ponto` e pelo quadrado da distância, sem cone nem tamanho: spot e area
    contam como luz de ponto."""
    rotacao = matriz_da_vista.to_3x3()
    luzes: list[tuple[float, Luz]] = []
    for objeto in _E.luzes:
        luz = objeto.data
        cor = np.array(luz.color, np.float64) * luz.energy
        if luz.type == "SUN":
            direcao = (rotacao @ (objeto.matrix_world.to_3x3() @ ZENITE)).normalized()
            luzes.append((float(cor.max()), ((*direcao, 1.0), (*cor, 0.0))))
            continue
        posicao = matriz_da_vista @ objeto.matrix_world.translation
        cor = cor / PLACA.divisor_da_luz_de_ponto
        luzes.append((float(cor.max()), ((*posicao, 0.0), (*cor, 0.0))))
    luzes.sort(key=lambda t: -t[0])
    return [luz for _, luz in luzes[:PLACA.luzes_maximas]]


def _luz_e_ceu(matriz_da_vista: Matrix) -> tuple[list[Luz], np.ndarray]:
    """As luzes da cena na vista e o céu; sem luz nem céu, a luz de partida do dados.json."""
    luzes = _luzes_na_vista(matriz_da_vista)
    ambiente = _E.ambiente
    if not luzes and ambiente is None:
        p = PLACA.luz_de_partida
        direcao = (matriz_da_vista.to_3x3() @ Vector(p.direcao)).normalized()
        luzes = [((*direcao, 1.0), (*(np.array(p.cor) * p.forca), 0.0))]
        ambiente = p.ambiente
    return luzes, np.array(ambiente if ambiente is not None else (0.0, 0.0, 0.0), np.float64)


def _parametros(vista: Vista, modelo: Matrix, caixa: Carregada, raio_do_ponto: float, selecao: bool, numero: int,
                luzes: list[Luz], ambiente: np.ndarray, com_luz: bool, parte_da_janela: float, contorno: bool = False) -> np.ndarray:
    v = np.zeros(_FLOATS_DOS_PARAMETROS, np.float32)
    v[_VISTA:_VISTA + 16] = np.asarray(vista.matriz_da_vista, np.float32).T.ravel()
    v[_PROJECAO:_PROJECAO + 16] = np.asarray(vista.matriz_de_projecao, np.float32).T.ravel()
    v[_MODELO:_MODELO + 16] = np.asarray(modelo, np.float32).T.ravel()
    v[_MINIMO:_MINIMO + 4] = (*caixa.minimo, raio_do_ponto)
    v[_TAMANHO:_TAMANHO + 4] = (*(caixa.maximo - caixa.minimo), vista.altura_px)
    v[_GERAL:_GERAL + 4] = (1.0 if selecao or contorno else 0.0, len(luzes), PLACA.ponto_minimo_px, PLACA.ponto_maximo_px)
    planos = vista.planos_de_recorte[:PLACA.planos_maximos]
    v[_EXTRA:_EXTRA + 4] = (len(planos), 1.0 if com_luz else 0.0, 1.0 if contorno else 0.0, PLACA.contorno.escala_do_ponto)
    v[_NUMERO:_NUMERO + 4] = PLACA.contorno.cor if contorno else campo_de_visao.numero_em_cor(numero) if selecao else (0.0, 0.0, 0.0, 0.0)
    v[_AMBIENTE:_AMBIENTE + 4] = (*ambiente, 0.0)
    v[_CIMA:_CIMA + 4] = (*(vista.matriz_da_vista.to_3x3() @ ZENITE), 0.0)
    v[_DENSIDADE:_DENSIDADE + 4] = (*pela_distancia(), parte_da_janela, 0.0)
    for i, (onde, cor) in enumerate(luzes):
        v[_LUZES + 8 * i:_LUZES + 8 * i + 4] = onde
        v[_LUZES + 8 * i + 4:_LUZES + 8 * i + 8] = cor
    for i, plano in enumerate(planos):
        v[_PLANOS + 4 * i:_PLANOS + 4 * i + 4] = plano
    return v


def _valores_dos_efeitos(_objeto: bpy.types.Object) -> np.ndarray:
    """O buffer `efeitos` da peça. Sem efeitos na placa nesta entrega, tudo desligado (zeros). Quando os efeitos chegarem,
    vem de `efeitos_na_placa.valores_da_peca(objeto)`: um vec4 por item de `UNIFORMS`, na ordem, e o `reservado` no fim."""
    return np.zeros(4 * (len(efeitos_na_placa.UNIFORMS) + 1), np.float32)


def pecas_na_placa() -> list[str]:
    """Os nomes completos (`name_full`) das peças numeradas por `desenhar_para_selecao`, na ordem dos números. Inclui as
    entregues só para a seleção (`so_na_selecao`): o Geometry Nodes as desenha, mas o clique precisa achá-las, senão a peça
    que está atrás delas seria a escolhida."""
    return [e.nome for e in _E.entradas if e.visivel and _na_placa(e.nome)]


def _desenhar(vista: Vista, selecao: bool, silhueta: bool = False) -> None:
    pecas = [(e, _E.carregadas[e.nome]) for e in _E.entradas if e.visivel and _na_placa(e.nome)]
    if not pecas or _E.shader is None:
        return
    gerenciador = bpy.context.window_manager
    escala_do_ponto = getattr(gerenciador, PROPRIEDADE_DA_ESCALA)
    com_luz = bool(getattr(gerenciador, PROPRIEDADE_DA_LUZ)) and not selecao
    da_janela = parte_da_janela()

    campo = campo_de_visao.planos_do_campo(np.asarray(vista.matriz_de_projecao @ vista.matriz_da_vista, np.float64))
    recortes = np.array(vista.planos_de_recorte, np.float64).reshape(-1, 4)
    planos = np.vstack([campo, recortes]) if len(recortes) else campo

    olho = np.asarray(vista.matriz_da_vista.inverted().translation, np.float64)
    cheia, minima = pela_distancia()
    agora = time.monotonic()
    a_desenhar: list[tuple[int, Entrada, Carregada, Matrix, int]] = []
    for numero, (entrada, c) in enumerate(pecas, start=1):
        if entrada.so_na_selecao and not selecao and not silhueta:
            continue
        if silhueta and not entrada.objeto.select_get():
            continue
        modelo = entrada.objeto.matrix_world
        cantos = campo_de_visao.cantos_da_caixa(c.minimo, c.maximo, np.asarray(modelo))
        if campo_de_visao.caixa_fora(planos, cantos):
            continue
        parte = campo_de_visao.parte_pela_distancia(campo_de_visao.distancia_ate_a_caixa(olho, cantos), cheia,
                                                    minima) * min(entrada.fracao, da_janela)
        quantos = min(campo_de_visao.pontos_ate(c.acumulado, parte), c.enviados)
        c.usada_em = agora
        a_desenhar.append((numero, entrada, c, modelo, max(quantos, 1)))
    if not a_desenhar:
        return
    luzes, ambiente = _luz_e_ceu(vista.matriz_da_vista) if com_luz else ([], np.zeros(3))

    estado = (gpu.state.depth_test_get(), gpu.state.depth_mask_get(), gpu.state.blend_get())
    gpu.state.depth_test_set("NONE" if silhueta else "LESS_EQUAL")
    gpu.state.depth_mask_set(True)
    gpu.state.blend_set("NONE")
    gpu.state.program_point_size_set(True)
    try:
        _E.shader.bind()
        for numero, entrada, c, modelo, quantos in a_desenhar:
            raio = entrada.tamanho_cm / 200 * escala_do_ponto * campo_de_visao.escala_da_matriz(np.asarray(modelo))
            parametros = _parametros(vista, modelo, c, raio, selecao, numero, luzes, ambiente, com_luz,
                                     min(entrada.fracao, da_janela), silhueta)
            _E.shader.uniform_block("parametros", _ubo_do_anel("parametros", parametros))
            _E.shader.uniform_block("efeitos", _ubo_do_anel("efeitos", _valores_dos_efeitos(entrada.objeto)))
            _E.proximo_do_anel += 1
            falta = quantos
            for pedaco in c.pedacos:
                if falta <= 0:
                    break
                if falta >= pedaco.pontos:
                    pedaco.lote.draw(_E.shader)
                else:
                    pedaco.lote.draw_range(_E.shader, elem_start=0, elem_count=falta)
                falta -= pedaco.pontos
    finally:
        gpu.state.program_point_size_set(False)
        gpu.state.depth_test_set(estado[0])
        gpu.state.depth_mask_set(estado[1])
        gpu.state.blend_set(estado[2])


def desenhar(vista: Vista) -> None:
    """Desenha as peças na placa, com cor, luz e profundidade, no que estiver ligado."""
    _desenhar(vista, selecao=False)


def tem_selecionada() -> bool:
    return any(e.visivel and _na_placa(e.nome) and e.objeto.select_get() for e in _E.entradas)


# O contorno: as peças selecionadas, com o ponto maior (`contorno.escala_do_ponto`, que fecha os vãos entre eles), vão numa
# textura fora da tela; um quadro cobrindo a região desenha a cor do contorno nos pixels fora da silhueta e até
# `contorno.raio_px` dela. Pixel que tem silhueta por perto em todas as oito direções, dentro de `contorno.vao_px`, é um vão
# entre pontos e não leva contorno: sobra a borda. Os pontos da peça não são tapados.
_GLSL_DO_CONTORNO = f"""
float tem(vec2 deslocamento)
{{
  return texture(mascara, uv_f + deslocamento * texel).a;
}}

void main()
{{
  if (tem(vec2(0.0)) > 0.5) {{
    discard;
  }}
  float perto = 0.0;
  for (int y = -{PLACA.contorno.raio_px}; y <= {PLACA.contorno.raio_px}; y++) {{
    for (int x = -{PLACA.contorno.raio_px}; x <= {PLACA.contorno.raio_px}; x++) {{
      if (x * x + y * y <= {PLACA.contorno.raio_px * PLACA.contorno.raio_px}) {{
        perto = max(perto, tem(vec2(float(x), float(y))));
      }}
    }}
  }}
  if (perto < 0.5) {{
    discard;
  }}
  bool aberto = false;
  for (int d = 0; d < 8; d++) {{
    float angulo = float(d) * 0.7853982;
    vec2 passo = vec2(cos(angulo), sin(angulo));
    float achou = 0.0;
    for (int i = 1; i <= {PLACA.contorno.vao_px}; i++) {{
      achou = max(achou, tem(passo * float(i)));
    }}
    if (achou < 0.5) {{
      aberto = true;
    }}
  }}
  if (!aberto) {{
    discard;
  }}
  saida = cor_do_contorno;
}}
"""


def _criar_o_sombreador_do_contorno() -> gpu.types.GPUShader:
    interface = gpu.types.GPUStageInterfaceInfo("modo_leve_contorno_iface")
    interface.smooth("VEC2", "uv_f")
    info = gpu.types.GPUShaderCreateInfo()
    info.sampler(0, "FLOAT_2D", "mascara")
    info.push_constant("VEC2", "texel")
    info.push_constant("VEC4", "cor_do_contorno")
    info.vertex_in(0, "VEC2", "pos")
    info.vertex_out(interface)
    info.fragment_out(0, "VEC4", "saida")
    info.vertex_source("void main() { uv_f = pos * 0.5 + 0.5; gl_Position = vec4(pos, 0.0, 1.0); }")
    info.fragment_source(_GLSL_DO_CONTORNO)
    return gpu.shader.create_from_info(info)


def desenhar_o_contorno(vista: Vista) -> None:
    """No desenho 2D da 3D View: o contorno das peças selecionadas (as da placa e as que o Geometry Nodes desenha), só na borda."""
    if _E.shader is None or not tem_selecionada():
        return
    largura, altura = vista.largura_px, vista.altura_px
    if _E.mascara is None or (_E.mascara.width, _E.mascara.height) != (largura, altura):
        if _E.mascara is not None:
            _E.mascara.free()
        _E.mascara = gpu.types.GPUOffScreen(largura, altura, format="RGBA8")
    if _E.sombreador_do_contorno is None:
        _E.sombreador_do_contorno = _criar_o_sombreador_do_contorno()
        _E.quadro_do_contorno = gpu_batch_do_quadro(_E.sombreador_do_contorno)
    with _E.mascara.bind():
        quadro = gpu.state.active_framebuffer_get()
        quadro.clear(color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
        _desenhar(vista, selecao=False, silhueta=True)
    estado = (gpu.state.depth_test_get(), gpu.state.blend_get())
    gpu.state.depth_test_set("NONE")
    gpu.state.blend_set("NONE")
    try:
        sombreador = _E.sombreador_do_contorno
        sombreador.bind()
        sombreador.uniform_sampler("mascara", _E.mascara.texture_color)
        sombreador.uniform_float("texel", (1.0 / largura, 1.0 / altura))
        sombreador.uniform_float("cor_do_contorno", PLACA.contorno.cor)
        _E.quadro_do_contorno.draw(sombreador)
    finally:
        gpu.state.depth_test_set(estado[0])
        gpu.state.blend_set(estado[1])


def gpu_batch_do_quadro(sombreador: gpu.types.GPUShader) -> gpu.types.GPUBatch:
    from gpu_extras.batch import batch_for_shader
    return batch_for_shader(sombreador, "TRI_FAN", {"pos": [(-1.0, -1.0), (1.0, -1.0), (1.0, 1.0), (-1.0, 1.0)]})


def desenhar_para_selecao(vista: Vista) -> None:
    """Desenha cada peça com a cor do número dela, sem luz: a peça i de `pecas_na_placa()` sai com o número i + 1 em
    RGBA de 8 bits (byte menos significativo no vermelho); o fundo fica 0. Escreve a profundidade, como `desenhar`."""
    _desenhar(vista, selecao=True)
