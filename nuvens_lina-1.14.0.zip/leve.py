"""Pontos na janela: a janela 3D desenha só uma parte dos pontos das nuvens, para navegar e tocar a animação mais rápido; o
render (F12, render.py e Renderizar a fita, do visor) não muda: lá vale só a entrada `Pontos no render (%)` de cada peça.
O visor ao vivo, desenhado como a 3D View, mostra os mesmos pontos que ela.

O controle, com nome, limites e valor de partida no dados.json (`modo_leve`), fica na aba Sala e no menu ao lado do botão
Modo leve (`modo_leve.py`), no cabeçalho da 3D View:
- Pontos na janela (%): a parte geral, em tudo (também nas peças que o Modo leve desenha pela placa); em 100%, sem redução.
- O botão dos Pontos na janela (`botao_dos_pontos`), também no cabeçalho, ao lado do Modo leve, com a parte em uso no
  rótulo: desligado, nada vai para a cena e a placa do Modo leve não reduz (as peças aparecem inteiras); a parte escolhida
  fica como está e volta a valer ao religar. Não depende do Modo leve.

O foco (raio, pontos fora do foco, centro ou olho, trava) saiu na 1.14.0: no Modo leve, a densidade já cai com a distância do
olho (`desenho_na_placa`). O grupo "Pontos da nuvem" ainda tem os nós do foco; sem as propriedades dele na cena, eles não tiram
nada.

O valor vai para uma propriedade da cena (`propriedade_da_cena`), que o grupo de cada peça lê por
drivers (pontos.reduzir_na_janela, no nuvens-blender). Assim o complemento não mexe na peça, que chega vinculada da
biblioteca, nem na tomada do artista. Sem a propriedade (Blender sem o complemento, ou 100%), a peça aparece inteira. Ela
sai das cenas antes de salvar e volta logo depois: sem o complemento, a tomada abre inteira. O controle fica no Window
Manager, e a escolha do artista vai também para o arquivo (`opcoes.py`): ao abrir, os Pontos na janela voltam ao que o
arquivo guarda (num arquivo de antes, ao valor de partida).
"""
from collections.abc import Callable

import bpy

from . import dados, opcoes
from .desenho_na_placa import PROPRIEDADE_DO_BOTAO_DOS_PONTOS as BOTAO
from .desenho_na_placa import PROPRIEDADE_DOS_PONTOS_NA_JANELA as PONTOS
from .opcoes import Propriedade

LEVE = dados.modo_leve()
PROPRIEDADES = LEVE.propriedades_da_cena
TODAS = (LEVE.propriedade_da_cena, *PROPRIEDADES.values())
CONTROLES = {PONTOS: LEVE.pontos}
NO_ARQUIVO = (BOTAO, *CONTROLES)   # o que o arquivo guarda (opcoes.py)


def redesenhar() -> None:
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def grupos_com_modo_leve() -> list[bpy.types.NodeTree]:
    """Os grupos de pontos carregados (das peças vinculadas ou locais) que obedecem aos Pontos na janela."""
    return [g for g in bpy.data.node_groups if g.bl_idname == "GeometryNodeTree" and LEVE.nome_do_no in g.nodes]


def valores(gerenciador: bpy.types.WindowManager) -> dict[str, float | list[float]]:
    """O que vai para as cenas; vazio quando não há redução ou o botão está desligado."""
    if not getattr(gerenciador, BOTAO):
        return {}
    geral = gerenciador.pontos_na_janela / 100
    return {} if geral >= 1 else {LEVE.propriedade_da_cena: geral}


def _igual(guardado: object, valor: float | list[float]) -> bool:
    return (list(guardado) if hasattr(guardado, "__len__") else guardado) == valor


def gravar_nas_cenas(v: dict[str, float | list[float]]) -> None:
    """Deixa em cada cena só as propriedades de `v`, com esses valores, e avisa o Blender para refazer as peças na janela.
    Sem mudança, não avisa, para não refazer as peças à toa."""
    mudou = False
    for cena in bpy.data.scenes:
        if cena.library is not None:
            continue
        for nome in TODAS:
            if nome not in v and nome in cena:
                del cena[nome]
                mudou = True
            elif nome in v and (nome not in cena or not _igual(cena[nome], v[nome])):
                cena[nome] = v[nome]
                mudou = True
        if mudou:
            cena.update_tag()
    if not mudou:
        return
    # Propriedade gravada pelo Python não avisa o Blender sozinha. Medido sem janela em 09/11/2026: só com a cena e os grupos
    # das peças marcados o driver relê o valor a cada mudança; marcar só um dos dois não basta.
    for grupo in grupos_com_modo_leve():
        grupo.update_tag()


def aplicar() -> None:
    gravar_nas_cenas(valores(bpy.context.window_manager))
    redesenhar()


def _ao_mudar(gerenciador: bpy.types.WindowManager, _contexto: bpy.types.Context) -> None:
    opcoes.guardar(gerenciador, NO_ARQUIVO)
    aplicar()


@bpy.app.handlers.persistent
def _antes_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    gravar_nas_cenas({})


@bpy.app.handlers.persistent
def _depois_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    aplicar()


@bpy.app.handlers.persistent
def _ao_abrir(_arquivo: str, _grafo: object = None) -> None:
    """Os controles voltam ao que o arquivo aberto guarda (os valores de partida, num arquivo de antes)."""
    gerenciador = bpy.context.window_manager
    guardados = opcoes.ler(bpy.context.scene, NO_ARQUIVO)
    for nome, valor in guardados.items():
        if getattr(gerenciador, nome) != valor:
            setattr(gerenciador, nome, valor)   # o update grava nas cenas
    aplicar()


def porcentagem_em_uso(gerenciador: bpy.types.WindowManager) -> int:
    """A parte geral dos pontos que a janela desenha agora: 100 com o botão desligado."""
    return int(getattr(gerenciador, PONTOS)) if getattr(gerenciador, BOTAO) else 100


def desenhar_o_botao(layout: bpy.types.UILayout, contexto: bpy.types.Context, texto: str | None = None) -> None:
    """O botão que liga e desliga os Pontos na janela; no cabeçalho, com a parte em uso no rótulo."""
    botao = LEVE.botao_dos_pontos
    layout.prop(contexto.window_manager, BOTAO, toggle=True, icon=botao.icone,
                text=botao.nome if texto is None else texto)


def desenhar_no_cabecalho(layout: bpy.types.UILayout, contexto: bpy.types.Context) -> None:
    rotulo = LEVE.botao_dos_pontos.rotulo_no_cabecalho.format(porcentagem=porcentagem_em_uso(contexto.window_manager))
    desenhar_o_botao(layout, contexto, rotulo)


def desenhar_controles(layout: bpy.types.UILayout, contexto: bpy.types.Context) -> None:
    gerenciador = contexto.window_manager
    desenhar_o_botao(layout, contexto)
    layout = layout.column()
    layout.active = bool(getattr(gerenciador, BOTAO))
    layout.prop(gerenciador, PONTOS, slider=True)
    if not grupos_com_modo_leve():
        layout.label(text="As peças desta cena são de antes deste controle", icon="INFO")


class SALA_PT_pontos_na_janela(bpy.types.Panel):
    bl_label = "Pontos na janela"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Sala"
    bl_order = 1

    def draw(self, contexto: bpy.types.Context) -> None:
        desenhar_controles(self.layout, contexto)


UNIDADES = {PONTOS: "PERCENTAGE"}
CLASSES = (SALA_PT_pontos_na_janela,)
HANDLERS = ((bpy.app.handlers.save_pre, _antes_de_salvar), (bpy.app.handlers.save_post, _depois_de_salvar),
            (bpy.app.handlers.load_post, _ao_abrir))


def definicoes(ao_mudar: Callable[[bpy.types.WindowManager, bpy.types.Context], None] | None) -> dict[str, Propriedade]:
    """O botão e o controle que o artista escolhe e o arquivo guarda, com nome, limites e partida do dados.json."""
    botao = LEVE.botao_dos_pontos
    return {BOTAO: bpy.props.BoolProperty(name=botao.nome, description=botao.descricao, default=botao.partida, update=ao_mudar),
            **{nome: bpy.props.IntProperty(name=c.nome, subtype=UNIDADES[nome], default=c.partida, min=c.minimo, max=c.maximo,
                                           step=c.passo, update=ao_mudar, description=c.descricao + LEVE.fim_da_descricao)
               for nome, c in CONTROLES.items()}}


def _aplicar_ao_ligar() -> None:
    aplicar()


def register() -> None:
    for classe in CLASSES:
        bpy.utils.register_class(classe)
    for nome, definicao in definicoes(_ao_mudar).items():
        setattr(bpy.types.WindowManager, nome, definicao)
    for lista, funcao in HANDLERS:
        lista.append(funcao)
    # Ao ligar o complemento com um arquivo já aberto (instalar ou atualizar a extensão), nenhum load_post roda: sem isto, os
    # Pontos na janela só voltavam à cena quando o artista mexia no controle.
    bpy.app.timers.register(_aplicar_ao_ligar, first_interval=0.0)


def unregister() -> None:
    for lista, funcao in HANDLERS:
        lista.remove(funcao)
    gravar_nas_cenas({})
    for nome in NO_ARQUIVO:
        delattr(bpy.types.WindowManager, nome)
    for classe in reversed(CLASSES):
        bpy.utils.unregister_class(classe)
