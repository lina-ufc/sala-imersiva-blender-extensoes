"""Lê o bloco `modo_leve.placa` do dados.json: os valores do desenho pela placa. Sem bpy, como `dados.py`."""
import json
import sys
from dataclasses import dataclass
from pathlib import Path

from . import dados


@dataclass(frozen=True)
class Controle:
    nome: str
    descricao: str
    partida: float
    minimo: float
    maximo: float
    passo: float


@dataclass(frozen=True)
class Selo:
    texto: str
    texto_carregando: str       # com {porcentagem}
    texto_desligando: str       # com {feitas} e {total}
    altura_da_barra_px: int
    cor_da_barra: tuple[float, float, float, float]
    tamanho_px: int
    margem_px: int
    preenchimento_px: int
    cor_do_texto: tuple[float, float, float, float]
    cor_do_fundo: tuple[float, float, float, float]


@dataclass(frozen=True)
class Painel:
    aviso_do_modo: str
    aviso_da_luz: str
    linhas_maximas: int
    largura_do_texto: int       # em caracteres, para quebrar os avisos
    carregando: str
    desligando: str             # com {feitas} e {total}
    contagem_placa: str         # uma linha por estado, com {quantas}: quantas peças estão nele
    contagem_gn: str
    contagem_copias: str
    contagem_ocultas: str


@dataclass(frozen=True)
class Contorno:
    cor: tuple[float, float, float, float]
    escala_do_ponto: float      # quantas vezes o ponto da peça selecionada na silhueta, que fecha os vãos entre os pontos
    raio_px: int                # a espessura do contorno, fora da silhueta
    vao_px: int                 # vão entre pontos que não leva contorno: a distância em que a silhueta tem de aparecer em todas as direções


@dataclass(frozen=True)
class LuzDePartida:
    direcao: tuple[float, float, float]
    cor: tuple[float, float, float]
    forca: float
    ambiente: tuple[float, float, float]


@dataclass(frozen=True)
class PelaDistancia:
    cheia_ate_m: Controle         # em metros; o valor em uso é o do painel (`desenho_na_placa.pela_distancia`)
    parte_minima: Controle        # em porcentagem
    parte_perto: Controle         # em porcentagem
    antecipacao: float          # de 0 a 1: a peça recebe os pontos que o olho pediria a esta fração da distância
    pontos_por_envio: int


@dataclass(frozen=True)
class Placa:
    nome_do_grupo: str
    atributo_da_cor: str
    entrada_do_tamanho: str
    entrada_dos_pontos: str
    nome_do_botao: str
    descricao_do_botao: str
    escala_do_ponto: Controle
    nome_da_luz: str
    titulo_da_densidade: str
    descricao_da_luz: str
    pela_distancia: PelaDistancia
    memoria_maxima_mb: int                # a do sistema em que o Blender roda
    intervalo_da_carga_s: float
    espera_pelo_preparo_s: float
    intervalo_ao_desligar_s: float
    ponto_minimo_px: float
    ponto_maximo_px: float
    luzes_maximas: int
    planos_maximos: int
    ubos_em_anel: int
    luz_de_partida: LuzDePartida
    divisor_da_luz_de_ponto: float
    semente: int
    contorno: Contorno
    selo: Selo
    painel: Painel
    motivos: dict[str, str]


def _controle(t: dict) -> Controle:
    c = Controle(str(t["nome"]), str(t["descricao"]), float(t["partida"]), float(t["minimo"]), float(t["maximo"]),
                 float(t.get("passo", 0)))
    if not c.minimo <= c.partida <= c.maximo:
        raise ValueError(f"modo_leve.placa: precisa de mínimo <= partida <= máximo; veio {c}")
    return c


def _vetor(valor: object, tamanho: int) -> tuple[float, ...]:
    v = tuple(float(x) for x in valor)  # type: ignore[attr-defined]
    if len(v) != tamanho:
        raise ValueError(f"modo_leve.placa: esperava {tamanho} números; veio {valor}")
    return v


def placa(arquivo: Path = dados.ARQUIVO, sistema: str | None = None) -> Placa:
    sistema = sys.platform if sistema is None else sistema
    m = json.loads(arquivo.read_text(encoding="utf-8"))["modo_leve"]
    p = m["placa"]
    memoria = p["memoria_maxima_mb"]
    s, e = p["selo"], p["painel"]
    luz = p["luz_de_partida"]
    d = p["pela_distancia"]
    resultado = Placa(
        str(p["nome_do_grupo"]), str(p["atributo_da_cor"]), str(p["entrada_do_tamanho"]), str(p["entrada_dos_pontos"]), str(p["botao"]["nome"]),
        str(p["botao"]["descricao"]), _controle(p["escala_do_ponto"]), str(p["com_luz"]["nome"]), str(p["titulo_da_densidade"]),
        str(p["com_luz"]["descricao"]), PelaDistancia(_controle(d["cheia_ate_m"]), _controle(d["parte_minima"]), _controle(d["parte_perto"]), float(d["antecipacao"]),
                      int(d["pontos_por_envio"])), int(memoria.get(sistema, memoria["padrao"])),
        float(p["intervalo_da_carga_s"]), float(p["espera_pelo_preparo_s"]), float(p["intervalo_ao_desligar_s"]), float(p["ponto_minimo_px"]), float(p["ponto_maximo_px"]), int(p["luzes_maximas"]),
        int(p["planos_maximos"]), int(p["ubos_em_anel"]),
        LuzDePartida(_vetor(luz["direcao"], 3), _vetor(luz["cor"], 3), float(luz["forca"]), _vetor(luz["ambiente"], 3)),  # type: ignore[arg-type]
        float(p["divisor_da_luz_de_ponto"]), int(m["semente"]),
        Contorno(_vetor(p["contorno"]["cor"], 4), float(p["contorno"]["escala_do_ponto"]),
                 int(p["contorno"]["raio_px"]), int(p["contorno"]["vao_px"])),  # type: ignore[arg-type]
        Selo(str(s["texto"]), str(s["texto_carregando"]), str(s["texto_desligando"]), int(s["altura_da_barra_px"]),
             _vetor(s["cor_da_barra"], 4), int(s["tamanho_px"]), int(s["margem_px"]), int(s["preenchimento_px"]),
             _vetor(s["cor_do_texto"], 4), _vetor(s["cor_do_fundo"], 4)),  # type: ignore[arg-type]
        Painel(str(e["aviso_do_modo"]), str(e["aviso_da_luz"]), int(e["linhas_maximas"]), int(e["largura_do_texto"]), str(e["carregando"]),
               str(e["desligando"]), str(e["contagem_placa"]), str(e["contagem_gn"]), str(e["contagem_copias"]), str(e["contagem_ocultas"])),
        {str(k): str(v) for k, v in p["motivos"].items()})
    if resultado.luzes_maximas < 1 or resultado.planos_maximos < 1 or resultado.ubos_em_anel < 1:
        raise ValueError("modo_leve.placa: luzes_maximas, planos_maximos e ubos_em_anel precisam ser pelo menos 1")
    if resultado.contorno.escala_do_ponto <= 1:
        raise ValueError("modo_leve.placa.contorno: a escala do ponto precisa passar de 1, ou o contorno não aparece")
    if resultado.contorno.raio_px < 1 or resultado.contorno.vao_px < 1:
        raise ValueError("modo_leve.placa.contorno: raio_px e vao_px precisam ser pelo menos 1")
    pd = resultado.pela_distancia
    if not 0 < pd.antecipacao <= 1 or pd.pontos_por_envio < 1 or pd.cheia_ate_m.minimo <= 0 \
            or not all(0 < c.minimo <= c.maximo <= 100 for c in (pd.parte_minima, pd.parte_perto)):
        raise ValueError("modo_leve.placa.pela_distancia: antecipação entre 0 e 1, pelo menos um ponto por envio, distância positiva "
                         "e partes de longe e de perto entre 0 e 100%")
    if not 0 < resultado.ponto_minimo_px <= resultado.ponto_maximo_px:
        raise ValueError("modo_leve.placa: o ponto mínimo na tela precisa ser positivo e não passar do máximo")
    return resultado
