"""Cópia reduzida das peças com efeito no Modo leve (desde a 1.17.0).

A peça com efeito (outro modificador além do "Pontos da nuvem" ligado na janela) fica no Geometry Nodes, que relê a nuvem
inteira a cada quadro. Com o Modo leve ligado, `modo_leve` a troca na janela por uma cópia só da sessão, com a parte dos
pontos dos *Pontos nas peças com efeito* (`leve.py`), e desliga na peça todos os modificadores, com a caixa no lugar
(`display_type = 'BOUNDS'`). Esconder a peça pelo olho não basta: o Blender continua calculando os modificadores dela.

A amostra é uma malha nova, com os vértices sorteados (semente `modo_leve.semente`; a parte menor é parte da maior) e
todos os atributos de ponto da peça (posição, cor e os outros), mais o número de cada ponto na peça inteira no atributo
`atributo_do_id`, se a peça ainda não o tem: os efeitos e o `Pontos no render (%)` que sorteiam por ponto sorteiam como
na peça inteira. Ela é feita aos poucos, como o preparo da placa (`desenho_na_placa.preparar`): o sorteio vai num processo
de fundo, e a leitura da malha, que só a linha principal faz, um atributo por passo (`passo`, chamado pela carga do
`modo_leve`). Mudar o controle pede uma amostra nova; a cópia segue com a velha até a nova ficar pronta.

A cópia é `peca.copy()`, com os modificadores, os valores, a animação, os drivers, as restrições e o pai da peça, local
(sem Library Override), com a malha da amostra, fora do render e da seleção, na coleção `nome_da_colecao`, ligada à cena, e
marcada com `propriedade_da_copia` (o nome da peça). `sincronizar` deixa uma cópia por peça pedida e refaz a que ficou
diferente da peça (pilha de modificadores, valores, ação, pai, restrições) ou da amostra; apaga as outras, também as
duplicadas que um desfazer deixe. A cópia e a coleção saem antes de salvar; a amostra, sem usuário, fica na memória e não
vai para o arquivo. O que um salvamento automático gravar é apagado ao abrir (`apagar_restos`).
"""
import traceback
from collections.abc import Iterator
from concurrent.futures import Future, ThreadPoolExecutor, wait
from dataclasses import dataclass, field

import bpy
import numpy as np

from . import dados, placa_dados

LEVE = dados.modo_leve()
COPIA = LEVE.copia
ESPERA_S = placa_dados.placa().espera_pelo_preparo_s

Origem = tuple[str, int]   # a malha da peça (name_full) e quantos vértices ela tem
Assinatura = tuple[object, ...]

# Tipo de atributo: (campo do foreach, números por ponto, tipo no numpy).
_TIPOS: dict[str, tuple[str, int, type]] = {
    "FLOAT": ("value", 1, np.float32), "INT": ("value", 1, np.int32), "INT8": ("value", 1, np.int32),
    "BOOLEAN": ("value", 1, np.bool_), "FLOAT_VECTOR": ("vector", 3, np.float32), "FLOAT2": ("vector", 2, np.float32),
    "FLOAT_COLOR": ("color", 4, np.float32), "BYTE_COLOR": ("color_srgb", 4, np.float32),
    "INT32_2D": ("value", 2, np.int32), "QUATERNION": ("value", 4, np.float32)}
# Campos do modificador que não mudam o que ele faz (estado da interface, medida de tempo, o ligado na janela).
_FORA_DA_ASSINATURA = {"rna_type", "name", "execution_time", "persistent_uid", "show_viewport", "is_active"}


@dataclass
class Amostra:
    origem: Origem
    fracao: float
    malha: str                      # nome da malha reduzida, local


@dataclass
class _Preparo:
    objeto: str                     # name_full da peça
    origem: Origem
    fracao: float
    escolhidos: Future
    faltam: list[tuple[str, str]]   # (nome, tipo) dos atributos de ponto ainda por ler
    colunas: dict[str, tuple[str, np.ndarray]] = field(default_factory=dict)


_amostras: dict[str, Amostra] = {}    # pela peça (name_full)
_preparos: dict[str, _Preparo] = {}
_erros: dict[str, str] = {}
_FUNDO = ThreadPoolExecutor(max_workers=1, thread_name_prefix="copia_reduzida")


# ---- a amostra ----

def origem(objeto: bpy.types.Object) -> Origem:
    return objeto.data.name_full, len(objeto.data.vertices)


def _malha(amostra: Amostra) -> bpy.types.Mesh | None:
    malha = bpy.data.meshes.get(amostra.malha)
    return malha if malha is not None and malha.get(COPIA.propriedade_da_amostra) is not None else None


def amostra(nome: str, objeto: bpy.types.Object) -> Amostra | None:
    """A amostra pronta da peça, da malha que ela tem agora, de qualquer parte; None sem nenhuma."""
    a = _amostras.get(nome)
    if a is None or a.origem != origem(objeto) or _malha(a) is None:
        return None
    return a


def erro(nome: str) -> str | None:
    return _erros.get(nome)


def pedir(nome: str, objeto: bpy.types.Object, fracao: float) -> None:
    """Pede a amostra da peça com a parte `fracao`, se ainda não há uma pronta ou em preparo com ela."""
    o = origem(objeto)
    pronta = amostra(nome, objeto)
    if pronta is not None and pronta.fracao == fracao:
        return
    preparo = _preparos.get(nome)
    if preparo is not None and preparo.origem == o and preparo.fracao == fracao:
        return
    if nome in _erros and preparo is None and pronta is None:
        return   # falhou com esta malha; o erro fica no painel até a peça mudar ou o Modo leve religar
    _cancelar(nome)
    atributos = [(a.name, a.data_type) for a in objeto.data.attributes if a.domain == "POINT" and not a.name.startswith(".")]
    sem_tipo = [f"{n} ({t})" for n, t in atributos if t not in _TIPOS]
    if sem_tipo:
        _erros[nome] = f"atributo de ponto que a cópia reduzida não sabe copiar: {', '.join(sem_tipo)}"
        return
    _erros.pop(nome, None)
    _preparos[nome] = _Preparo(nome, o, fracao, _FUNDO.submit(_escolher, o[1], LEVE.semente, fracao), atributos)


def _escolher(total: int, semente: int, fracao: float) -> np.ndarray:
    """Fora da linha principal: os vértices sorteados, em ordem. A mesma semente dá a mesma sorte a cada vértice, então os
    escolhidos de uma parte menor estão entre os de uma maior."""
    sorte = np.random.default_rng(semente).random(total, dtype=np.float32)
    return np.flatnonzero(sorte < fracao)


def _cancelar(nome: str) -> None:
    preparo = _preparos.pop(nome, None)
    if preparo is not None:
        preparo.escolhidos.cancel()


def passo() -> bool:
    """Um passo de um preparo: espera um pouco pelo sorteio, lê um atributo da malha ou grava a amostra. Diz se uma amostra
    ficou pronta. O erro vai para o console e para o painel (`erro`)."""
    if not _preparos:
        return False
    nome, preparo = next(iter(_preparos.items()))
    objeto = _objeto(preparo.objeto)
    if objeto is None or objeto.type != "MESH" or origem(objeto) != preparo.origem:
        _cancelar(nome)   # a peça sumiu ou trocou de malha; a classificação pede de novo
        return False
    if not preparo.escolhidos.done():
        wait([preparo.escolhidos], timeout=ESPERA_S)   # o processo de fundo só anda enquanto a linha principal espera
        return False
    try:
        escolhidos = preparo.escolhidos.result()
        if preparo.faltam:
            atributo, tipo = preparo.faltam.pop(0)
            preparo.colunas[atributo] = (tipo, _ler(objeto.data, atributo, tipo, escolhidos))
            return False
        _gravar(nome, objeto, preparo, escolhidos)
    except Exception as e:   # noqa: BLE001  (o erro vai para o painel e para o console; a peça fica inteira)
        traceback.print_exc()
        _erros[nome] = f"{type(e).__name__}: {e}"
        _cancelar(nome)
        return True
    _cancelar(nome)
    return True


def _objeto(nome_completo: str) -> bpy.types.Object | None:
    return next((o for o in bpy.data.objects if o.name_full == nome_completo), None)


def _ler(malha: bpy.types.Mesh, atributo: str, tipo: str, escolhidos: np.ndarray) -> np.ndarray:
    campo, por_ponto, numpy = _TIPOS[tipo]
    tudo = np.empty(len(malha.vertices) * por_ponto, numpy)
    malha.attributes[atributo].data.foreach_get(campo, tudo)
    return tudo.reshape(-1, por_ponto)[escolhidos].ravel()


def _gravar(nome: str, objeto: bpy.types.Object, preparo: _Preparo, escolhidos: np.ndarray) -> None:
    malha = bpy.data.meshes.new(COPIA.nome_da_copia.format(peca=objeto.name))
    malha.vertices.add(len(escolhidos))
    for atributo, (tipo, valores) in preparo.colunas.items():
        destino = malha.attributes.get(atributo) if atributo == "position" else malha.attributes.new(atributo, tipo, "POINT")
        destino.data.foreach_set(_TIPOS[tipo][0], valores)
    if COPIA.atributo_do_id not in preparo.colunas:
        malha.attributes.new(COPIA.atributo_do_id, "INT", "POINT").data.foreach_set("value", escolhidos.astype(np.int32))
    for material in objeto.data.materials:
        malha.materials.append(material)
    malha[COPIA.propriedade_da_amostra] = nome
    malha.update()
    velha = _amostras.get(nome)
    _amostras[nome] = Amostra(preparo.origem, preparo.fracao, malha.name)
    if velha is not None and velha.malha != malha.name:
        _apagar_a_malha(velha.malha)


def _apagar_a_malha(nome: str) -> None:
    malha = bpy.data.meshes.get(nome)
    if malha is not None and malha.get(COPIA.propriedade_da_amostra) is not None and malha.users == 0:
        bpy.data.meshes.remove(malha)
    # Com usuário (uma cópia ainda a usa), a malha sai com a cópia: `sincronizar` troca a cópia e a apaga depois.


def esquecer(nome: str) -> None:
    """Solta a amostra, o preparo e o erro da peça (malha mexida, ou a parte voltou a 100%)."""
    _cancelar(nome)
    _erros.pop(nome, None)
    velha = _amostras.pop(nome, None)
    if velha is not None:
        tirar(nome)
        _apagar_a_malha(velha.malha)


def esquecer_tudo() -> None:
    for nome in list(_preparos):
        _cancelar(nome)
    _erros.clear()
    apagar_copias()
    for velha in _amostras.values():
        _apagar_a_malha(velha.malha)
    _amostras.clear()


# ---- a cópia ----

def e_copia(objeto: bpy.types.Object) -> bool:
    return objeto.get(COPIA.propriedade_da_copia) is not None


def _colecao(criar: bool) -> bpy.types.Collection | None:
    colecao = bpy.data.collections.get(COPIA.nome_da_colecao)
    if colecao is not None and colecao.get(COPIA.propriedade_da_copia) is None:
        raise ValueError(f"o arquivo já tem uma coleção {COPIA.nome_da_colecao!r} que não é do Modo leve; renomeie-a")
    if colecao is None and criar:
        colecao = bpy.data.collections.new(COPIA.nome_da_colecao)
        colecao[COPIA.propriedade_da_copia] = True
        colecao.hide_select = True
        colecao.hide_render = True
    if colecao is not None and criar and colecao.name not in bpy.context.scene.collection.children:
        bpy.context.scene.collection.children.link(colecao)
    return colecao


def _copias() -> Iterator[bpy.types.Object]:
    colecao = _colecao(criar=False)
    if colecao is not None:
        yield from [o for o in colecao.objects if e_copia(o)]


def _apagar(copia: bpy.types.Object) -> None:
    malha = copia.data
    bpy.data.objects.remove(copia)
    if malha.users == 0 and not any(a.malha == malha.name for a in _amostras.values()):
        bpy.data.meshes.remove(malha)   # amostra substituída por uma nova


def tirar(nome: str) -> None:
    """Apaga a cópia da peça, se houver; a amostra fica para a próxima."""
    for copia in [c for c in _copias() if c[COPIA.propriedade_da_copia] == nome]:
        _apagar(copia)


def apagar_copias() -> None:
    """Apaga todas as cópias e a coleção delas (antes de salvar e ao desligar); as amostras ficam."""
    for copia in list(_copias()):
        _apagar(copia)
    colecao = _colecao(criar=False)
    if colecao is not None:
        bpy.data.collections.remove(colecao)


def apagar_restos() -> None:
    """Ao abrir um arquivo: apaga as cópias, a coleção e as amostras que um salvamento automático tenha gravado, e esquece as
    da sessão anterior."""
    for nome in list(_preparos):
        _cancelar(nome)
    _amostras.clear()
    _erros.clear()
    for copia in [o for o in bpy.data.objects if e_copia(o)]:
        bpy.data.objects.remove(copia)
    for colecao in [c for c in bpy.data.collections if c.get(COPIA.propriedade_da_copia) is not None]:
        bpy.data.collections.remove(colecao)
    for malha in [m for m in bpy.data.meshes if m.get(COPIA.propriedade_da_amostra) is not None and m.users == 0]:
        bpy.data.meshes.remove(malha)


def _valor(v: object) -> object:
    if isinstance(v, bpy.types.ID):
        return v.name_full
    if isinstance(v, str | int | float | bool) or v is None:
        return v
    return tuple(v)   # vetor, cor, matriz em linha


def _campos_do_modificador(modificador: bpy.types.Modifier) -> tuple[object, ...]:
    if modificador.type == "NODES":
        # Grupo sem entradas (o "Pontos da nuvem" antigo do avião): o Blender dá NodesModifierPropertiesEmpty, sem `inputs`.
        entradas = getattr(modificador.properties, "inputs", None)
        if entradas is None:
            return (_valor(modificador.node_group),)
        return (_valor(modificador.node_group),
                *((p.identifier, _valor(getattr(getattr(entradas, p.identifier), "value", None)),
                   getattr(getattr(entradas, p.identifier), "attribute_name", ""))
                  for p in entradas.bl_rna.properties if p.identifier not in ("rna_type", "name")))
    return tuple((p.identifier, _valor(getattr(modificador, p.identifier))) for p in modificador.bl_rna.properties
                 if p.identifier not in _FORA_DA_ASSINATURA and p.type in ("BOOLEAN", "INT", "FLOAT", "ENUM", "STRING", "POINTER")
                 and not p.identifier.startswith(("show_", "open_", "is_")) and (p.type != "POINTER" or isinstance(
                     getattr(modificador, p.identifier), bpy.types.ID | None)))


def assinatura(objeto: bpy.types.Object) -> Assinatura:
    """O que a cópia herda da peça e muda o desenho dela, menos a malha e o ligado na janela de cada modificador."""
    animacao = objeto.animation_data
    return (tuple((m.name, m.type, _campos_do_modificador(m)) for m in objeto.modifiers),
            _valor(animacao.action) if animacao is not None else None,
            _valor(objeto.parent), tuple((c.name, c.type, c.mute) for c in objeto.constraints))


def _criar(peca: bpy.types.Object, malha: bpy.types.Mesh, ligar: frozenset[str], display: str) -> None:
    copia = peca.copy()
    if copia.override_library is not None:
        copia.make_local(clear_liboverride=True)
    copia.name = COPIA.nome_da_copia.format(peca=peca.name)
    copia.data = malha
    copia[COPIA.propriedade_da_copia] = peca.name_full
    copia.hide_render = True
    copia.hide_select = True
    copia.display_type = display
    for modificador in copia.modifiers:
        modificador.show_viewport = modificador.name in ligar
    colecao = _colecao(criar=True)
    assert colecao is not None
    colecao.objects.link(copia)


@dataclass(frozen=True)
class Pedido:
    """Uma peça que deve ter cópia: os modificadores a ligar nela (os que a peça tinha ligados) e o *Display As* de antes."""
    peca: bpy.types.Object
    ligar: frozenset[str]
    display: str


def sincronizar(pedidos: dict[str, Pedido]) -> None:
    """Deixa exatamente uma cópia atual por peça de `pedidos` e nenhuma das outras."""
    ficam: set[str] = set()
    for copia in list(_copias()):
        nome = copia[COPIA.propriedade_da_copia]
        pedido = pedidos.get(nome)
        a = _amostras.get(nome)
        if pedido is None or nome in ficam or a is None or copia.data.name != a.malha \
                or assinatura(copia) != assinatura(pedido.peca):
            _apagar(copia)
            continue
        ficam.add(nome)
    for nome, pedido in pedidos.items():
        if nome in ficam:
            continue
        a = amostra(nome, pedido.peca)
        malha = None if a is None else _malha(a)
        if malha is None:
            raise ValueError(f"{nome}: pedida a cópia reduzida sem amostra pronta")
        _criar(pedido.peca, malha, pedido.ligar, pedido.display)
    colecao = _colecao(criar=False)
    if colecao is not None and not colecao.objects:
        bpy.data.collections.remove(colecao)
