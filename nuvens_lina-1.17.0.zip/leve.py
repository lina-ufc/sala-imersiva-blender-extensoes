"""Pontos nas peças com efeito: com o Modo leve ligado, a parte dos pontos da cópia reduzida que a janela 3D desenha no lugar
de cada peça com efeito (`copia_reduzida.py`, desde a 1.17.0). As peças sem efeito vão pela placa (`modo_leve.py`), com a
densidade pela distância. Em 100%, as peças com efeito ficam inteiras, sem cópia. Com o Modo leve desligado, nada é
reduzido: a janela mostra tudo como no render. O render (F12, render.py e Renderizar a fita, do visor) nunca muda: lá vale
só a entrada `Pontos no render (%)` de cada peça.

O controle, com nome, limites e valor de partida no dados.json (`modo_leve.pontos`), fica no painel do Modo leve. Até a 1.14,
eram os *Pontos na janela*, com botão próprio no cabeçalho e valendo também sem o Modo leve; a propriedade do Window Manager
manteve o nome (`pontos_na_janela`), para o valor guardado nos arquivos continuar valendo. Mudar o valor avisa o Modo leve
(`ao_mudar_os_pontos`), que refaz as cópias.

Até a 1.16, o valor ia para uma propriedade da cena (`propriedade_da_cena`), que o grupo "Pontos da nuvem" lia por um driver
para reduzir a peça na janela. Com a cópia reduzida, essa redução dobraria (a cópia sairia com a parte da parte): o
complemento não grava mais a propriedade e a apaga das cenas onde ela ainda estiver (arquivos antigos), junto com as
propriedades do foco (`propriedades_da_cena`), que a 1.13 gravava. Sem ela, o grupo deixa a peça inteira. A escolha do
artista vai para o arquivo (`opcoes.py`).
"""
from collections.abc import Callable

import bpy

from . import dados, opcoes
from .desenho_na_placa import PROPRIEDADE_DOS_PONTOS_NA_JANELA as PONTOS
from .opcoes import Propriedade

LEVE = dados.modo_leve()
PROPRIEDADES = LEVE.propriedades_da_cena
ANTIGAS = (LEVE.propriedade_da_cena, *PROPRIEDADES.values())
CONTROLES = {PONTOS: LEVE.pontos}
NO_ARQUIVO = tuple(CONTROLES)   # o que o arquivo guarda (opcoes.py)
# Quem a mudança do controle avisa (o `modo_leve` põe aqui o `reclassificar`, que refaz as cópias).
ao_mudar_os_pontos: Callable[[], None] | None = None


def redesenhar() -> None:
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def fracao_das_copias(gerenciador: bpy.types.WindowManager) -> float:
    """A parte dos pontos da cópia reduzida, de 0 a 1; 1 é sem cópia."""
    return getattr(gerenciador, PONTOS) / 100


def apagar_das_cenas() -> None:
    """Apaga das cenas do arquivo as propriedades que as versões até a 1.16 gravavam. O driver do grupo dos pontos só relê o
    valor com a cena e o grupo marcados (medido sem janela em 09/11/2026), então os dois são avisados."""
    mudou = False
    for cena in bpy.data.scenes:
        if cena.library is not None:
            continue
        for nome in [n for n in ANTIGAS if n in cena]:
            del cena[nome]
            cena.update_tag()
            mudou = True
    if not mudou:
        return
    for grupo in bpy.data.node_groups:
        if grupo.bl_idname == "GeometryNodeTree" and LEVE.nome_do_no in grupo.nodes:
            grupo.update_tag()
    redesenhar()


def _ao_mudar(gerenciador: bpy.types.WindowManager, _contexto: bpy.types.Context) -> None:
    opcoes.guardar(gerenciador, NO_ARQUIVO)
    if ao_mudar_os_pontos is not None:
        ao_mudar_os_pontos()


@bpy.app.handlers.persistent
def _ao_abrir(_arquivo: str, _grafo: object = None) -> None:
    """Os controles voltam ao que o arquivo aberto guarda (os valores de partida, num arquivo de antes)."""
    gerenciador = bpy.context.window_manager
    guardados = opcoes.ler(bpy.context.scene, NO_ARQUIVO)
    for nome, valor in guardados.items():
        if getattr(gerenciador, nome) != valor:
            setattr(gerenciador, nome, valor)
    apagar_das_cenas()


def desenhar_controles(layout: bpy.types.UILayout, contexto: bpy.types.Context) -> None:
    layout.prop(contexto.window_manager, PONTOS, slider=True)


UNIDADES = {PONTOS: "PERCENTAGE"}
HANDLERS = ((bpy.app.handlers.load_post, _ao_abrir),)


def definicoes(ao_mudar: Callable[[bpy.types.WindowManager, bpy.types.Context], None] | None) -> dict[str, Propriedade]:
    """O controle que o artista escolhe e o arquivo guarda, com nome, limites e partida do dados.json."""
    return {nome: bpy.props.IntProperty(name=c.nome, subtype=UNIDADES[nome], default=c.partida, min=c.minimo, max=c.maximo,
                                        step=c.passo, update=ao_mudar, description=c.descricao + LEVE.fim_da_descricao)
            for nome, c in CONTROLES.items()}


def _apagar_ao_ligar() -> None:
    apagar_das_cenas()


def register() -> None:
    for nome, definicao in definicoes(_ao_mudar).items():
        setattr(bpy.types.WindowManager, nome, definicao)
    for lista, funcao in HANDLERS:
        lista.append(funcao)
    # Ao ligar o complemento com um arquivo já aberto (instalar ou atualizar a extensão), nenhum load_post roda.
    bpy.app.timers.register(_apagar_ao_ligar, first_interval=0.0)


def unregister() -> None:
    for lista, funcao in HANDLERS:
        lista.remove(funcao)
    for nome in NO_ARQUIVO:
        delattr(bpy.types.WindowManager, nome)
