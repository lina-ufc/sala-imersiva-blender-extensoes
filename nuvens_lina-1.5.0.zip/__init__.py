"""Complemento do Blender do Filme da Nuvem. Cada parte é um módulo com register e unregister:

- ao_soltar: a coleção marcada (a Sala) chega liberada com Library Override quando é solta do Asset Browser.
- visor: o visor da sala, com as cinco telas lado a lado, como a projeção recebe.
- marcas: as arestas da sala, a letra de cada parede e o teto, desenhados por cima da vista do olho do visor.

Uma parte nova (por exemplo a trava das tomadas no Gitea) entra como outro módulo nesta lista.
"""
from . import ao_soltar, marcas, visor

PARTES = (ao_soltar, visor, marcas)


def register() -> None:
    for parte in PARTES:
        parte.register()


def unregister() -> None:
    for parte in reversed(PARTES):
        parte.unregister()
