"""Pontos na janela: a janela 3D desenha só uma parte dos pontos das nuvens, para navegar e tocar a animação mais rápido; o
render (F12, render.py e Renderizar a fita, do visor) não muda: lá vale só a entrada `Pontos no render (%)` de cada peça.
O visor ao vivo, desenhado como a 3D View, mostra os mesmos pontos que ela.

Os controles, com nomes, limites e valores de partida no dados.json (`modo_leve`), ficam na aba Sala e no menu ao lado do
botão Modo leve (`modo_leve.py`), no cabeçalho da 3D View:
- Pontos na janela (%): a parte geral, em tudo (também nas peças que o Modo leve desenha pela placa); em 100%, sem redução.
- Raio do foco (m): dentro dessa distância do foco, a janela não tira pontos; 0 desliga o foco.
- Pontos fora do foco (%): além do raio, a parte desce, suave, numa faixa de `faixa_de_transicao_m`, até esse valor, que
  nunca passa dos Pontos na janela; em 0, só o foco aparece.
- Travar foco: congela o foco onde está, para o artista se afastar e olhar o mesmo lugar de longe.

O foco é o centro em torno do qual a vista gira (`view_location`), não o olho, a câmera da cena ou as da sala. Vale a 3D View
em que o artista mexeu por último. O grupo "Pontos da nuvem" não sabe onde ela está: um timer lê o
centro a cada `intervalo_do_foco_s` e, quando ele mudou e ficou parado por `espera_do_foco_s`, grava-o na cena. Girar a vista
não muda o centro, e nada é refeito; arrastá-la para o lado, Frame Selected ou zoom ao ponto refazem as peças quando ela para.

Os valores vão para propriedades da cena (`propriedade_da_cena` e `propriedades_da_cena`), que o grupo de cada peça lê por
drivers (pontos.reduzir_na_janela, no nuvens-blender). Assim o complemento não mexe na peça, que chega vinculada da
biblioteca, nem na tomada do artista. Sem as propriedades (Blender sem o complemento, ou 100% e foco desligado), a peça
aparece inteira. Essas propriedades saem das cenas antes de salvar e voltam logo depois: sem o complemento, a tomada abre
inteira. Os controles ficam no Window Manager, e a escolha do artista vai também para o arquivo (`opcoes.py`): ao abrir,
os Pontos na janela, o Raio do foco e os Pontos fora do foco voltam ao que o arquivo guarda (num arquivo de antes, aos
valores de partida). O lugar do foco e a trava não vão para o arquivo; a trava segue na sessão, como o foco travado.
"""
import time
from collections.abc import Callable

import bpy
from mathutils import Matrix, Vector

from . import dados, opcoes
from .opcoes import Propriedade

LEVE = dados.modo_leve()
PROPRIEDADES = LEVE.propriedades_da_cena
TODAS = (LEVE.propriedade_da_cena, *PROPRIEDADES.values())
CONTROLES = {"pontos_na_janela": LEVE.pontos, "raio_do_foco_m": LEVE.raio_do_foco_m,
             "pontos_fora_do_foco": LEVE.pontos_fora_do_foco}


def redesenhar() -> None:
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def grupos_com_modo_leve() -> list[bpy.types.NodeTree]:
    """Os grupos de pontos carregados (das peças vinculadas ou locais) que obedecem aos Pontos na janela."""
    return [g for g in bpy.data.node_groups if g.bl_idname == "GeometryNodeTree" and LEVE.nome_do_no in g.nodes]


# O foco gravado na cena, o último centro lido e desde quando ele está parado, a 3D View em que o artista mexeu por último e
# a última vista de cada 3D View, para saber em qual ele mexeu.
_foco: dict = {"gravado": None, "lido": None, "desde": 0.0, "area": None, "vistas": {}}


def _vistas_3d() -> list[bpy.types.Area]:
    return [area for janela in bpy.context.window_manager.windows for area in janela.screen.areas if area.type == "VIEW_3D"]


def centro_da_vista() -> Vector | None:
    """O centro da 3D View em que o artista mexeu por último (a maior, se ele não mexeu em nenhuma); None sem 3D View."""
    areas = _vistas_3d()
    if not areas:
        return None
    vistas: dict[int, Matrix] = _foco["vistas"]
    for area in areas:
        chave, matriz = area.as_pointer(), area.spaces.active.region_3d.view_matrix.copy()
        if chave in vistas and vistas[chave] != matriz:
            _foco["area"] = chave
        vistas[chave] = matriz
    escolhida = next((a for a in areas if a.as_pointer() == _foco["area"]), None)
    if escolhida is None:
        escolhida = max(areas, key=lambda a: a.width * a.height)
    return escolhida.spaces.active.region_3d.view_location.copy()


def valores(gerenciador: bpy.types.WindowManager) -> dict[str, float | list[float]]:
    """O que vai para as cenas; vazio quando não há redução."""
    geral = gerenciador.pontos_na_janela / 100
    if gerenciador.raio_do_foco_m <= 0:
        return {} if geral >= 1 else {LEVE.propriedade_da_cena: geral}
    if _foco["gravado"] is None:
        _foco["gravado"] = centro_da_vista()
    if _foco["gravado"] is None:
        return {LEVE.propriedade_da_cena: geral}
    raio = float(gerenciador.raio_do_foco_m)
    return {LEVE.propriedade_da_cena: 1.0,
            PROPRIEDADES["fracao_fora_do_foco"]: min(gerenciador.pontos_fora_do_foco / 100, geral),
            PROPRIEDADES["raio_do_foco_m"]: raio,
            PROPRIEDADES["fim_da_transicao_m"]: raio + LEVE.faixa_de_transicao_m,
            PROPRIEDADES["foco"]: list(_foco["gravado"])}


def _igual(guardado: object, valor: float | list[float]) -> bool:
    return (list(guardado) if hasattr(guardado, "__len__") else guardado) == valor


def gravar_nas_cenas(v: dict[str, float | list[float]]) -> None:
    """Deixa em cada cena só as propriedades de `v`, com esses valores, e avisa o Blender para refazer as peças na janela.
    Sem mudança, não avisa, para não refazer as peças à toa."""
    mudou = False
    for cena in bpy.data.scenes:
        if cena.library is not None:
            continue
        for nome in TODAS:
            if nome not in v and nome in cena:
                del cena[nome]
                mudou = True
            elif nome in v and (nome not in cena or not _igual(cena[nome], v[nome])):
                cena[nome] = v[nome]
                mudou = True
        if mudou:
            cena.update_tag()
    if not mudou:
        return
    # Propriedade gravada pelo Python não avisa o Blender sozinha. Medido sem janela em 09/11/2026: só com a cena e os grupos
    # das peças marcados o driver relê o valor a cada mudança; marcar só um dos dois não basta.
    for grupo in grupos_com_modo_leve():
        grupo.update_tag()


def aplicar() -> None:
    gravar_nas_cenas(valores(bpy.context.window_manager))
    redesenhar()


def _seguir_o_foco() -> float:
    gerenciador = bpy.context.window_manager
    if gerenciador is None or gerenciador.raio_do_foco_m <= 0 or gerenciador.travar_foco:
        return LEVE.intervalo_do_foco_s
    centro = centro_da_vista()
    if centro is None:
        return LEVE.intervalo_do_foco_s
    instante = time.monotonic()
    if _foco["lido"] is None or _foco["lido"] != centro:
        _foco["lido"], _foco["desde"] = centro, instante
    parado = instante - _foco["desde"] >= LEVE.espera_do_foco_s
    if parado and _foco["gravado"] != centro:
        _foco["gravado"] = centro
        aplicar()
    return LEVE.intervalo_do_foco_s


# A trava do foco não vai para o arquivo (o lugar do foco também não): a sessão a guarda para devolvê-la ao abrir outro.
_na_sessao: dict[str, bool] = {}


def _ao_mudar(gerenciador: bpy.types.WindowManager, _contexto: bpy.types.Context) -> None:
    _na_sessao["travar_foco"] = gerenciador.travar_foco
    opcoes.guardar(gerenciador, CONTROLES)
    aplicar()


@bpy.app.handlers.persistent
def _antes_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    gravar_nas_cenas({})


@bpy.app.handlers.persistent
def _depois_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    aplicar()


@bpy.app.handlers.persistent
def _ao_abrir(_arquivo: str, _grafo: object = None) -> None:
    """Os controles voltam ao que o arquivo aberto guarda (os valores de partida, num arquivo de antes). O foco travado fica
    onde estava; o solto é lido de novo."""
    gerenciador = bpy.context.window_manager
    guardados = {**opcoes.ler(bpy.context.scene, CONTROLES), **_na_sessao}
    _foco.update(lido=None, area=None, vistas={})
    if not _na_sessao.get("travar_foco"):
        _foco["gravado"] = None
    for nome, valor in guardados.items():
        if getattr(gerenciador, nome) != valor:
            setattr(gerenciador, nome, valor)   # o update grava nas cenas
    aplicar()


def desenhar_controles(layout: bpy.types.UILayout, contexto: bpy.types.Context) -> None:
    gerenciador = contexto.window_manager
    layout.prop(gerenciador, "pontos_na_janela", slider=True)
    layout.prop(gerenciador, "raio_do_foco_m")
    ligado = gerenciador.raio_do_foco_m > 0
    coluna = layout.column()
    coluna.active = ligado
    coluna.prop(gerenciador, "pontos_fora_do_foco", slider=True)
    coluna.prop(gerenciador, "travar_foco", icon="LOCKED" if gerenciador.travar_foco else "UNLOCKED")
    if not ligado:
        layout.label(text="Foco desligado: raio 0", icon="INFO")
    if not grupos_com_modo_leve():
        layout.label(text="As peças desta cena são de antes deste controle", icon="INFO")
    elif ligado and not any(PROPRIEDADES["foco"] in g.nodes for g in grupos_com_modo_leve()):
        layout.label(text="As peças desta cena são de antes do foco", icon="INFO")


class SALA_PT_pontos_na_janela(bpy.types.Panel):
    bl_label = "Pontos na janela"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Sala"
    bl_order = 1

    def draw(self, contexto: bpy.types.Context) -> None:
        desenhar_controles(self.layout, contexto)


UNIDADES = {"pontos_na_janela": "PERCENTAGE", "pontos_fora_do_foco": "PERCENTAGE", "raio_do_foco_m": "NONE"}
CLASSES = (SALA_PT_pontos_na_janela,)
HANDLERS = ((bpy.app.handlers.save_pre, _antes_de_salvar), (bpy.app.handlers.save_post, _depois_de_salvar),
            (bpy.app.handlers.load_post, _ao_abrir))


def definicoes(ao_mudar: Callable[[bpy.types.WindowManager, bpy.types.Context], None] | None) -> dict[str, Propriedade]:
    """Os controles que o artista escolhe e o arquivo guarda (sem a trava do foco), com nome, limites e partida do dados.json."""
    return {nome: bpy.props.IntProperty(name=c.nome, subtype=UNIDADES[nome], default=c.partida, min=c.minimo, max=c.maximo,
                                        step=c.passo, update=ao_mudar, description=c.descricao + LEVE.fim_da_descricao)
            for nome, c in CONTROLES.items()}


def register() -> None:
    for classe in CLASSES:
        bpy.utils.register_class(classe)
    for nome, definicao in definicoes(_ao_mudar).items():
        setattr(bpy.types.WindowManager, nome, definicao)
    bpy.types.WindowManager.travar_foco = bpy.props.BoolProperty(
        name=LEVE.nome_da_trava, default=False, update=_ao_mudar,
        description=LEVE.descricao_da_trava)
    for lista, funcao in HANDLERS:
        lista.append(funcao)
    bpy.app.timers.register(_seguir_o_foco, first_interval=LEVE.intervalo_do_foco_s, persistent=True)


def unregister() -> None:
    if bpy.app.timers.is_registered(_seguir_o_foco):
        bpy.app.timers.unregister(_seguir_o_foco)
    for lista, funcao in HANDLERS:
        lista.remove(funcao)
    gravar_nas_cenas({})
    del bpy.types.WindowManager.travar_foco
    for nome in CONTROLES:
        delattr(bpy.types.WindowManager, nome)
    for classe in reversed(CLASSES):
        bpy.utils.unregister_class(classe)
