"""Modo leve: as nuvens desenhadas direto pela placa de vídeo, só na janela.

O botão *Modo leve* (cabeçalho da 3D View e aba Sala, desligado ao começar) reúne os *Pontos na janela* (`leve.py`, no menu
ao lado do botão) e o desenho pela placa (`desenho_na_placa.py`). O botão e os controles ficam no Window Manager, e a escolha
do artista vai também para o `.blend` (`opcoes.py`): ao abrir o arquivo, o Modo leve religa se estava ligado. O que o
complemento muda nas peças não vai: é devolvido antes de salvar. O render (F12, `render.py`, Renderizar a fita) nunca muda:
lá só vale o Geometry Nodes, com todos os efeitos.

Cada peça (objeto com o modificador "Pontos da nuvem") é classificada:
- só com o "Pontos da nuvem" ligado na janela: vai para a placa, depois de enviada;
- com outro modificador ligado na janela (efeito): fica no Geometry Nodes. Quando os efeitos da biblioteca chegarem à placa
  (`efeitos_na_placa.efeitos_da_peca`), é aqui, em `_efeito_que_a_placa_nao_faz`, que a peça com só esses efeitos passa a ir;
- em modo de edição, escondida pelo artista ou mexida à mão: fica no Geometry Nodes.

Tirar a peça do desenho do Blender depende de ela ser editável. Liberada (Library Override) ou local: `show_viewport` do
"Pontos da nuvem" desligado e `display_type = 'BOUNDS'`; ela continua selecionável e se move como sempre. Só vinculada: o
Blender não deixa mexer no modificador, então o olho dela fecha (`hide_set`). O complemento guarda só o que mudou. Se o
artista mexer à mão no olho, no modificador ou no jeito de mostrar a peça, ela sai do cuidado do Modo leve até o botão ser
desligado e ligado de novo.

A peça só vinculada selecionada por clique (`selecao_na_placa`) volta ao Geometry Nodes enquanto estiver selecionada: a seleção
abre o olho dela e a declara em `devolvidas_ao_geometry_nodes()`; aqui ela deixa de ser "mexida à mão" e de ir à placa (motivo
`selecionada`), e ao perder a seleção volta à placa e o olho fecha de novo. Só este módulo fecha o olho. Enquanto o Geometry
Nodes a desenha, ela segue numerada na textura da seleção (`Entrada.so_na_selecao`), para o clique achá-la e não a peça atrás.

O que muda nas peças é devolvido antes de salvar (`save_pre`) e refeito depois (`save_post`), ao abrir outro arquivo
(`load_post`, porque o salvamento automático não chama `save_pre` e grava o estado aplicado), ao desligar e ao descarregar o
complemento. Depois de desfazer ou refazer (`undo_post`, `redo_post`) as referências aos objetos morrem: os objetos são
buscados de novo, e o que o desfazer voltou é aplicado outra vez, senão a peça sairia duas vezes.
"""
import traceback
from collections.abc import Callable
from dataclasses import dataclass

import blf
import bpy
import gpu
from gpu_extras.batch import batch_for_shader

from . import ao_vivo, desenho_na_placa, leve, opcoes, selecao_na_placa
from .desenho_na_placa import Entrada
from .opcoes import Propriedade

PLACA = desenho_na_placa.PLACA
PROPRIEDADE_DO_BOTAO = desenho_na_placa.PROPRIEDADE_DO_BOTAO
CONTROLES = (desenho_na_placa.PROPRIEDADE_DO_TETO, desenho_na_placa.PROPRIEDADE_DA_ESCALA, desenho_na_placa.PROPRIEDADE_DA_LUZ)


@dataclass
class Peca:
    """O que o Modo leve sabe de uma peça."""
    nome: str                       # name_full do objeto
    objeto: bpy.types.Object
    modo: str                       # "override" (editável: local ou liberada) ou "vinculada"
    aplicado: bool = False          # o complemento tirou a peça do desenho do Blender
    do_artista: bool = False        # o artista mexeu à mão depois: fora do cuidado até religar
    original_modificador: bool = True
    original_display: str = "TEXTURED"
    original_oculto: bool = False
    destino: str = "gn"             # "placa" ou "gn"
    motivo: str = "carregando"      # chave de PLACA.motivos
    detalhe: str = ""               # o modificador do efeito ou o erro
    visivel: bool = True
    tamanho_cm: float = 0.0
    fracao: float = 1.0


@dataclass
class _Estado:
    ligado: bool = False
    pecas: dict[str, Peca] = None   # type: ignore[assignment]
    ocupado: bool = False
    com_handlers: bool = False


_M = _Estado(pecas={})
# O "Outline Selected" de cada 3D View, como o artista o deixou, enquanto o complemento o desliga (ver `_contorno_do_blender`).
_contorno_guardado: dict[int, bool] = {}
_identificadores: dict[str, dict[str, str]] = {}   # grupo de nós -> nome da entrada -> identificador no modificador
_desenhos: list[tuple[type, object]] = []


# ---- o que é uma peça ----

def _modificador_dos_pontos(objeto: bpy.types.Object) -> bpy.types.NodesModifier | None:
    for modificador in objeto.modifiers:
        if modificador.type == "NODES" and modificador.node_group is not None \
                and modificador.node_group.name.startswith(PLACA.nome_do_grupo):
            return modificador
    return None


def _entrada(modificador: bpy.types.NodesModifier, nome: str) -> float | None:
    """O valor de uma entrada do modificador pelo nome que o artista vê; None se o grupo não tem a entrada (peça de antes)."""
    grupo = modificador.node_group
    tabela = _identificadores.get(grupo.name_full)
    if tabela is None:
        tabela = _identificadores[grupo.name_full] = {
            i.name: i.identifier for i in grupo.interface.items_tree if i.item_type == "SOCKET" and i.in_out == "INPUT"}
    identificador = tabela.get(nome)
    if identificador is None:
        return None
    entrada = getattr(modificador.properties.inputs, identificador, None)
    return None if entrada is None else float(entrada.value)


def _efeito_que_a_placa_nao_faz(objeto: bpy.types.Object, dos_pontos: bpy.types.Modifier) -> str | None:
    """O nome do primeiro modificador, além do "Pontos da nuvem", ligado na janela; None se a peça não tem efeito. Os efeitos
    da biblioteca ainda não vão pela placa: quando forem, `efeitos_na_placa.efeitos_da_peca(objeto)` (hoje levanta
    NotImplementedError) decide aqui quais a placa faz, e só os outros contam."""
    for modificador in objeto.modifiers:
        if modificador != dos_pontos and modificador.show_viewport:
            return modificador.name
    return None


def _colecoes_escondidas(camada: bpy.types.ViewLayer) -> set[str]:
    """Os nomes das coleções que o olho ou a tela da coleção escondem na janela, herdado pelas filhas."""
    escondidas: set[str] = set()

    def descer(no: bpy.types.LayerCollection, pai_escondido: bool) -> None:
        escondida = pai_escondido or no.hide_viewport or no.collection.hide_viewport
        if escondida:
            escondidas.add(no.collection.name_full)
        for filho in no.children:
            descer(filho, escondida)

    descer(camada.layer_collection, False)
    return escondidas


def _aparece(objeto: bpy.types.Object, peca: Peca | None, escondidas: set[str]) -> bool:
    """Se o artista veria a peça na janela. A peça vinculada que o complemento escondeu não pode perguntar ao Blender."""
    if peca is not None and peca.aplicado and peca.modo == "vinculada":
        return not objeto.hide_viewport and any(c.name_full not in escondidas for c in objeto.users_collection)
    return objeto.visible_get()


# ---- tirar e devolver a peça ----

def _parece_aplicado(peca: Peca) -> bool:
    objeto = peca.objeto
    if peca.modo == "vinculada":
        return objeto.hide_get()
    modificador = _modificador_dos_pontos(objeto)
    return modificador is not None and not modificador.show_viewport and objeto.display_type == "BOUNDS"


def _aplicar(peca: Peca, modificador: bpy.types.Modifier) -> None:
    if peca.aplicado:
        return
    objeto = peca.objeto
    if peca.modo == "override":
        peca.original_modificador, peca.original_display = modificador.show_viewport, objeto.display_type
        modificador.show_viewport = False
        objeto.display_type = "BOUNDS"
    else:
        peca.original_oculto = objeto.hide_get()
        objeto.hide_set(True)
    peca.aplicado = True


def _devolver(peca: Peca) -> None:
    if not peca.aplicado:
        return
    peca.aplicado = False
    try:
        objeto = peca.objeto
        if peca.modo == "vinculada":
            objeto.hide_set(peca.original_oculto)
            return
        modificador = _modificador_dos_pontos(objeto)
        if modificador is not None:
            modificador.show_viewport = peca.original_modificador
        objeto.display_type = peca.original_display
    except ReferenceError:
        return   # o objeto foi apagado: não há o que devolver


def _devolver_tudo() -> None:
    for peca in _M.pecas.values():
        _devolver(peca)
    _contorno_do_blender(False)


def _contorno_do_blender(desligar: bool) -> None:
    """Enquanto o Geometry Nodes desenha uma peça selecionada, o contorno de seleção do Blender (*Overlay > Outline Selected*)
    contorna cada ponto dela e a pinta toda de laranja, escondendo a nuvem; o contorno do Modo leve (`desenho_na_placa`) o
    substitui. Desligado, cada 3D View volta ao valor que o artista tinha."""
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type != "VIEW_3D":
                continue
            overlay = area.spaces.active.overlay
            chave = area.spaces.active.as_pointer()
            if desligar and chave not in _contorno_guardado:
                _contorno_guardado[chave] = overlay.show_outline_selected
                overlay.show_outline_selected = False
            elif not desligar and chave in _contorno_guardado:
                overlay.show_outline_selected = _contorno_guardado.pop(chave)
    if not desligar:
        _contorno_guardado.clear()


# ---- a classificação ----

def _modo_de_edicao(objeto: bpy.types.Object) -> str:
    if objeto.library is not None and (objeto.override_library is None or objeto.override_library.is_system_override):
        return "vinculada"
    return "override"


def _decidir(peca: Peca, modificador: bpy.types.Modifier, escondidas: set[str]) -> None:
    objeto = peca.objeto

    def fica_no_gn(motivo: str, detalhe: str = "") -> None:
        _devolver(peca)
        peca.destino, peca.motivo, peca.detalhe = "gn", motivo, detalhe

    if peca.nome in selecao_na_placa.devolvidas_ao_geometry_nodes():
        # O olho foi aberto pela seleção, não pelo artista: o Geometry Nodes desenha a peça até ela perder a seleção.
        peca.aplicado, peca.do_artista = False, False
        peca.destino, peca.motivo, peca.detalhe, peca.visivel = "gn", "selecionada", "", True
        return
    if peca.do_artista:
        peca.destino, peca.motivo, peca.visivel = "gn", "mexida", False
        return
    if peca.aplicado and not _parece_aplicado(peca):
        peca.aplicado, peca.do_artista = False, True
        peca.destino, peca.motivo, peca.visivel = "gn", "mexida", False
        return
    peca.visivel = _aparece(objeto, peca, escondidas)
    if not peca.visivel:
        if not peca.aplicado:
            peca.destino, peca.motivo = "gn", "oculta"
        return
    if objeto.mode == "EDIT":
        desenho_na_placa.liberar(peca.nome)
        peca.detalhe = ""
        fica_no_gn("editando")
        return
    efeito = _efeito_que_a_placa_nao_faz(objeto, modificador)
    if efeito is not None:
        fica_no_gn("efeito", efeito)
        return
    if not modificador.show_viewport and not peca.aplicado:
        fica_no_gn("modificador_desligado")
        return
    tamanho = _entrada(modificador, PLACA.entrada_do_tamanho)
    if tamanho is None:
        fica_no_gn("sem_tamanho")
        return
    peca.tamanho_cm = tamanho
    fracao = _entrada(modificador, PLACA.entrada_dos_pontos)
    peca.fracao = 1.0 if fracao is None else max(0.0, min(fracao, 100.0)) / 100
    if peca.motivo in ("erro", "sem_espaco") and not desenho_na_placa.carregada(peca.nome, objeto):
        fica_no_gn(peca.motivo, peca.detalhe)
        return
    if desenho_na_placa.carregada(peca.nome, objeto):
        _aplicar(peca, modificador)
        peca.destino, peca.motivo, peca.detalhe = "placa", "placa", ""
        return
    fica_no_gn("carregando")


def _passo() -> None:
    camada = bpy.context.view_layer
    selecao_na_placa.conferir_devolvidas()
    escondidas = _colecoes_escondidas(camada)
    vistos: set[str] = set()
    luzes: list[bpy.types.Object] = []
    for objeto in camada.objects:
        if objeto.type == "LIGHT":
            if objeto.visible_get():
                luzes.append(objeto)
            continue
        if objeto.type != "MESH":
            continue
        modificador = _modificador_dos_pontos(objeto)
        if modificador is None:
            continue
        nome = objeto.name_full
        vistos.add(nome)
        peca = _M.pecas.get(nome)
        if peca is None:
            peca = _M.pecas[nome] = Peca(nome, objeto, _modo_de_edicao(objeto))
        peca.objeto = objeto
        _decidir(peca, modificador, escondidas)
    _contorno_do_blender(any(p.motivo == "selecionada" for p in _M.pecas.values()))
    for nome in [n for n in _M.pecas if n not in vistos]:
        peca = _M.pecas[nome]
        try:
            peca.objeto.name   # noqa: B018  (só para saber se o objeto ainda existe)
        except ReferenceError:
            desenho_na_placa.liberar(nome)
            del _M.pecas[nome]
            continue
        peca.visivel = False   # fora da camada de vista: o que foi aplicado fica como está
    entradas = [Entrada(p.nome, p.objeto, p.tamanho_cm, p.fracao, p.visivel) for p in _M.pecas.values()
                if p.destino == "placa" and p.aplicado]
    entradas += [Entrada(p.nome, p.objeto, p.tamanho_cm, p.fracao, True, so_na_selecao=True) for p in _M.pecas.values()
                 if p.motivo == "selecionada" and desenho_na_placa.carregada(p.nome, p.objeto)]
    desenho_na_placa.definir_a_cena(entradas, luzes, desenho_na_placa.ambiente_da_cena(bpy.context.scene))


def reclassificar() -> None:
    """Classifica de novo as peças e entrega ao desenho as que vão pela placa. Sem efeito com o Modo leve desligado."""
    if not _M.ligado or _M.ocupado:
        return
    _M.ocupado = True
    try:
        _passo()
    finally:
        _M.ocupado = False


def estado_das_pecas() -> list[tuple[str, str]]:
    """(nome, estado em palavras) de cada peça, em ordem de nome."""
    resultado = []
    for nome in sorted(_M.pecas):
        peca = _M.pecas[nome]
        texto = PLACA.motivos[peca.motivo]
        resultado.append((nome, texto.format(modificador=peca.detalhe, erro=peca.detalhe)))
    return resultado


# ---- carregar as peças na placa, uma por vez ----

def _carregar_uma() -> float | None:
    if not _M.ligado:
        return None
    alvo = next((p for p in _M.pecas.values() if p.motivo == "carregando" and p.destino == "gn" and p.visivel), None)
    if alvo is None:
        return PLACA.intervalo_da_carga_s
    try:
        desenho_na_placa.carregar(alvo.nome, alvo.objeto)
    except desenho_na_placa.SemEspaco:
        alvo.motivo, alvo.detalhe = "sem_espaco", ""
    except Exception as erro:   # noqa: BLE001  (o erro vai para o painel e para o console; a peça fica no Geometry Nodes)
        traceback.print_exc()
        alvo.motivo, alvo.detalhe = "erro", f"{type(erro).__name__}: {erro}"
    reclassificar()
    _redesenhar()
    return PLACA.intervalo_da_carga_s


def _redesenhar() -> None:
    leve.redesenhar()
    ao_vivo.pedir()


# ---- handlers ----

@bpy.app.handlers.persistent
def _ao_mudar(_cena: bpy.types.Scene, _grafo: bpy.types.Depsgraph | None = None) -> None:
    reclassificar()


@bpy.app.handlers.persistent
def _ao_mudar_o_quadro(_cena: bpy.types.Scene, _grafo: object = None) -> None:
    reclassificar()


def _objetos_pelo_nome() -> dict[str, bpy.types.Object]:
    return {o.name_full: o for o in bpy.data.objects}


@bpy.app.handlers.persistent
def _depois_de_desfazer(_cena: bpy.types.Scene, _grafo: object = None) -> None:
    """As referências Python aos objetos morrem no desfazer e no refazer. Busca os objetos de novo e vê o que o desfazer
    deixou: a peça que voltou ao Geometry Nodes é aplicada de novo pela classificação."""
    if not _M.ligado:
        return
    _identificadores.clear()
    objetos = _objetos_pelo_nome()
    for nome in list(_M.pecas):
        peca = _M.pecas[nome]
        objeto = objetos.get(nome)
        if objeto is None or _modificador_dos_pontos(objeto) is None:
            desenho_na_placa.liberar(nome)
            del _M.pecas[nome]
            continue
        peca.objeto = objeto
        parece = _parece_aplicado(peca)
        if peca.do_artista and parece:
            peca.do_artista = False
        peca.aplicado = parece and not peca.do_artista
    reclassificar()


@bpy.app.handlers.persistent
def _antes_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    if _M.ligado:
        _devolver_tudo()


@bpy.app.handlers.persistent
def _depois_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    reclassificar()


@bpy.app.handlers.persistent
def _ao_abrir(_arquivo: str, _grafo: object = None) -> None:
    """Os objetos do arquivo anterior morreram. Se este é o mesmo arquivo (reverter, recuperar o salvamento automático), as
    peças que parecem ter sido aplicadas por nós voltam ao Geometry Nodes; depois os controles voltam ao que o arquivo guarda
    (os valores de partida, num arquivo de antes) e o Modo leve recomeça do zero, se o arquivo o guarda ligado."""
    escolhas = opcoes.ler(bpy.context.scene, (PROPRIEDADE_DO_BOTAO, *CONTROLES))
    ligado = bool(escolhas.pop(PROPRIEDADE_DO_BOTAO))
    _contorno_guardado.clear()   # as 3D Views do arquivo anterior morreram; o arquivo novo traz o valor salvo
    objetos = _objetos_pelo_nome()
    for peca in _M.pecas.values():
        objeto = objetos.get(peca.nome)
        if objeto is None:
            continue
        peca.objeto = objeto
        if peca.aplicado and _parece_aplicado(peca):
            _devolver(peca)
    _M.pecas.clear()
    _identificadores.clear()
    desenho_na_placa.liberar_tudo()
    selecao_na_placa.devolver_todas()
    _tirar_handlers()
    _M.ligado = False
    gerenciador = bpy.context.window_manager
    for nome, valor in escolhas.items():
        if getattr(gerenciador, nome) != valor:
            setattr(gerenciador, nome, valor)
    if getattr(gerenciador, PROPRIEDADE_DO_BOTAO) != ligado:
        setattr(gerenciador, PROPRIEDADE_DO_BOTAO, ligado)   # o update liga ou só guarda o desligado
    elif ligado:
        _comecar()


HANDLERS_DA_JANELA = ((bpy.app.handlers.depsgraph_update_post, _ao_mudar), (bpy.app.handlers.frame_change_post, _ao_mudar_o_quadro),
                      (bpy.app.handlers.undo_post, _depois_de_desfazer), (bpy.app.handlers.redo_post, _depois_de_desfazer),
                      (bpy.app.handlers.save_pre, _antes_de_salvar), (bpy.app.handlers.save_post, _depois_de_salvar))


def _por_handlers() -> None:
    if _M.com_handlers:
        return
    for lista, funcao in HANDLERS_DA_JANELA:
        lista.append(funcao)
    _M.com_handlers = True


def _tirar_handlers() -> None:
    if not _M.com_handlers:
        return
    for lista, funcao in HANDLERS_DA_JANELA:
        if funcao in lista:
            lista.remove(funcao)
    _M.com_handlers = False
    if bpy.app.timers.is_registered(_carregar_uma):
        bpy.app.timers.unregister(_carregar_uma)


# ---- ligar e desligar ----

def _comecar() -> None:
    """Liga o Modo leve: as peças sem efeito vão para a placa, uma por vez, e saem do desenho do Blender."""
    _M.pecas.clear()
    _M.ligado = True
    _por_handlers()
    if not bpy.app.timers.is_registered(_carregar_uma):
        bpy.app.timers.register(_carregar_uma, first_interval=PLACA.intervalo_da_carga_s, persistent=True)
    reclassificar()
    _redesenhar()


def _parar() -> None:
    """Desliga: devolve o que mudou nas peças e solta a placa."""
    _devolver_tudo()
    selecao_na_placa.devolver_todas()
    _M.pecas.clear()
    _M.ligado = False
    _tirar_handlers()
    desenho_na_placa.liberar_tudo()
    _redesenhar()


def _ao_mudar_o_botao(gerenciador: bpy.types.WindowManager, _contexto: bpy.types.Context) -> None:
    opcoes.guardar(gerenciador, (PROPRIEDADE_DO_BOTAO,))
    ligado = bool(getattr(gerenciador, PROPRIEDADE_DO_BOTAO))
    if ligado and not _M.ligado:
        _comecar()
    elif not ligado and _M.ligado:
        _parar()


def _ao_mudar_um_controle(gerenciador: bpy.types.WindowManager, _contexto: bpy.types.Context) -> None:
    opcoes.guardar(gerenciador, CONTROLES)
    _redesenhar()


# ---- a interface ----

def _desenhar_o_painel(layout: bpy.types.UILayout, contexto: bpy.types.Context, com_lista: bool) -> None:
    """O menu do cabeçalho mostra só o resumo; a aba Sala lista também as peças que ficaram no Geometry Nodes, com o motivo."""
    gerenciador = contexto.window_manager
    layout.prop(gerenciador, PROPRIEDADE_DO_BOTAO, toggle=True, icon="LIGHTPROBE_SPHERE" if _M.ligado else "POINTCLOUD_DATA")
    coluna = layout.column()
    coluna.prop(gerenciador, desenho_na_placa.PROPRIEDADE_DO_TETO)
    coluna.prop(gerenciador, desenho_na_placa.PROPRIEDADE_DA_ESCALA)
    coluna.prop(gerenciador, desenho_na_placa.PROPRIEDADE_DA_LUZ)
    caixa = layout.box().column(align=True)
    for linha in (PLACA.painel.aviso_do_modo, PLACA.painel.aviso_da_luz):
        _texto_em_linhas(caixa, linha)
    if not _M.ligado:
        return
    estados = estado_das_pecas()
    carregando = sum(1 for p in _M.pecas.values() if p.motivo == "carregando" and p.visivel)
    if carregando:
        layout.label(text=PLACA.painel.carregando.format(feitas=len(estados) - carregando, total=len(estados)), icon="TIME")
    motivos = [p.motivo for p in _M.pecas.values()]
    placa, ocultas = motivos.count("placa"), motivos.count("oculta")
    contagens = layout.column(align=True)
    for texto, quantas in ((PLACA.painel.contagem_placa, placa), (PLACA.painel.contagem_gn, len(motivos) - placa - ocultas),
                           (PLACA.painel.contagem_ocultas, ocultas)):
        contagens.label(text=texto.format(quantas=quantas))
    if not com_lista:
        return
    no_gn = [(nome, estado) for nome, estado in estados if estado not in (PLACA.motivos["placa"], PLACA.motivos["oculta"])]
    coluna = layout.column(align=True)
    for nome, estado in no_gn[:PLACA.painel.linhas_maximas]:
        coluna.label(text=nome.split(" [")[0], icon="DOT")
        _texto_em_linhas(coluna, estado)
    if len(no_gn) > PLACA.painel.linhas_maximas:
        coluna.label(text=f"… e mais {len(no_gn) - PLACA.painel.linhas_maximas}")


def _texto_em_linhas(layout: bpy.types.UILayout, texto: str) -> None:
    largura = PLACA.painel.largura_do_texto
    linha = ""
    for palavra in texto.split():
        if linha and len(linha) + 1 + len(palavra) > largura:
            layout.label(text=linha)
            linha = palavra
        else:
            linha = f"{linha} {palavra}".strip()
    if linha:
        layout.label(text=linha)


class SALA_PT_modo_leve(bpy.types.Panel):
    bl_label = PLACA.nome_do_botao
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Sala"
    bl_order = 0

    def draw(self, contexto: bpy.types.Context) -> None:
        _desenhar_o_painel(self.layout, contexto, com_lista=True)


class SALA_PT_modo_leve_menu(bpy.types.Panel):
    """O menu ao lado do botão no cabeçalho: o Modo leve e, embaixo, os Pontos na janela."""
    bl_label = PLACA.nome_do_botao
    bl_space_type = "VIEW_3D"
    bl_region_type = "HEADER"

    def draw(self, contexto: bpy.types.Context) -> None:
        _desenhar_o_painel(self.layout, contexto, com_lista=False)
        self.layout.separator()
        self.layout.label(text="Pontos na janela")
        leve.desenhar_controles(self.layout, contexto)


def _no_cabecalho(menu: bpy.types.Header, contexto: bpy.types.Context) -> None:
    linha = menu.layout.row(align=True)
    linha.prop(contexto.window_manager, PROPRIEDADE_DO_BOTAO, toggle=True, text=PLACA.nome_do_botao)
    linha.popover(panel=SALA_PT_modo_leve_menu.__name__, text="")


def _desenhar_o_selo() -> None:
    """O selo fixo no canto da 3D View enquanto o Modo leve está ligado."""
    if not _M.ligado:
        return
    selo = PLACA.selo
    blf.size(0, selo.tamanho_px)
    largura, altura = blf.dimensions(0, selo.texto)
    x, y = selo.margem_px, selo.margem_px
    p = selo.preenchimento_px
    sombreador = gpu.shader.from_builtin("UNIFORM_COLOR")
    lote = batch_for_shader(sombreador, "TRI_FAN", {"pos": [(x - p, y - p), (x + largura + p, y - p), (x + largura + p, y + altura + p),
                                                          (x - p, y + altura + p)]})
    gpu.state.blend_set("ALPHA")
    sombreador.bind()
    sombreador.uniform_float("color", selo.cor_do_fundo)
    lote.draw(sombreador)
    blf.color(0, *selo.cor_do_texto)
    blf.position(0, x, y, 0)
    blf.draw(0, selo.texto)
    gpu.state.blend_set("NONE")


def _desenhar_o_contorno() -> None:
    """No desenho 2D de cada 3D View: o contorno das peças selecionadas (da placa e do Geometry Nodes)."""
    if not _M.ligado:
        return
    regiao, dados = bpy.context.region, bpy.context.region_data
    if regiao is None or dados is None:
        return
    recorte = tuple(tuple(p) for p in dados.clip_planes) if dados.use_clip_planes else ()
    desenho_na_placa.desenhar_o_contorno(desenho_na_placa.Vista(dados.view_matrix.copy(), dados.window_matrix.copy(), regiao.width,
                                                                regiao.height, recorte))


def _desenhar_na_vista() -> None:
    """No desenho de cada 3D View: as peças da placa, com o recorte do Alt+B da vista."""
    if not _M.ligado:
        return
    regiao, dados = bpy.context.region, bpy.context.region_data
    if regiao is None or dados is None:
        return
    recorte = tuple(tuple(p) for p in dados.clip_planes) if dados.use_clip_planes else ()
    desenho_na_placa.desenhar(desenho_na_placa.Vista(dados.view_matrix.copy(), dados.window_matrix.copy(), regiao.width,
                                                     regiao.height, recorte))


CLASSES = (SALA_PT_modo_leve_menu,)


def registrar_o_painel_da_aba() -> None:
    """O painel da aba Sala é registrado antes dos outros painéis da aba (`__init__.py`): o Blender não ordena por `bl_order`
    abaixo de zero (um painel com -1 ficou depois dos de 0) e, entre painéis de mesma ordem, vale o registro."""
    bpy.utils.register_class(SALA_PT_modo_leve)


Mudanca = Callable[[bpy.types.WindowManager, bpy.types.Context], None] | None


def definicoes(ao_mudar_o_botao: Mudanca, ao_mudar_um_controle: Mudanca) -> dict[str, Propriedade]:
    """O botão e os controles do Modo leve, que o artista escolhe e o arquivo guarda, com nomes e partida do dados.json."""
    teto, escala = PLACA.teto_de_pontos, PLACA.escala_do_ponto
    return {
        PROPRIEDADE_DO_BOTAO: bpy.props.BoolProperty(name=PLACA.nome_do_botao, description=PLACA.descricao_do_botao,
                                                     default=False, update=ao_mudar_o_botao),
        desenho_na_placa.PROPRIEDADE_DO_TETO: bpy.props.IntProperty(
            name=teto.nome, description=teto.descricao, default=int(teto.partida), min=int(teto.minimo), max=int(teto.maximo),
            update=ao_mudar_um_controle),
        desenho_na_placa.PROPRIEDADE_DA_ESCALA: bpy.props.FloatProperty(
            name=escala.nome, description=escala.descricao, default=escala.partida, min=escala.minimo, max=escala.maximo,
            update=ao_mudar_um_controle),
        desenho_na_placa.PROPRIEDADE_DA_LUZ: bpy.props.BoolProperty(
            name=PLACA.nome_da_luz, description=PLACA.descricao_da_luz, default=True, update=ao_mudar_um_controle),
    }


def register() -> None:
    for classe in CLASSES:
        bpy.utils.register_class(classe)
    for nome, definicao in definicoes(_ao_mudar_o_botao, _ao_mudar_um_controle).items():
        setattr(bpy.types.WindowManager, nome, definicao)
    _desenhos.append((bpy.types.SpaceView3D, bpy.types.SpaceView3D.draw_handler_add(_desenhar_na_vista, (), "WINDOW", "POST_VIEW")))
    _desenhos.append((bpy.types.SpaceView3D, bpy.types.SpaceView3D.draw_handler_add(_desenhar_o_selo, (), "WINDOW", "POST_PIXEL")))
    _desenhos.append((bpy.types.SpaceView3D, bpy.types.SpaceView3D.draw_handler_add(_desenhar_o_contorno, (), "WINDOW", "POST_PIXEL")))
    bpy.app.handlers.load_post.append(_ao_abrir)
    bpy.types.VIEW3D_HT_header.append(_no_cabecalho)
    selecao_na_placa.ao_mudar_a_selecao = reclassificar


def unregister() -> None:
    selecao_na_placa.ao_mudar_a_selecao = None
    _parar()
    if _ao_abrir in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_ao_abrir)
    bpy.types.VIEW3D_HT_header.remove(_no_cabecalho)
    for espaco, desenho in _desenhos:
        espaco.draw_handler_remove(desenho, "WINDOW")
    _desenhos.clear()
    for nome in (PROPRIEDADE_DO_BOTAO, *CONTROLES):
        delattr(bpy.types.WindowManager, nome)
    for classe in reversed(CLASSES):
        bpy.utils.unregister_class(classe)
    bpy.utils.unregister_class(SALA_PT_modo_leve)
