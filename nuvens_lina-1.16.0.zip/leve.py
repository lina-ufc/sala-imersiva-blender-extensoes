"""Pontos nas peças com efeito: com o Modo leve ligado, a janela 3D desenha só uma parte dos pontos das peças que continuam no
Geometry Nodes (as com efeito, a em edição, a só vinculada selecionada). As outras vão pela placa (`modo_leve.py`), com a
densidade pela distância. Com o Modo leve desligado, nada é reduzido: a janela mostra tudo como no render. O render (F12,
render.py e Renderizar a fita, do visor) nunca muda: lá vale só a entrada `Pontos no render (%)` de cada peça.

O controle, com nome, limites e valor de partida no dados.json (`modo_leve.pontos`), fica no painel do Modo leve. Até a 1.14,
eram os *Pontos na janela*, com botão próprio no cabeçalho e valendo também sem o Modo leve; a propriedade do Window Manager
manteve o nome (`pontos_na_janela`), para o valor guardado nos arquivos continuar valendo.

O valor vai para uma propriedade da cena (`propriedade_da_cena`), que o grupo de cada peça lê por drivers
(pontos.reduzir_na_janela, no nuvens-blender). Assim o complemento não mexe na peça, que chega vinculada da biblioteca, nem na
tomada do artista. Sem a propriedade (Blender sem o complemento, Modo leve desligado ou 100%), a peça aparece inteira. Ela sai
das cenas antes de salvar e volta logo depois: sem o complemento, a tomada abre inteira. As propriedades do foco
(`propriedades_da_cena`), que a 1.13 gravava, são apagadas das cenas onde ainda estiverem. O controle fica no Window Manager, e
a escolha do artista vai também para o arquivo (`opcoes.py`).
"""
from collections.abc import Callable

import bpy

from . import dados, opcoes
from .desenho_na_placa import PROPRIEDADE_DO_BOTAO as MODO_LEVE
from .desenho_na_placa import PROPRIEDADE_DOS_PONTOS_NA_JANELA as PONTOS
from .opcoes import Propriedade

LEVE = dados.modo_leve()
PROPRIEDADES = LEVE.propriedades_da_cena
TODAS = (LEVE.propriedade_da_cena, *PROPRIEDADES.values())
CONTROLES = {PONTOS: LEVE.pontos}
NO_ARQUIVO = tuple(CONTROLES)   # o que o arquivo guarda (opcoes.py)


def redesenhar() -> None:
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def grupos_com_modo_leve() -> list[bpy.types.NodeTree]:
    """Os grupos de pontos carregados (das peças vinculadas ou locais) que obedecem ao controle."""
    return [g for g in bpy.data.node_groups if g.bl_idname == "GeometryNodeTree" and LEVE.nome_do_no in g.nodes]


def valores(gerenciador: bpy.types.WindowManager) -> dict[str, float | list[float]]:
    """O que vai para as cenas; vazio sem redução ou com o Modo leve desligado (também enquanto ele desliga)."""
    if not getattr(gerenciador, MODO_LEVE):
        return {}
    geral = gerenciador.pontos_na_janela / 100
    return {} if geral >= 1 else {LEVE.propriedade_da_cena: geral}


def _igual(guardado: object, valor: float | list[float]) -> bool:
    return (list(guardado) if hasattr(guardado, "__len__") else guardado) == valor


def gravar_nas_cenas(v: dict[str, float | list[float]]) -> None:
    """Deixa em cada cena só as propriedades de `v`, com esses valores, e avisa o Blender para refazer as peças na janela.
    Sem mudança, não avisa, para não refazer as peças à toa."""
    mudou = False
    for cena in bpy.data.scenes:
        if cena.library is not None:
            continue
        for nome in TODAS:
            if nome not in v and nome in cena:
                del cena[nome]
                mudou = True
            elif nome in v and (nome not in cena or not _igual(cena[nome], v[nome])):
                cena[nome] = v[nome]
                mudou = True
        if mudou:
            cena.update_tag()
    if not mudou:
        return
    # Propriedade gravada pelo Python não avisa o Blender sozinha. Medido sem janela em 09/11/2026: só com a cena e os grupos
    # das peças marcados o driver relê o valor a cada mudança; marcar só um dos dois não basta.
    for grupo in grupos_com_modo_leve():
        grupo.update_tag()


def aplicar() -> None:
    gravar_nas_cenas(valores(bpy.context.window_manager))
    redesenhar()


def _ao_mudar(gerenciador: bpy.types.WindowManager, _contexto: bpy.types.Context) -> None:
    opcoes.guardar(gerenciador, NO_ARQUIVO)
    aplicar()


@bpy.app.handlers.persistent
def _antes_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    gravar_nas_cenas({})


@bpy.app.handlers.persistent
def _depois_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    aplicar()


@bpy.app.handlers.persistent
def _ao_abrir(_arquivo: str, _grafo: object = None) -> None:
    """Os controles voltam ao que o arquivo aberto guarda (os valores de partida, num arquivo de antes)."""
    gerenciador = bpy.context.window_manager
    guardados = opcoes.ler(bpy.context.scene, NO_ARQUIVO)
    for nome, valor in guardados.items():
        if getattr(gerenciador, nome) != valor:
            setattr(gerenciador, nome, valor)   # o update grava nas cenas
    aplicar()


def desenhar_controles(layout: bpy.types.UILayout, contexto: bpy.types.Context) -> None:
    layout.prop(contexto.window_manager, PONTOS, slider=True)
    if not grupos_com_modo_leve():
        layout.label(text="As peças desta cena são de antes deste controle", icon="INFO")


UNIDADES = {PONTOS: "PERCENTAGE"}
HANDLERS = ((bpy.app.handlers.save_pre, _antes_de_salvar), (bpy.app.handlers.save_post, _depois_de_salvar),
            (bpy.app.handlers.load_post, _ao_abrir))


def definicoes(ao_mudar: Callable[[bpy.types.WindowManager, bpy.types.Context], None] | None) -> dict[str, Propriedade]:
    """O controle que o artista escolhe e o arquivo guarda, com nome, limites e partida do dados.json."""
    return {nome: bpy.props.IntProperty(name=c.nome, subtype=UNIDADES[nome], default=c.partida, min=c.minimo, max=c.maximo,
                                        step=c.passo, update=ao_mudar, description=c.descricao + LEVE.fim_da_descricao)
            for nome, c in CONTROLES.items()}


def _aplicar_ao_ligar() -> None:
    aplicar()


def register() -> None:
    for nome, definicao in definicoes(_ao_mudar).items():
        setattr(bpy.types.WindowManager, nome, definicao)
    for lista, funcao in HANDLERS:
        lista.append(funcao)
    # Ao ligar o complemento com um arquivo já aberto (instalar ou atualizar a extensão), nenhum load_post roda: sem isto, os
    # pontos só voltavam à cena quando o artista mexia no controle.
    bpy.app.timers.register(_aplicar_ao_ligar, first_interval=0.0)


def unregister() -> None:
    for lista, funcao in HANDLERS:
        lista.remove(funcao)
    gravar_nas_cenas({})
    for nome in NO_ARQUIVO:
        delattr(bpy.types.WindowManager, nome)
