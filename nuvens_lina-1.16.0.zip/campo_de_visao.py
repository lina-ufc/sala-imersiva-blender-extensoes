"""Contas do desenho pela placa que não precisam do Blender: o campo de visão, a sorte de cada ponto, a parte dos pontos que
a distância pede e a posição compacta em 16 bits. Sem bpy, para os testes rodarem fora do Blender."""
import numpy as np

MAIOR_COMPACTO = 65535


def planos_do_campo(projecao_vezes_vista: np.ndarray) -> np.ndarray:
    """Os seis planos do campo de visão (esquerda, direita, baixo, cima, perto, longe) no mundo, de (a, b, c, d) apontando
    para dentro: o ponto p está dentro de um plano quando a·p.x + b·p.y + c·p.z + d >= 0. A matriz é a de recorte do OpenGL
    (profundidade de -1 a 1), a mesma que o Blender dá em `perspective_matrix`."""
    m = np.asarray(projecao_vezes_vista, np.float64)
    planos = np.array([m[3] + m[0], m[3] - m[0], m[3] + m[1], m[3] - m[1], m[3] + m[2], m[3] - m[2]])
    comprimento = np.linalg.norm(planos[:, :3], axis=1, keepdims=True)
    return planos / np.maximum(comprimento, 1e-12)


def cantos_da_caixa(minimo: np.ndarray, maximo: np.ndarray, modelo: np.ndarray) -> np.ndarray:
    """Os oito cantos da caixa (coordenadas da malha) no mundo, pela matriz do objeto."""
    lo, hi = np.asarray(minimo, np.float64), np.asarray(maximo, np.float64)
    cantos = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])
    return cantos @ np.asarray(modelo, np.float64)[:3, :3].T + np.asarray(modelo, np.float64)[:3, 3]


def caixa_fora(planos: np.ndarray, cantos: np.ndarray) -> bool:
    """Verdadeiro quando todos os cantos ficam do lado de fora de algum dos planos: a caixa inteira está fora. Pode dizer
    "dentro" de uma caixa que está fora perto de uma quina do campo; nunca diz "fora" de uma que aparece."""
    if len(planos) == 0:
        return False
    distancias = cantos @ planos[:, :3].T + planos[:, 3]
    return bool((distancias < 0).all(axis=0).any())


def escala_da_matriz(modelo: np.ndarray) -> float:
    """O tamanho de uma unidade da malha no mundo: a raiz cúbica do determinante da parte 3×3."""
    return float(abs(np.linalg.det(np.asarray(modelo, np.float64)[:3, :3])) ** (1 / 3))


def sorte_de_cada_ponto(total: int, semente: int) -> np.ndarray:
    """Um número de 0 a 65535 por ponto, espalhado ao acaso e sempre o mesmo para o mesmo índice e semente. O ponto aparece
    quando a sorte dele fica abaixo da parte que a distância pede: os que aparecem longe são parte dos que aparecem perto, e a
    densidade cai sem salto. Devolve (total,) uint16."""
    x = np.arange(total, dtype=np.uint32) ^ np.uint32(semente & 0xFFFFFFFF)
    x ^= x >> np.uint32(16)
    x *= np.uint32(0x7FEB352D)
    x ^= x >> np.uint32(15)
    x *= np.uint32(0x846CA68B)
    x ^= x >> np.uint32(16)
    return (x >> np.uint32(16)).astype(np.uint16)


def parte_pela_distancia(distancia_m: float, cheia_ate_m: float, parte_minima: float, parte_perto: float = 1.0) -> float:
    """A parte dos pontos que aparece a esta distância do olho: `parte_perto` até `cheia_ate_m`, depois caindo com o quadrado
    da distância (a mesma quantidade de pontos por pixel), até `parte_minima`, que não passa da de perto. A mesma conta do
    shader."""
    if distancia_m <= cheia_ate_m:
        return parte_perto
    return max(min(parte_minima, parte_perto), parte_perto * (cheia_ate_m / distancia_m) ** 2)


def distancia_ate_a_caixa(olho: np.ndarray, cantos: np.ndarray) -> float:
    """A distância do olho até a caixa alinhada aos eixos que contém os cantos (no mundo); zero com o olho dentro."""
    lo, hi = cantos.min(0), cantos.max(0)
    fora = np.maximum(np.maximum(lo - olho, olho - hi), 0.0)
    return float(np.linalg.norm(fora))


def acumulado_da_sorte(sorte: np.ndarray) -> np.ndarray:
    """Quantos pontos têm sorte abaixo de cada valor: o item k conta os de sorte < k. (65537,) int64."""
    acumulado = np.zeros(MAIOR_COMPACTO + 2, np.int64)
    acumulado[1:] = np.cumsum(np.bincount(sorte, minlength=MAIOR_COMPACTO + 1))
    return acumulado


def pontos_ate(acumulado: np.ndarray, parte: float) -> int:
    """Quantos pontos aparecem com esta parte: os de sorte abaixo de parte × 65536, que são o começo dos pontos em ordem de
    sorte."""
    limite = int(np.ceil(min(max(parte, 0.0), 1.0) * (MAIOR_COMPACTO + 1)))
    return int(acumulado[limite])


def compactar(pontos: np.ndarray, minimo: np.ndarray, maximo: np.ndarray) -> np.ndarray:
    """A posição de cada ponto como inteiro de 16 bits dentro da caixa, com um quarto componente zero: o Metal não aceita
    atributo de 3 componentes de 16 bits. Devolve (n, 4) uint16."""
    minimo32 = np.asarray(minimo, np.float32)
    escala = np.float32(MAIOR_COMPACTO) / np.maximum(np.asarray(maximo, np.float32) - minimo32, np.float32(1e-9))
    unidade = np.subtract(pontos, minimo32, dtype=np.float32)
    unidade *= escala
    np.rint(unidade, out=unidade)
    np.clip(unidade, 0, MAIOR_COMPACTO, out=unidade)
    saida = np.zeros((len(pontos), 4), np.uint16)
    saida[:, :3] = unidade
    return saida


def cor_em_bytes(srgb: np.ndarray) -> np.ndarray:
    """A cor de cada ponto (sRGB, 0 a 1, (n, 3) ou (n, 4)) como (n, 4) uint8, com alfa cheio."""
    canais = np.clip(srgb[:, :3], 0.0, 1.0, dtype=np.float32)
    canais *= np.float32(255)
    np.rint(canais, out=canais)
    saida = np.full((len(srgb), 4), 255, np.uint8)
    saida[:, :3] = canais
    return saida


def numero_em_cor(numero: int) -> tuple[float, float, float, float]:
    """O número da peça como RGBA de 8 bits (byte menos significativo no vermelho), em 0 a 1."""
    return tuple(((numero >> (8 * i)) & 255) / 255.0 for i in range(4))  # type: ignore[return-value]
