"""As peças que o Modo leve desenha pela placa também no visor da sala, que é do complemento Sala imersiva
(`complemento_da_sala` no dados.json). Sem ele ligado, o Modo leve vale só na 3D View.

O visor desenha cada superfície fora da tela e chama, por cima, o desenho que este módulo deixa com ele
(`ao_vivo.desenhar_por_cima`). Os complementos ligam em qualquer ordem ao abrir o Blender: o desenho é deixado logo depois
de todos ligarem e de novo a cada pedido de redesenho, o que também cobre a Sala imersiva ligada depois.
"""
import sys
from types import ModuleType

import bpy
import gpu
from mathutils import Matrix

from . import dados, desenho_na_placa

COMPLEMENTO_DA_SALA = dados.complemento_da_sala()


def _ao_vivo() -> ModuleType | None:
    for complemento in bpy.context.preferences.addons:
        nome = complemento.module
        if nome == COMPLEMENTO_DA_SALA or nome.endswith("." + COMPLEMENTO_DA_SALA):
            return sys.modules.get(f"{nome}.ao_vivo")
    return None


def desenhar(vista: Matrix, projecao: Matrix, largura: int, altura: int) -> None:
    # A profundidade que o draw_view3d deixa no fora da tela não serve ao teste das bolinhas (medido no Metal: com ela,
    # nenhum ponto passa; sem teste, passam todos). Limpa-se, e as bolinhas se ordenam só entre elas: uma malha do Blender
    # na cena não as tapa no visor.
    gpu.state.active_framebuffer_get().clear(depth=1.0)
    desenho_na_placa.desenhar(desenho_na_placa.Vista(vista, projecao, largura, altura, ()))


def pedir() -> None:
    """Pede ao visor um desenho novo, deixando antes o desenho das peças com ele."""
    ao_vivo = _ao_vivo()
    if ao_vivo is not None:
        ao_vivo.desenhar_por_cima(desenhar)


def _ligar() -> None:
    pedir()


def register() -> None:
    bpy.app.timers.register(_ligar, first_interval=0.0)


def unregister() -> None:
    if bpy.app.timers.is_registered(_ligar):
        bpy.app.timers.unregister(_ligar)
    ao_vivo = _ao_vivo()
    if ao_vivo is not None:
        ao_vivo.parar_de_desenhar_por_cima(desenhar)
