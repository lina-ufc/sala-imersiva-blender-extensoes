"""As peças leves. Ao lado de cada peça `<peça>.blend` da biblioteca, `<peça><sufixo>.blend` (`versao_leve.py` do nuvens-blender)
tem uma parte dos pontos e os mesmos nomes por dentro. Com o Modo leve ligado, a cena vincula as leves; desligado, as completas.
O Blender carrega os vínculos ao abrir o arquivo, antes de qualquer complemento agir: por isso o arquivo é sempre salvo apontando
para as leves, e abre leve em qualquer máquina. A troca é o Relocate do Outliner (modo Blender File, botão direito na biblioteca):
o caminho muda e a biblioteca é recarregada; as liberações (Library Override) seguem, porque os nomes são os mesmos. Biblioteca
sem a versão ao lado fica como está. O render das paradas (`render.py` do nuvens-blender) chama `para_as_completas`."""
import os

import bpy

from . import dados

VERSAO_LEVE = dados.versao_leve()


def _trocas(para_leves: bool) -> list[tuple[bpy.types.Library, str]]:
    """As bibliotecas vinculadas direto pela cena que têm a outra versão no disco, com o caminho dela."""
    trocas = []
    for biblioteca in bpy.data.libraries:
        if biblioteca.parent is not None:
            continue
        novo = VERSAO_LEVE.leve_de(biblioteca.filepath) if para_leves else VERSAO_LEVE.completa_de(biblioteca.filepath)
        if novo is not None and os.path.isfile(bpy.path.abspath(novo)):
            trocas.append((biblioteca, novo))
    return trocas


def biblioteca_de(id_: bpy.types.ID) -> bpy.types.Library | None:
    """A biblioteca de onde vem um objeto ou uma coleção da cena: a da referência, se liberado; a dele, se só vinculado; a dos
    dados, num objeto local com os dados vinculados."""
    if id_.override_library is not None:
        return id_.override_library.reference.library
    if id_.library is not None:
        return id_.library
    dado = getattr(id_, "data", None)
    return dado.library if isinstance(dado, bpy.types.ID) else None


def pecas_com_as_duas() -> list[tuple[bpy.types.Library, bool]]:
    """As bibliotecas vinculadas direto pela cena que têm a versão leve e a completa no disco, com True se estão na completa."""
    pecas = []
    for biblioteca in bpy.data.libraries:
        if biblioteca.parent is not None:
            continue
        completa = VERSAO_LEVE.completa_de(biblioteca.filepath)
        if completa is not None:
            pecas.append((biblioteca, False))
            continue
        leve = VERSAO_LEVE.leve_de(biblioteca.filepath)
        if leve is not None and os.path.isfile(bpy.path.abspath(leve)):
            pecas.append((biblioteca, True))
    return sorted(pecas, key=lambda par: par[0].name)


def nome_da_peca(biblioteca: bpy.types.Library) -> str:
    caminho = VERSAO_LEVE.completa_de(biblioteca.filepath) or biblioteca.filepath
    return os.path.splitext(os.path.basename(caminho))[0]


def trocar_uma(biblioteca: bpy.types.Library, completa: bool) -> bool:
    """Põe uma peça na completa ou na leve; devolve se trocou."""
    novo = VERSAO_LEVE.completa_de(biblioteca.filepath) if completa else VERSAO_LEVE.leve_de(biblioteca.filepath)
    if novo is None or not os.path.isfile(bpy.path.abspath(novo)):
        return False
    biblioteca.filepath = novo
    biblioteca.reload()
    return True


def _trocar(para_leves: bool) -> int:
    trocas = _trocas(para_leves)
    for biblioteca, novo in trocas:
        biblioteca.filepath = novo
        biblioteca.reload()
    return len(trocas)


def para_as_leves() -> int:
    """Passa as peças da cena às versões leves; devolve quantas bibliotecas trocou."""
    return _trocar(True)


def para_as_completas() -> int:
    """Volta as peças da cena às completas; devolve quantas bibliotecas trocou."""
    return _trocar(False)


_caminhos_da_sessao: dict[str, str] = {}


@bpy.app.handlers.persistent
def _antes_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    """O arquivo leva o caminho das leves; a sessão segue com o que tem na memória, sem recarregar."""
    _caminhos_da_sessao.clear()
    for biblioteca, novo in _trocas(True):
        _caminhos_da_sessao[biblioteca.name] = biblioteca.filepath
        biblioteca.filepath = novo


@bpy.app.handlers.persistent
def _depois_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    for nome, caminho in _caminhos_da_sessao.items():
        bpy.data.libraries[nome].filepath = caminho
    _caminhos_da_sessao.clear()


HANDLERS = ((bpy.app.handlers.save_pre, _antes_de_salvar), (bpy.app.handlers.save_post, _depois_de_salvar),
            (bpy.app.handlers.save_post_fail, _depois_de_salvar))


def register() -> None:
    for lista, funcao in HANDLERS:
        lista.append(funcao)


def unregister() -> None:
    for lista, funcao in HANDLERS:
        if funcao in lista:
            lista.remove(funcao)
