"""Arestas da sala, letra de cada parede e teto, desenhados por cima da vista do olho do visor (a 3D View da janela do
visor). Não criam objeto nem mudam a cena: são só desenho, ligado e desligado pelo painel (Arestas, Letras, Teto)."""
import math

import blf
import bpy
import gpu
from bpy_extras.view3d_utils import location_3d_to_region_2d
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

from . import visor
from .visor import VISOR

_desenhos: list[tuple[object, str]] = []


def _na_vista_do_olho() -> bool:
    tela = bpy.context.screen
    return tela is not None and bool(tela.get(VISOR.marca_da_janela))


def superficies(sala: bpy.types.Object) -> dict[str, list[Vector]]:
    """Os cantos de cada superfície da sala, no mundo, pelo nome dela (o mesmo da câmera: "Parede A", "Piso")."""
    cantos: dict[str, list[Vector]] = {}
    for filho in sala.children:
        if filho.type != "MESH" or not filho.name.startswith(VISOR.prefixo_da_superficie):
            continue
        nome = filho.name.removeprefix(VISOR.prefixo_da_superficie)
        cantos[nome] = [filho.matrix_world @ v.co for v in filho.data.vertices]
    return cantos


def _altura(ponto: Vector, sala: bpy.types.Object) -> float:
    return ponto.dot(sala.matrix_world.to_3x3().col[2].normalized())


def _bordas(cantos: list[Vector]) -> list[Vector]:
    """As quatro bordas do retângulo, em pares de pontos, na ordem dos cantos em volta do centro."""
    centro = sum(cantos, Vector()) / len(cantos)
    eixo_a = (cantos[0] - centro).normalized()
    eixo_b = (cantos[1] - centro) - (cantos[1] - centro).project(eixo_a)
    eixo_b = eixo_b.normalized() if eixo_b.length > 1e-9 else eixo_a.orthogonal().normalized()
    em_volta = sorted(cantos, key=lambda p: math.atan2((p - centro).dot(eixo_b), (p - centro).dot(eixo_a)))
    pares: list[Vector] = []
    for i, ponto in enumerate(em_volta):
        pares += [ponto, em_volta[(i + 1) % len(em_volta)]]
    return pares


def _desenhar_na_cena() -> None:
    if not _na_vista_do_olho():
        return
    cena = bpy.context.scene
    opcoes = cena.visor_da_sala
    if not (opcoes.arestas or opcoes.teto):
        return
    try:
        sala = visor.sala_do_visor(cena)
    except RuntimeError:
        return
    cantos = superficies(sala)
    estado_da_profundidade = gpu.state.depth_test_get()
    gpu.state.depth_test_set("LESS_EQUAL")
    gpu.state.blend_set("ALPHA")
    if opcoes.teto and VISOR.superficie_do_piso in cantos:
        paredes = [p for nome, ps in cantos.items() if nome != VISOR.superficie_do_piso for p in ps]
        piso = cantos[VISOR.superficie_do_piso]
        subir = max(_altura(p, sala) for p in paredes) - max(_altura(p, sala) for p in piso)
        acima = sala.matrix_world.to_3x3().col[2].normalized() * subir
        teto = [p + acima for p in _bordas(piso)[::2]]
        sombreador = gpu.shader.from_builtin("UNIFORM_COLOR")
        lote = batch_for_shader(sombreador, "TRIS", {"pos": [tuple(p) for p in teto]}, indices=[(0, 1, 2), (0, 2, 3)])
        sombreador.uniform_float("color", VISOR.cor_do_teto)
        lote.draw(sombreador)
    if opcoes.arestas:
        linhas = [tuple(p) for ps in cantos.values() for p in _bordas(ps)]
        sombreador = gpu.shader.from_builtin("POLYLINE_UNIFORM_COLOR")
        lote = batch_for_shader(sombreador, "LINES", {"pos": linhas})
        regiao = bpy.context.region
        sombreador.uniform_float("viewportSize", (regiao.width, regiao.height))
        sombreador.uniform_float("lineWidth", VISOR.espessura_das_arestas_px)
        sombreador.uniform_float("color", VISOR.cor_das_arestas)
        lote.draw(sombreador)
    gpu.state.blend_set("NONE")
    gpu.state.depth_test_set(estado_da_profundidade)


def _desenhar_letras() -> None:
    if not _na_vista_do_olho() or not bpy.context.scene.visor_da_sala.letras:
        return
    try:
        sala = visor.sala_do_visor(bpy.context.scene)
    except RuntimeError:
        return
    regiao, r3d = bpy.context.region, bpy.context.region_data
    olho = r3d.view_matrix.inverted().translation
    blf.size(0, VISOR.tamanho_das_letras_px)
    blf.color(0, *VISOR.cor_das_letras)
    for nome, cantos in superficies(sala).items():
        if nome == VISOR.superficie_do_piso:
            continue
        alturas = sorted(cantos, key=lambda p: _altura(p, sala))
        topo = (alturas[-1] + alturas[-2]) / 2
        para_o_topo = topo - olho
        if para_o_topo.dot(r3d.view_rotation @ Vector((0.0, 0.0, -1.0))) <= 0:
            continue
        ponto = location_3d_to_region_2d(regiao, r3d, topo)
        if ponto is None:
            continue
        letra = nome.split()[-1]
        largura, altura = blf.dimensions(0, letra)
        blf.position(0, ponto.x - largura / 2, ponto.y - altura - VISOR.letras_abaixo_do_topo_px, 0)
        blf.draw(0, letra)


def register() -> None:
    _desenhos.append((bpy.types.SpaceView3D.draw_handler_add(_desenhar_na_cena, (), "WINDOW", "POST_VIEW"), "WINDOW"))
    _desenhos.append((bpy.types.SpaceView3D.draw_handler_add(_desenhar_letras, (), "WINDOW", "POST_PIXEL"), "WINDOW"))


def unregister() -> None:
    for desenho, regiao in _desenhos:
        bpy.types.SpaceView3D.draw_handler_remove(desenho, regiao)
    _desenhos.clear()
