"""Lê dados.json, ao lado deste arquivo. Não depende do Blender, para os scripts do nuvens-blender lerem o mesmo arquivo."""
import json
from dataclasses import dataclass
from pathlib import Path

ARQUIVO = Path(__file__).resolve().parent / "dados.json"


@dataclass(frozen=True)
class AoSoltar:
    propriedade: str
    propriedade_do_lugar: str


@dataclass(frozen=True)
class Visor:
    propriedade_da_sala: str
    propriedade_da_superficie: str
    superficie_do_piso: str
    ponto_de_vista: str
    nome_do_olhar: str
    nome_da_imagem: str
    escala: float
    campo_padrao: float
    campo_minimo: float
    campo_maximo: float
    inclinacao_maxima: float
    inclinacao_do_piso: float
    atraso_s: float
    graus_por_pixel: float
    graus_por_passo_da_roda: float
    marca_da_janela: str
    intervalo_da_janela_s: float
    prefixo_da_superficie: str
    cor_das_arestas: tuple[float, float, float, float]
    espessura_das_arestas_px: float
    cor_das_letras: tuple[float, float, float, float]
    tamanho_das_letras_px: int
    letras_abaixo_do_topo_px: float
    cor_do_teto: tuple[float, float, float, float]


def _tabela(arquivo: Path) -> dict[str, dict[str, object]]:
    return json.loads(arquivo.read_text(encoding="utf-8"))


def _rgba(valor: object) -> tuple[float, float, float, float]:
    cor = tuple(float(c) for c in valor)
    if len(cor) != 4:
        raise ValueError(f"cor precisa de RGBA (quatro números de 0 a 1); veio {valor}")
    return cor


def ao_soltar(arquivo: Path = ARQUIVO) -> AoSoltar:
    a = _tabela(arquivo)["ao_soltar"]
    return AoSoltar(str(a["propriedade"]), str(a["propriedade_do_lugar"]))


def visor(arquivo: Path = ARQUIVO) -> Visor:
    v = _tabela(arquivo)["visor"]
    campo = [float(c) for c in v["campo_graus"]]
    if len(campo) != 3 or not campo[1] <= campo[0] <= campo[2]:
        raise ValueError(f"visor.campo_graus precisa de (padrão, mínimo, máximo), com o padrão entre os dois; veio {campo}")
    return Visor(str(v["propriedade_da_sala"]), str(v["propriedade_da_superficie"]), str(v["superficie_do_piso"]),
                 str(v["ponto_de_vista"]), str(v["nome_do_olhar"]), str(v["nome_da_imagem"]), float(v["escala"]),
                 campo[0], campo[1], campo[2], float(v["inclinacao_maxima_graus"]), float(v["inclinacao_do_piso_graus"]),
                 float(v["atraso_s"]), float(v["graus_por_pixel"]),
                 float(v["graus_por_passo_da_roda"]), str(v["marca_da_janela"]), float(v["intervalo_da_janela_s"]),
                 str(v["prefixo_da_superficie"]), _rgba(v["cor_das_arestas"]), float(v["espessura_das_arestas_px"]),
                 _rgba(v["cor_das_letras"]), int(v["tamanho_das_letras_px"]), float(v["letras_abaixo_do_topo_px"]),
                 _rgba(v["cor_do_teto"]))
