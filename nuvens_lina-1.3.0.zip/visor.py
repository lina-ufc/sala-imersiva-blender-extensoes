"""Visor da sala: a fita das quatro paredes com o piso embaixo, como a projeção recebe.

Renderiza a cena pelas cinco câmeras da sala, com o motor e os ajustes de render da cena, numa fração da resolução, e
junta as imagens numa só, que se vê num Image Editor. As câmeras e o lugar de cada imagem na fita vêm das propriedades
gravadas nelas pelo sala-unity (resolução, recorte, espelhamento, anamorfose); os nomes e limites, de dados.json.

Na barra lateral da 3D View (N), aba "Sala": atualizar o visor, abrir a janela do visor, acompanhar o quadro, olhar por
uma superfície e olhar do ponto de vista (uma câmera no olho do público, com giro, inclinação e campo de visão). O botão
"Visor da sala", no cabeçalho da 3D View, abre a janela do visor: em cima, a vista do olho, livre e sem os desenhos de
ajuda, no lugar e no rumo da câmera do olho e do formato da janela; embaixo, a fita. Na vista do olho, arrastar com o
botão do meio do mouse ou com dois dedos no trackpad gira o olho no lugar (giro e inclinação), e a roda ou a pinça
abrem e fecham o campo de visão.

Serve à sala vinculada direto na cena (as cenas prontas), à liberada com Library Override e à copiada pela Tomada
modelo. A sala que chegou como instância (um vazio que mostra a coleção) não serve: as câmeras dela não acompanham o
vazio, e o visor pede o Library Override.
"""
import math
import os
import tempfile

import bpy
import numpy as np

from . import dados

VISOR = dados.visor()


def _e_sala(objeto: bpy.types.Object) -> bool:
    return VISOR.propriedade_da_sala in objeto


def salas(cena: bpy.types.Scene) -> list[bpy.types.Object]:
    return [objeto for objeto in cena.objects if _e_sala(objeto)]


def instancias_de_sala(cena: bpy.types.Scene) -> list[bpy.types.Object]:
    return [objeto for objeto in cena.objects
            if objeto.instance_type == "COLLECTION" and objeto.instance_collection is not None
            and any(_e_sala(o) for o in objeto.instance_collection.all_objects)]


def sala_do_visor(cena: bpy.types.Scene) -> bpy.types.Object:
    escolhida = cena.visor_da_sala.sala
    if escolhida is not None:
        return escolhida
    encontradas = salas(cena)
    if len(encontradas) == 1:
        return encontradas[0]
    if encontradas:
        raise RuntimeError(f"A cena tem {len(encontradas)} salas: escolha uma em Sala do visor.")
    instancias = instancias_de_sala(cena)
    if instancias:
        raise RuntimeError(f'A sala "{instancias[0].name}" está como instância: selecione-a e use '
                           "Object > Library Override > Make, ou solte a sala de novo com o complemento ligado.")
    raise RuntimeError("A cena não tem sala: traga a Sala do Asset Browser (Ferramentas > Sala).")


def cameras_da_sala(sala: bpy.types.Object) -> list[bpy.types.Object]:
    cameras = [filho for filho in sala.children if VISOR.propriedade_da_superficie in filho]
    if len(cameras) != 5:
        raise RuntimeError(f'A sala "{sala.name}" tem {len(cameras)} câmeras; esperadas 5 (quatro paredes e o piso).')
    return cameras


def por_camera(cena: bpy.types.Scene, camera: bpy.types.Object, escala: float) -> None:
    cena.camera = camera
    cena.render.resolution_x = max(1, round(camera["resolucao_x"] * escala))
    cena.render.resolution_y = max(1, round(camera["resolucao_y"] * escala))
    cena.render.resolution_percentage = 100
    cena.render.pixel_aspect_x = 1.0
    cena.render.pixel_aspect_y = camera["anamorfose"]


def renderizar(cena: bpy.types.Scene, camera: bpy.types.Object, escala: float, pasta: str) -> np.ndarray:
    """A imagem de uma câmera, em linhas de baixo para cima como o Blender guarda, RGBA em float."""
    por_camera(cena, camera, escala)
    cena.render.filepath = os.path.join(pasta, f"{camera[VISOR.propriedade_da_superficie]}.png")
    bpy.ops.render.render(write_still=True, scene=cena.name)
    imagem = bpy.data.images.load(cena.render.filepath)
    try:
        largura, altura = imagem.size
        pixels = np.empty(largura * altura * 4, np.float32)
        imagem.pixels.foreach_get(pixels)
    finally:
        bpy.data.images.remove(imagem)
    pixels = pixels.reshape(altura, largura, 4)
    return pixels[:, ::-1] if camera["espelhar_no_visor"] else pixels


def atualizar(cena: bpy.types.Scene) -> bpy.types.Image:
    """Renderiza as cinco câmeras e monta a fita com o piso centrado embaixo. Devolve a cena como estava."""
    sala = sala_do_visor(cena)
    escala = cena.visor_da_sala.escala
    largura = round(sala["largura_da_fita"] * escala)
    altura_da_fita = round(sala["altura_da_fita"] * escala)
    cameras = cameras_da_sala(sala)
    piso = next(c for c in cameras if c[VISOR.propriedade_da_superficie] == VISOR.superficie_do_piso)
    altura_do_piso = round(piso["resolucao_y"] * escala)

    render = cena.render
    antes = (cena.camera, render.resolution_x, render.resolution_y, render.resolution_percentage,
             render.pixel_aspect_x, render.pixel_aspect_y, render.filepath, render.image_settings.file_format)
    quadro = np.zeros((altura_da_fita + altura_do_piso, largura, 4), np.float32)
    quadro[..., 3] = 1.0
    try:
        render.image_settings.file_format = "PNG"
        with tempfile.TemporaryDirectory(prefix="visor-da-sala-") as pasta:
            for camera in cameras:
                imagem = renderizar(cena, camera, escala, pasta)
                altura, largura_da_imagem = imagem.shape[:2]
                if camera is piso:
                    x = max(0, (largura - largura_da_imagem) // 2)
                    quadro[:altura, x:x + largura_da_imagem] = imagem[:, :largura - x]
                    continue
                x = round(camera["recorte_x"] * escala)
                fim = min(largura, x + largura_da_imagem)
                quadro[altura_do_piso:altura_do_piso + altura, x:fim] = imagem[:, :fim - x]
    finally:
        (cena.camera, render.resolution_x, render.resolution_y, render.resolution_percentage,
         render.pixel_aspect_x, render.pixel_aspect_y, render.filepath, render.image_settings.file_format) = antes

    imagem = bpy.data.images.get(VISOR.nome_da_imagem)
    if imagem is None or tuple(imagem.size) != (largura, quadro.shape[0]):
        if imagem is not None:
            bpy.data.images.remove(imagem)
        imagem = bpy.data.images.new(VISOR.nome_da_imagem, largura, quadro.shape[0], alpha=False)
    imagem.pixels.foreach_set(quadro.ravel())
    imagem.update()
    return imagem


def ponto_de_vista(sala: bpy.types.Object) -> bpy.types.Object:
    ponto = next((filho for filho in sala.children if filho.name.startswith(VISOR.ponto_de_vista)), None)
    if ponto is None:
        raise RuntimeError(f'A sala "{sala.name}" não tem o "{VISOR.ponto_de_vista}".')
    return ponto


def giro_de_frente_para(sala: bpy.types.Object, superficie: str) -> float:
    """O giro, em graus no espaço da sala, que põe o centro da superfície no meio da vista, a partir do olho."""
    camera = next(c for c in cameras_da_sala(sala) if c[VISOR.propriedade_da_superficie] == superficie)
    para_a_frente = camera.matrix_basis.to_3x3().col[2] * -1.0
    return math.degrees(math.atan2(-para_a_frente.x, para_a_frente.y))


def primeira_parede(sala: bpy.types.Object) -> str:
    return next(c[VISOR.propriedade_da_superficie] for c in cameras_da_sala(sala)
                if c[VISOR.propriedade_da_superficie] != VISOR.superficie_do_piso)


def olhar(cena: bpy.types.Scene) -> bpy.types.Object:
    """A câmera do olho, criada na primeira vez como objeto do arquivo do artista, na coleção da cena, presa ao ponto de
    vista da sala (que pode ser vinculado), e posta no giro, na inclinação e no campo do painel."""
    sala = sala_do_visor(cena)
    ponto = ponto_de_vista(sala)
    camera = next((filho for filho in ponto.children if filho.name.startswith(VISOR.nome_do_olhar)), None)
    if camera is None:
        camera = bpy.data.objects.new(VISOR.nome_do_olhar, bpy.data.cameras.new(VISOR.nome_do_olhar))
        camera.parent = ponto
        cena.collection.objects.link(camera)
        camera.data.sensor_fit = "VERTICAL"
        camera.data.clip_start = 0.05
        camera.data.clip_end = 500.0
        camera.hide_render = False
        cena.visor_da_sala["giro"] = giro_de_frente_para(sala, primeira_parede(sala))
    visor = cena.visor_da_sala
    camera.rotation_mode = "XYZ"
    camera.rotation_euler = (math.radians(90.0 + visor.inclinacao), 0.0, math.radians(visor.giro))
    camera.data.angle_y = math.radians(visor.campo)
    return camera


def _ao_mudar_o_olhar(_grupo: "VisorDaSala", contexto: bpy.types.Context) -> None:
    if not salas(contexto.scene) and contexto.scene.visor_da_sala.sala is None:
        return
    seguir_o_olho(contexto.scene, olhar(contexto.scene))


def _redesenhar_o_olho(_grupo: "VisorDaSala", _contexto: bpy.types.Context) -> None:
    for area, _regiao in vistas_do_olho():
        area.tag_redraw()


# O Blender desenha a vista livre com um sensor de 72 mm na maior dimensão da área (36 mm vezes o zoom 2 da perspectiva).
MEIO_SENSOR_DA_VISTA_MM = 36.0


def vistas_do_olho() -> list[tuple[bpy.types.Area, bpy.types.Region]]:
    """As 3D Views das janelas do visor (a tela marcada com `marca_da_janela`), com a região de desenho de cada uma."""
    vistas = []
    for janela in bpy.context.window_manager.windows:
        if not janela.screen.get(VISOR.marca_da_janela):
            continue
        for area in janela.screen.areas:
            if area.type == "VIEW_3D":
                vistas.append((area, next(r for r in area.regions if r.type == "WINDOW")))
    return vistas


def pos_no_olho(area: bpy.types.Area, regiao: bpy.types.Region, camera: bpy.types.Object, campo: float) -> None:
    """A vista livre no lugar e no rumo da câmera do olho, ocupando a área inteira, com `campo` graus na vertical. Sem
    vista pela câmera não há quadro nem faixa fora dele, e o formato é o da janela."""
    espaco = area.spaces.active
    r3d = espaco.region_3d
    largura, altura = max(regiao.width, 1), max(regiao.height, 1)
    meia_tangente = math.tan(math.radians(campo) / 2.0)
    espaco.lens = MEIO_SENSOR_DA_VISTA_MM / (meia_tangente * max(largura, altura) / altura)
    espaco.clip_start, espaco.clip_end = camera.data.clip_start, camera.data.clip_end
    r3d.view_perspective = "PERSP"
    r3d.view_distance = 0.0
    r3d.view_location = camera.matrix_world.translation
    r3d.view_rotation = camera.matrix_world.to_quaternion()
    area.tag_redraw()


def seguir_o_olho(cena: bpy.types.Scene, camera: bpy.types.Object) -> None:
    bpy.context.view_layer.update()
    for area, regiao in vistas_do_olho():
        pos_no_olho(area, regiao, camera, cena.visor_da_sala.campo)


_tamanhos: dict[int, tuple[int, int]] = {}


def _acompanhar_as_janelas() -> float | None:
    """Refaz a vista do olho quando a janela do visor muda de tamanho. Para sozinho quando não há janela do visor."""
    vistas = vistas_do_olho()
    if not vistas:
        _tamanhos.clear()
        return None
    for area, regiao in vistas:
        tamanho = (regiao.width, regiao.height)
        if _tamanhos.get(area.as_pointer()) != tamanho:
            _tamanhos[area.as_pointer()] = tamanho
            cena = bpy.context.window_manager.windows[0].scene
            try:
                pos_no_olho(area, regiao, olhar(cena), cena.visor_da_sala.campo)
            except RuntimeError as erro:
                print(f"Visor da sala: {erro}")
    return VISOR.intervalo_da_janela_s


def _encaixar_imagem(janela: bpy.types.Window, area: bpy.types.Area) -> None:
    """A fita inteira à vista. Roda depois de a janela nova ser desenhada, quando a área já tem tamanho."""
    regiao = next(r for r in area.regions if r.type == "WINDOW")
    with bpy.context.temp_override(window=janela, area=area, region=regiao):
        bpy.ops.image.view_all(fit_view=True)
    return None


def mostrar(contexto: bpy.types.Context, imagem: bpy.types.Image) -> None:
    for area in contexto.screen.areas:
        if area.type == "IMAGE_EDITOR":
            area.spaces.active.image = imagem
            area.tag_redraw()


class VisorDaSala(bpy.types.PropertyGroup):
    escala: bpy.props.FloatProperty(name="Escala", description="Fração da resolução da sala em que o visor renderiza",
                                    default=VISOR.escala, min=0.05, max=1.0)
    acompanhar: bpy.props.BoolProperty(name="Acompanhar o quadro",
                                       description="Atualiza o visor quando o quadro muda (fora da reprodução)")
    sala: bpy.props.PointerProperty(name="Sala do visor", type=bpy.types.Object,
                                    poll=lambda _grupo, objeto: _e_sala(objeto),
                                    description="Vazio: a única sala da cena")
    giro: bpy.props.FloatProperty(name="Giro", description="Para onde o público olha, em graus no espaço da sala",
                                  default=0.0, min=-180.0, max=180.0, update=_ao_mudar_o_olhar)
    inclinacao: bpy.props.FloatProperty(name="Inclinação", description="Para cima (+) ou para o piso (-), em graus",
                                        default=0.0, min=-VISOR.inclinacao_maxima, max=VISOR.inclinacao_maxima,
                                        update=_ao_mudar_o_olhar)
    campo: bpy.props.FloatProperty(name="Campo de visão", description="Campo de visão vertical, em graus",
                                   default=VISOR.campo_padrao, min=VISOR.campo_minimo, max=VISOR.campo_maximo,
                                   update=_ao_mudar_o_olhar)
    arestas: bpy.props.BoolProperty(name="Arestas da sala", description="Na vista do olho, as bordas das paredes e do piso",
                                    default=True, update=_redesenhar_o_olho)
    letras: bpy.props.BoolProperty(name="Letras das paredes", description="Na vista do olho, a letra no topo de cada parede",
                                   default=True, update=_redesenhar_o_olho)
    teto: bpy.props.BoolProperty(name="Teto", description="Na vista do olho, o teto da sala, que não recebe projeção",
                                 default=True, update=_redesenhar_o_olho)


class SALA_OT_atualizar_visor(bpy.types.Operator):
    bl_idname = "sala.atualizar_visor"
    bl_label = "Atualizar visor"
    bl_description = "Renderiza as cinco câmeras da sala e monta a fita com o piso"

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        try:
            imagem = atualizar(contexto.scene)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}
        mostrar(contexto, imagem)
        return {"FINISHED"}


class SALA_OT_abrir_visor(bpy.types.Operator):
    bl_idname = "sala.abrir_visor"
    bl_label = "Abrir visor"
    bl_description = "Abre uma janela com o ponto de vista em cima, ao vivo, e a fita com o piso embaixo"

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        cena = contexto.scene
        try:
            imagem = bpy.data.images.get(VISOR.nome_da_imagem) or atualizar(cena)
            camera = olhar(cena)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}

        bpy.ops.wm.window_new()
        janela = contexto.window_manager.windows[-1]
        janela.screen[VISOR.marca_da_janela] = True
        area = max(janela.screen.areas, key=lambda a: a.width * a.height)
        area.type = "VIEW_3D"
        antes = set(janela.screen.areas)
        with contexto.temp_override(window=janela, screen=janela.screen, area=area):
            bpy.ops.screen.area_split(direction="HORIZONTAL", factor=0.4)
        # A área de antes fica em cima, e a nova, com a fração pedida, embaixo.
        nova = next(a for a in janela.screen.areas if a not in antes)
        nova.type = "IMAGE_EDITOR"
        nova.spaces.active.image = imagem
        bpy.app.timers.register(lambda: _encaixar_imagem(janela, nova), first_interval=0.0)

        vista = area.spaces.active
        vista.shading.type = "MATERIAL"
        vista.overlay.show_overlays = False
        vista.show_gizmo = False
        regiao = next(r for r in area.regions if r.type == "WINDOW")
        pos_no_olho(area, regiao, camera, cena.visor_da_sala.campo)
        if not bpy.app.timers.is_registered(_acompanhar_as_janelas):
            bpy.app.timers.register(_acompanhar_as_janelas, first_interval=0.0)
        return {"FINISHED"}


class SALA_OT_olhar_pela_superficie(bpy.types.Operator):
    bl_idname = "sala.olhar_pela_superficie"
    bl_label = "Olhar pela superfície"
    bl_description = "Faz da câmera desta superfície a câmera da cena, com a resolução dela, e olha por ela"

    superficie: bpy.props.StringProperty()

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        try:
            sala = sala_do_visor(contexto.scene)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}
        camera = next((c for c in cameras_da_sala(sala) if c[VISOR.propriedade_da_superficie] == self.superficie), None)
        if camera is None:
            self.report({"ERROR"}, f'Sem câmera para "{self.superficie}".')
            return {"CANCELLED"}
        por_camera(contexto.scene, camera, 1.0)
        if contexto.space_data is not None and contexto.space_data.type == "VIEW_3D":
            contexto.space_data.region_3d.view_perspective = "CAMERA"
        return {"FINISHED"}


class SALA_OT_olhar_do_ponto_de_vista(bpy.types.Operator):
    bl_idname = "sala.olhar_do_ponto_de_vista"
    bl_label = "Olhar do ponto de vista"
    bl_description = "Põe a vista na câmera do olho do público, de frente para uma superfície"

    superficie: bpy.props.StringProperty(default="")

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        cena = contexto.scene
        visor = cena.visor_da_sala
        try:
            sala = sala_do_visor(cena)
            if self.superficie == VISOR.superficie_do_piso:
                visor.inclinacao = -VISOR.inclinacao_do_piso
            elif self.superficie:
                visor.giro = giro_de_frente_para(sala, self.superficie)
                visor.inclinacao = 0.0
            camera = olhar(cena)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}
        cena.camera = camera
        cena.render.pixel_aspect_x = cena.render.pixel_aspect_y = 1.0
        if contexto.space_data is not None and contexto.space_data.type == "VIEW_3D":
            contexto.space_data.region_3d.view_perspective = "CAMERA"
        return {"FINISHED"}


def _olhando_pelo_olho(contexto: bpy.types.Context) -> bool:
    """A 3D View é a vista do olho do público: a da janela do visor, ou uma vista pela câmera do olho."""
    espaco = contexto.space_data
    if espaco is None or espaco.type != "VIEW_3D" or espaco.region_3d is None:
        return False
    if contexto.screen is not None and contexto.screen.get(VISOR.marca_da_janela):
        return True
    if espaco.region_3d.view_perspective != "CAMERA":
        return False
    camera = espaco.camera if espaco.use_local_camera else contexto.scene.camera
    return camera is not None and camera.name.startswith(VISOR.nome_do_olhar)


def _girar_o_olho(cena: bpy.types.Scene, dx: float, dy: float) -> None:
    """Arrastar para a direita olha para a direita, e para cima olha para cima. O giro dá a volta em ±180°."""
    visor = cena.visor_da_sala
    giro = visor.giro - dx * VISOR.graus_por_pixel
    visor.giro = (giro + 180.0) % 360.0 - 180.0
    visor.inclinacao = max(-VISOR.inclinacao_maxima, min(VISOR.inclinacao_maxima, visor.inclinacao + dy * VISOR.graus_por_pixel))


class SALA_OT_girar_o_olho(bpy.types.Operator):
    bl_idname = "sala.girar_o_olho"
    bl_label = "Girar o olho"
    bl_description = "Gira o olho do público no lugar, arrastando na vista pela câmera do olho"
    bl_options = {"BLOCKING", "GRAB_CURSOR"}

    @classmethod
    def poll(cls, contexto: bpy.types.Context) -> bool:
        return _olhando_pelo_olho(contexto)

    def invoke(self, contexto: bpy.types.Context, evento: bpy.types.Event) -> set[str]:
        visor = contexto.scene.visor_da_sala
        if evento.type in {"WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
            passo = -VISOR.graus_por_passo_da_roda if evento.type == "WHEELUPMOUSE" else VISOR.graus_por_passo_da_roda
            visor.campo = max(VISOR.campo_minimo, min(VISOR.campo_maximo, visor.campo + passo))
            return {"FINISHED"}
        if evento.type == "TRACKPADZOOM":
            passo = (evento.mouse_y - evento.mouse_prev_y) * VISOR.graus_por_pixel
            visor.campo = max(VISOR.campo_minimo, min(VISOR.campo_maximo, visor.campo - passo))
            return {"FINISHED"}
        if evento.type == "TRACKPADPAN":
            _girar_o_olho(contexto.scene, evento.mouse_x - evento.mouse_prev_x, evento.mouse_y - evento.mouse_prev_y)
            return {"FINISHED"}
        self._botao = evento.type
        self._x, self._y = evento.mouse_x, evento.mouse_y
        contexto.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, contexto: bpy.types.Context, evento: bpy.types.Event) -> set[str]:
        if evento.type == "MOUSEMOVE":
            _girar_o_olho(contexto.scene, evento.mouse_x - self._x, evento.mouse_y - self._y)
            self._x, self._y = evento.mouse_x, evento.mouse_y
            return {"RUNNING_MODAL"}
        if (evento.type == self._botao and evento.value == "RELEASE") or evento.type in {"ESC", "RIGHTMOUSE"}:
            return {"FINISHED"}
        return {"RUNNING_MODAL"}


def _botao_no_cabecalho(menu: bpy.types.Header, _contexto: bpy.types.Context) -> None:
    menu.layout.operator(SALA_OT_abrir_visor.bl_idname, text="Visor da sala", icon="WINDOW")


class SALA_PT_visor(bpy.types.Panel):
    bl_label = "Visor da sala"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Sala"

    def draw(self, contexto: bpy.types.Context) -> None:
        layout = self.layout
        visor = contexto.scene.visor_da_sala
        if len(salas(contexto.scene)) > 1:
            layout.prop(visor, "sala")
        layout.prop(visor, "escala")
        layout.prop(visor, "acompanhar")
        linha = layout.row(align=True)
        linha.operator(SALA_OT_atualizar_visor.bl_idname, icon="RENDER_STILL")
        linha.operator(SALA_OT_abrir_visor.bl_idname, icon="WINDOW")
        try:
            cameras = cameras_da_sala(sala_do_visor(contexto.scene))
        except RuntimeError as erro:
            layout.label(text=str(erro), icon="ERROR")
            return
        coluna = layout.column(align=True)
        coluna.label(text="Olhar pela superfície")
        for camera in cameras:
            nome = camera[VISOR.propriedade_da_superficie]
            coluna.operator(SALA_OT_olhar_pela_superficie.bl_idname, text=nome).superficie = nome

        caixa = layout.box()
        caixa.operator(SALA_OT_olhar_do_ponto_de_vista.bl_idname, icon="HIDE_OFF").superficie = ""
        linha = caixa.row(align=True)
        linha.label(text="Encarar")
        for camera in cameras:
            nome = camera[VISOR.propriedade_da_superficie]
            rotulo = "piso" if nome == VISOR.superficie_do_piso else nome.split()[-1]
            linha.operator(SALA_OT_olhar_do_ponto_de_vista.bl_idname, text=rotulo).superficie = nome
        caixa.prop(visor, "giro")
        caixa.prop(visor, "inclinacao")
        caixa.prop(visor, "campo")
        linha = caixa.row(align=True)
        linha.prop(visor, "arestas", toggle=True)
        linha.prop(visor, "letras", toggle=True)
        linha.prop(visor, "teto", toggle=True)


class SALA_PT_visor_na_imagem(bpy.types.Panel):
    bl_label = "Visor da sala"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Sala"

    def draw(self, contexto: bpy.types.Context) -> None:
        self.layout.prop(contexto.scene.visor_da_sala, "acompanhar")
        self.layout.operator(SALA_OT_atualizar_visor.bl_idname, icon="RENDER_STILL")


def _atualizar_depois() -> None:
    if bpy.context.screen is not None and bpy.context.screen.is_animation_playing:
        return None
    try:
        imagem = atualizar(bpy.context.scene)
    except RuntimeError as erro:
        print(f"Visor da sala: {erro}")
        return None
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type == "IMAGE_EDITOR" and area.spaces.active.image == imagem:
                area.tag_redraw()
    return None


@bpy.app.handlers.persistent
def ao_mudar_o_quadro(cena: bpy.types.Scene, _grafo: object = None) -> None:
    if bpy.app.background or not cena.visor_da_sala.acompanhar:
        return
    if bpy.app.timers.is_registered(_atualizar_depois):
        bpy.app.timers.unregister(_atualizar_depois)
    bpy.app.timers.register(_atualizar_depois, first_interval=VISOR.atraso_s)


CLASSES = (VisorDaSala, SALA_OT_atualizar_visor, SALA_OT_abrir_visor, SALA_OT_olhar_pela_superficie,
           SALA_OT_olhar_do_ponto_de_vista, SALA_OT_girar_o_olho, SALA_PT_visor, SALA_PT_visor_na_imagem)
# Na vista pela câmera do olho, estes eventos giram o olho; fora dela, o poll falha e o Blender orbita como sempre.
EVENTOS_DO_OLHO = (("MIDDLEMOUSE", "PRESS"), ("TRACKPADPAN", "ANY"), ("WHEELUPMOUSE", "PRESS"), ("WHEELDOWNMOUSE", "PRESS"),
                   ("TRACKPADZOOM", "ANY"))
_atalhos: list[tuple[bpy.types.KeyMap, bpy.types.KeyMapItem]] = []


def register() -> None:
    for classe in CLASSES:
        bpy.utils.register_class(classe)
    bpy.types.Scene.visor_da_sala = bpy.props.PointerProperty(type=VisorDaSala)
    bpy.app.handlers.frame_change_post.append(ao_mudar_o_quadro)
    bpy.types.VIEW3D_HT_header.append(_botao_no_cabecalho)
    configuracao = bpy.context.window_manager.keyconfigs.addon
    if configuracao is None:
        return
    mapa = configuracao.keymaps.new(name="3D View", space_type="VIEW_3D")
    for tipo, valor in EVENTOS_DO_OLHO:
        _atalhos.append((mapa, mapa.keymap_items.new(SALA_OT_girar_o_olho.bl_idname, tipo, valor)))


def unregister() -> None:
    if bpy.app.timers.is_registered(_acompanhar_as_janelas):
        bpy.app.timers.unregister(_acompanhar_as_janelas)
    for mapa, atalho in _atalhos:
        mapa.keymap_items.remove(atalho)
    _atalhos.clear()
    bpy.types.VIEW3D_HT_header.remove(_botao_no_cabecalho)
    bpy.app.handlers.frame_change_post.remove(ao_mudar_o_quadro)
    if bpy.app.timers.is_registered(_atualizar_depois):
        bpy.app.timers.unregister(_atualizar_depois)
    del bpy.types.Scene.visor_da_sala
    for classe in reversed(CLASSES):
        bpy.utils.unregister_class(classe)
