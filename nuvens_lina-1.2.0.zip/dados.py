"""Lê dados.json, ao lado deste arquivo. Não depende do Blender, para os scripts do nuvens-blender lerem o mesmo arquivo."""
import json
from dataclasses import dataclass
from pathlib import Path

ARQUIVO = Path(__file__).resolve().parent / "dados.json"


@dataclass(frozen=True)
class AoSoltar:
    propriedade: str
    propriedade_do_lugar: str


@dataclass(frozen=True)
class Visor:
    propriedade_da_sala: str
    propriedade_da_superficie: str
    superficie_do_piso: str
    ponto_de_vista: str
    nome_do_olhar: str
    nome_da_imagem: str
    escala: float
    campo_padrao: float
    campo_minimo: float
    campo_maximo: float
    inclinacao_maxima: float
    inclinacao_do_piso: float
    atraso_s: float
    graus_por_pixel: float


def _tabela(arquivo: Path) -> dict[str, dict[str, object]]:
    return json.loads(arquivo.read_text(encoding="utf-8"))


def ao_soltar(arquivo: Path = ARQUIVO) -> AoSoltar:
    a = _tabela(arquivo)["ao_soltar"]
    return AoSoltar(str(a["propriedade"]), str(a["propriedade_do_lugar"]))


def visor(arquivo: Path = ARQUIVO) -> Visor:
    v = _tabela(arquivo)["visor"]
    campo = [float(c) for c in v["campo_graus"]]
    if len(campo) != 3 or not campo[1] <= campo[0] <= campo[2]:
        raise ValueError(f"visor.campo_graus precisa de (padrão, mínimo, máximo), com o padrão entre os dois; veio {campo}")
    return Visor(str(v["propriedade_da_sala"]), str(v["propriedade_da_superficie"]), str(v["superficie_do_piso"]),
                 str(v["ponto_de_vista"]), str(v["nome_do_olhar"]), str(v["nome_da_imagem"]), float(v["escala"]),
                 campo[0], campo[1], campo[2], float(v["inclinacao_maxima_graus"]), float(v["inclinacao_do_piso_graus"]),
                 float(v["atraso_s"]), float(v["graus_por_pixel"]))
