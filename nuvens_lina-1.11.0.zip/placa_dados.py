"""Lê o bloco `modo_leve.placa` do dados.json: os valores do desenho pela placa. Sem bpy, como `dados.py`."""
import json
import sys
from dataclasses import dataclass
from pathlib import Path

from . import dados


@dataclass(frozen=True)
class Controle:
    nome: str
    descricao: str
    partida: float
    minimo: float
    maximo: float
    passo: float


@dataclass(frozen=True)
class Selo:
    texto: str
    tamanho_px: int
    margem_px: int
    preenchimento_px: int
    cor_do_texto: tuple[float, float, float, float]
    cor_do_fundo: tuple[float, float, float, float]


@dataclass(frozen=True)
class Painel:
    aviso_do_modo: str
    aviso_da_luz: str
    linhas_maximas: int
    largura_do_texto: int       # em caracteres, para quebrar os avisos
    carregando: str
    resumo: str                 # {placa}, {gn} e {ocultas}: quantas peças em cada estado


@dataclass(frozen=True)
class Contorno:
    cor: tuple[float, float, float, float]
    escala_do_ponto: float      # quantas vezes o ponto da peça selecionada, por trás dele


@dataclass(frozen=True)
class LuzDePartida:
    direcao: tuple[float, float, float]
    cor: tuple[float, float, float]
    forca: float
    ambiente: tuple[float, float, float]


@dataclass(frozen=True)
class Placa:
    nome_do_grupo: str
    atributo_da_cor: str
    entrada_do_tamanho: str
    entrada_dos_pontos: str
    nome_do_botao: str
    descricao_do_botao: str
    teto_de_pontos: Controle              # em milhões
    escala_do_ponto: Controle
    nome_da_luz: str
    descricao_da_luz: str
    pontos_maximos_por_peca: int
    memoria_maxima_mb: int                # a do sistema em que o Blender roda
    intervalo_da_carga_s: float
    ponto_minimo_px: float
    ponto_maximo_px: float
    luzes_maximas: int
    planos_maximos: int
    ubos_em_anel: int
    luz_de_partida: LuzDePartida
    divisor_da_luz_de_ponto: float
    semente: int
    contorno: Contorno
    selo: Selo
    painel: Painel
    motivos: dict[str, str]


def _controle(t: dict) -> Controle:
    c = Controle(str(t["nome"]), str(t["descricao"]), float(t["partida"]), float(t["minimo"]), float(t["maximo"]),
                 float(t.get("passo", 0)))
    if not c.minimo <= c.partida <= c.maximo:
        raise ValueError(f"modo_leve.placa: precisa de mínimo <= partida <= máximo; veio {c}")
    return c


def _vetor(valor: object, tamanho: int) -> tuple[float, ...]:
    v = tuple(float(x) for x in valor)  # type: ignore[attr-defined]
    if len(v) != tamanho:
        raise ValueError(f"modo_leve.placa: esperava {tamanho} números; veio {valor}")
    return v


def placa(arquivo: Path = dados.ARQUIVO, sistema: str | None = None) -> Placa:
    sistema = sys.platform if sistema is None else sistema
    m = json.loads(arquivo.read_text(encoding="utf-8"))["modo_leve"]
    p = m["placa"]
    memoria = p["memoria_maxima_mb"]
    s, e = p["selo"], p["painel"]
    luz = p["luz_de_partida"]
    resultado = Placa(
        str(p["nome_do_grupo"]), str(p["atributo_da_cor"]), str(p["entrada_do_tamanho"]), str(p["entrada_dos_pontos"]), str(p["botao"]["nome"]),
        str(p["botao"]["descricao"]), _controle(p["teto_de_pontos"]), _controle(p["escala_do_ponto"]), str(p["com_luz"]["nome"]),
        str(p["com_luz"]["descricao"]), int(p["pontos_maximos_por_peca"]), int(memoria.get(sistema, memoria["padrao"])),
        float(p["intervalo_da_carga_s"]), float(p["ponto_minimo_px"]), float(p["ponto_maximo_px"]), int(p["luzes_maximas"]),
        int(p["planos_maximos"]), int(p["ubos_em_anel"]),
        LuzDePartida(_vetor(luz["direcao"], 3), _vetor(luz["cor"], 3), float(luz["forca"]), _vetor(luz["ambiente"], 3)),  # type: ignore[arg-type]
        float(p["divisor_da_luz_de_ponto"]), int(m["semente"]),
        Contorno(_vetor(p["contorno"]["cor"], 4), float(p["contorno"]["escala_do_ponto"])),  # type: ignore[arg-type]
        Selo(str(s["texto"]), int(s["tamanho_px"]), int(s["margem_px"]), int(s["preenchimento_px"]),
             _vetor(s["cor_do_texto"], 4), _vetor(s["cor_do_fundo"], 4)),  # type: ignore[arg-type]
        Painel(str(e["aviso_do_modo"]), str(e["aviso_da_luz"]), int(e["linhas_maximas"]), int(e["largura_do_texto"]), str(e["carregando"]), str(e["resumo"])),
        {str(k): str(v) for k, v in p["motivos"].items()})
    if resultado.luzes_maximas < 1 or resultado.planos_maximos < 1 or resultado.ubos_em_anel < 1:
        raise ValueError("modo_leve.placa: luzes_maximas, planos_maximos e ubos_em_anel precisam ser pelo menos 1")
    if resultado.contorno.escala_do_ponto <= 1:
        raise ValueError("modo_leve.placa.contorno: a escala do ponto precisa passar de 1, ou o contorno não aparece")
    if not 0 < resultado.ponto_minimo_px <= resultado.ponto_maximo_px:
        raise ValueError("modo_leve.placa: o ponto mínimo na tela precisa ser positivo e não passar do máximo")
    return resultado
