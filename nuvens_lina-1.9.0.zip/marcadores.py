"""Marcadores da linha do tempo presos a uma câmera trocam a câmera da cena a cada render: o Blender põe de volta a câmera
do marcador do quadro, por cima da que o script escolheu. Quem renderiza por outra câmera solta os marcadores durante o
render e os devolve depois. Sem bpy, para o teste rodar fora do Blender."""
from collections.abc import Iterable, Iterator
from contextlib import contextmanager
from typing import Protocol


class Marcador(Protocol):
    camera: object | None


@contextmanager
def soltos_da_camera(marcadores: Iterable[Marcador]) -> Iterator[None]:
    """Tira a câmera de cada marcador que tem uma e devolve a mesma câmera ao sair, mesmo com erro no meio."""
    presos = [(marcador, marcador.camera) for marcador in marcadores if marcador.camera is not None]
    for marcador, _ in presos:
        marcador.camera = None
    try:
        yield
    finally:
        for marcador, camera in presos:
            marcador.camera = camera
