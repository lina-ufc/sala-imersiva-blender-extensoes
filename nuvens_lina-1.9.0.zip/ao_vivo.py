"""Visor ao vivo: as cinco superfícies da sala desenhadas como a 3D View se desenha, e não renderizadas.

Cada superfície é desenhada pela câmera dela numa textura fora da tela (`GPUOffScreen.draw_view3d`), com os Pontos na
janela. A janela da Sala (a sala simulada, marcas.py) e a da Fita (Image Editor) mostram essas texturas, e qualquer uma
delas, aberta sozinha, as desenha. Mexer na cena, mudar o quadro ou o shading refaz as texturas depois de `atraso_s`
parado; durante a reprodução, só quando ela para.

O desenho usa a 3D View de uma tela do Blender que nenhuma janela mostra (`nome_da_fonte`, criada na primeira vez, como o
Camera Viewer faz), sem as sobreposições (grade, câmeras, luzes). O shading do visor é o dela: muda pelo cabeçalho da sala
simulada, como em qualquer 3D View, ou pelos ícones de shading no cabeçalho da Fita, e as duas ficam iguais. A sala
simulada não mostra a cena: as superfícies a cobrem toda, porque o olho está dentro da sala, e girar o olho não desenha a
cena. O Rendered só serve quando o motor da cena desenha fora da tela (Eevee, Workbench); com o Cycles, sairia preto, e o
visor volta ao `shading_de_partida`. Para ver a fita com o render da cena, o painel tem Renderizar a fita (renderizar.py).

No Material Preview e no Rendered do Eevee, o visor desenha com `passadas_do_visor` passadas, e não com as da cena: fora da
tela, o Eevee faz todas de uma vez para cada superfície (com 16, segundos por parede), enquanto a janela faz uma por quadro.
As da cena voltam logo depois do desenho.

O desenho fora da tela é copiado para uma textura simples e liberado em seguida. Guardado até o Blender fechar, ele seria
liberado pelo Python depois de o Blender já ter liberado o arquivo, e o Blender caía ao sair.
"""
import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Matrix

from . import visor
from .visor import SALA, VISOR

# Motores que desenham em Rendered fora da tela; com os outros, o visor não fica no Rendered.
MOTORES_DA_VISTA = {"BLENDER_EEVEE", "BLENDER_EEVEE_NEXT", "BLENDER_WORKBENCH"}
# Shadings que o Eevee desenha. Fora da tela, ele faz todas as passadas de uma vez, e não uma por quadro como na janela.
SHADINGS_DO_EEVEE = {"MATERIAL", "RENDERED"}

_texturas: dict[str, gpu.types.GPUTexture] = {}
_estado: dict = {"sujo": False, "assinatura": None, "assinatura_da_sala": None, "desenhando": False, "passadas_da_cena": None,
                 "ignorar_a_troca": False}
_desenhos: list[tuple[type, object]] = []


def vistas() -> list[bpy.types.Area]:
    """As salas simuladas abertas (a 3D View de cada janela da Sala)."""
    return [area for area, _regiao in visor.vistas_do_olho()]


def aberto() -> bool:
    """Se há alguma janela do visor aberta, da Sala ou da Fita."""
    return any(janela.screen.get(VISOR.marca_da_janela) for janela in bpy.context.window_manager.windows)


def _area_da_fonte() -> bpy.types.Area | None:
    """A 3D View que desenha as texturas, na tela `nome_da_fonte`, que nenhuma janela mostra; nada antes de `fonte`."""
    tela = bpy.data.screens.get(VISOR.nome_da_fonte)
    areas = [] if tela is None else [a for a in tela.areas if a.type == "VIEW_3D"]
    return max(areas, key=lambda a: a.width * a.height) if areas else None


def criar_a_fonte(contexto: bpy.types.Context) -> None:
    """Na primeira vez, a tela da fonte, cópia da tela da janela de onde o visor é aberto, com a maior área como 3D View.
    Roda no operador que abre a janela do visor, antes dela."""
    if bpy.data.screens.get(VISOR.nome_da_fonte) is not None:
        return
    janela = contexto.window
    original = janela.screen
    antes = set(bpy.data.screens)
    bpy.ops.screen.new()
    tela = next(s for s in bpy.data.screens if s not in antes)
    tela.name = VISOR.nome_da_fonte
    janela.screen = original
    area = max(tela.areas, key=lambda a: a.width * a.height)
    if area.type != "VIEW_3D":
        area.type = "VIEW_3D"


def fonte() -> bpy.types.Area | None:
    """A 3D View da fonte, pronta para desenhar. Não roda dentro de um desenho, que não aceita mudanças."""
    area = _area_da_fonte()
    if area is None:
        return None
    espaco = area.spaces.active
    if espaco.overlay.show_overlays:
        espaco.overlay.show_overlays = False
    if espaco.show_gizmo:
        espaco.show_gizmo = False
    mostrar_a_cena(area, True)
    return area


def desenhando_fora_da_tela() -> bool:
    """Enquanto as texturas são desenhadas: os desenhos da sala simulada (marcas.py) ficam de fora delas."""
    return _estado["desenhando"]


def mostrar_a_cena(area: bpy.types.Area, mostrar: bool) -> None:
    espaco = area.spaces.active
    for propriedade in espaco.bl_rna.properties:
        if propriedade.identifier.startswith("show_object_viewport_") and getattr(espaco, propriedade.identifier) != mostrar:
            setattr(espaco, propriedade.identifier, mostrar)


def _trocar_as_passadas(cena: bpy.types.Scene, passadas: int) -> None:
    """A troca refaz o grafo da cena inteira; a atualização que ela produz não pede outro desenho."""
    if cena.eevee.taa_samples == passadas:
        return
    cena.eevee.taa_samples = passadas
    _estado["ignorar_a_troca"] = True


def _baixar_as_passadas(cena: bpy.types.Scene, tipo: str) -> None:
    if tipo not in SHADINGS_DO_EEVEE:
        return
    if _estado["passadas_da_cena"] is None:
        _estado["passadas_da_cena"] = cena.eevee.taa_samples
    _trocar_as_passadas(cena, VISOR.passadas_do_visor)


def _devolver_as_passadas(cena: bpy.types.Scene) -> None:
    if _estado["passadas_da_cena"] is None:
        return
    _trocar_as_passadas(cena, _estado["passadas_da_cena"])
    _estado["passadas_da_cena"] = None


def preparar_a_vista(area: bpy.types.Area) -> None:
    """A sala simulada sem a cena, sem sobreposições e sem gizmos, e com o cabeçalho, onde fica o shading do visor."""
    espaco = area.spaces.active
    espaco.overlay.show_overlays = False
    espaco.show_gizmo = False
    espaco.show_region_header = True
    mostrar_a_cena(area, False)


def _propriedades_do_shading(shading: bpy.types.View3DShading) -> list[str]:
    return [p.identifier for p in shading.bl_rna.properties
            if not p.is_readonly and p.type not in {"POINTER", "COLLECTION"} and p.identifier != "rna_type"]


def _assinatura(espaco: bpy.types.SpaceView3D) -> tuple:
    valores = [getattr(espaco.shading, nome) for nome in _propriedades_do_shading(espaco.shading)]
    return tuple(tuple(v) if hasattr(v, "__len__") and not isinstance(v, str) else v for v in valores)


def _copiar_shading(origem: bpy.types.SpaceView3D, destino: bpy.types.SpaceView3D) -> None:
    """O tipo primeiro, depois a luz e o resto: a lista das luzes de estúdio muda com o tipo e com a luz."""
    destino.shading.type = origem.shading.type
    destino.shading.light = origem.shading.light
    for nome in _propriedades_do_shading(origem.shading):
        if nome not in {"type", "light"}:
            setattr(destino.shading, nome, getattr(origem.shading, nome))


def _igualar_os_shadings(espaco: bpy.types.SpaceView3D) -> bool:
    """Leva à fonte o shading mudado no cabeçalho de uma sala simulada, e o da fonte às salas simuladas. Diz se o da fonte
    mudou desde o último desenho."""
    salas = [area.spaces.active for area in vistas()]
    mudada = next((s for s in salas if _assinatura(s) != _estado["assinatura_da_sala"]), None)
    if mudada is not None and _estado["assinatura_da_sala"] is not None:
        _copiar_shading(mudada, espaco)
    for sala in salas:
        if _assinatura(sala) != _assinatura(espaco):
            _copiar_shading(espaco, sala)
    _estado["assinatura_da_sala"] = _assinatura(espaco)
    return _assinatura(espaco) != _estado["assinatura"]


def _shading_que_desenha(espaco: bpy.types.SpaceView3D, motor: str) -> None:
    """O Rendered com um motor que não desenha fora da tela (o Cycles) sairia preto: o visor volta ao `shading_de_partida`."""
    if espaco.shading.type == "RENDERED" and motor not in MOTORES_DA_VISTA:
        espaco.shading.type = VISOR.shading_de_partida


def tela_da_fita(cena: bpy.types.Scene) -> bpy.types.Image:
    """A imagem preta do tamanho da fita, sobre a qual o Image Editor desenha as texturas (a fita ao vivo)."""
    largura, altura = (max(1, round(t * cena.visor_da_sala.escala)) for t in visor.tamanho_da_fita())
    imagem = bpy.data.images.get(VISOR.nome_da_imagem)
    if imagem is None:
        imagem = bpy.data.images.new(VISOR.nome_da_imagem, largura, altura, alpha=False)
    elif tuple(imagem.size) != (largura, altura):
        imagem.scale(largura, altura)
    else:
        return imagem
    imagem.pixels.foreach_set([0.0, 0.0, 0.0, 1.0] * (largura * altura))
    imagem.update()
    return imagem


def _redesenhar(tipos: set[str]) -> None:
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type in tipos:
                area.tag_redraw()


def _refazer() -> None:
    """Pede as texturas no próximo desenho de uma janela do visor."""
    cena = bpy.context.window_manager.windows[0].scene if bpy.context.window_manager.windows else None
    if cena is None or not aberto():
        return None
    area = fonte()
    if area is None:
        return None
    espaco = area.spaces.active
    _igualar_os_shadings(espaco)
    _shading_que_desenha(espaco, cena.render.engine)
    _igualar_os_shadings(espaco)
    _estado["assinatura"] = _assinatura(espaco)
    _baixar_as_passadas(cena, espaco.shading.type)
    tela_da_fita(cena)
    _estado["sujo"] = True
    _redesenhar({"VIEW_3D"})
    return None


def pedir() -> None:
    """Refaz as texturas depois de `atraso_s` sem novo pedido."""
    if bpy.app.background:
        return
    if bpy.app.timers.is_registered(_refazer):
        bpy.app.timers.unregister(_refazer)
    bpy.app.timers.register(_refazer, first_interval=VISOR.atraso_s)


def _seguir_o_shading() -> float | None:
    """Pede um desenho novo quando o shading do visor muda, numa sala simulada ou na Fita. Para sozinho sem janela do
    visor."""
    if not aberto():
        return None
    area = fonte()
    if area is not None and _igualar_os_shadings(area.spaces.active):
        pedir()
    return VISOR.intervalo_da_janela_s


def seguir() -> None:
    if not bpy.app.timers.is_registered(_seguir_o_shading):
        bpy.app.timers.register(_seguir_o_shading, first_interval=0.0)
    pedir()


def textura(superficie: str) -> gpu.types.GPUTexture | None:
    return _texturas.get(superficie)


def _copiar(origem: gpu.types.GPUTexture, destino: gpu.types.GPUTexture) -> None:
    """Desenha `origem` cobrindo `destino` inteiro, sem mistura."""
    sombreador = gpu.shader.from_builtin("IMAGE")
    lote = batch_for_shader(sombreador, "TRI_FAN", {"pos": [(-1.0, -1.0, 0.0), (1.0, -1.0, 0.0), (1.0, 1.0, 0.0), (-1.0, 1.0, 0.0)],
                                                    "texCoord": [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]})
    quadro = gpu.types.GPUFrameBuffer(color_slots=destino)
    with quadro.bind():
        quadro.viewport_set(0, 0, destino.width, destino.height)
        gpu.state.blend_set("NONE")
        with gpu.matrix.push_pop(), gpu.matrix.push_pop_projection():
            gpu.matrix.load_identity()
            gpu.matrix.load_projection_matrix(Matrix.Identity(4))
            sombreador.uniform_sampler("image", origem)
            lote.draw(sombreador)


def _desenhar_as_superficies() -> None:
    """No desenho de qualquer 3D View, com uma janela do visor aberta e um pedido: cada superfície pela câmera dela, no
    tamanho dela na fita, pela 3D View da fonte."""
    contexto = bpy.context
    if not _estado["sujo"] or not aberto():
        return
    _estado["sujo"] = False
    cena = contexto.scene
    area = _area_da_fonte()
    if area is None:
        return
    regiao = next(r for r in area.regions if r.type == "WINDOW")
    try:
        cameras = visor.cameras_da_sala(visor.sala_do_visor(cena))
    except RuntimeError as erro:
        print(f"Visor da sala: {erro}")
        return
    grafo = contexto.evaluated_depsgraph_get()
    escala = cena.visor_da_sala.escala
    for camera in cameras:
        nome = camera[VISOR.propriedade_da_superficie]
        superficie = SALA.superficie(nome)
        largura = max(1, round(superficie.largura_m * SALA.pixels_por_metro * escala))
        altura = max(1, round(superficie.altura_m * SALA.pixels_por_metro * escala))
        guardada = _texturas.get(nome)
        if guardada is None or (guardada.width, guardada.height) != (largura, altura):
            guardada = _texturas[nome] = gpu.types.GPUTexture((largura, altura), format="RGBA8")
        fora = gpu.types.GPUOffScreen(largura, altura)
        _estado["desenhando"] = True
        try:
            fora.draw_view3d(cena, contexto.view_layer, area.spaces.active, regiao, camera.matrix_world.inverted(),
                             camera.calc_matrix_camera(grafo, x=largura, y=altura), do_color_management=True)
            _copiar(fora.texture_color, guardada)
        finally:
            _estado["desenhando"] = False
            fora.free()
    if not bpy.app.timers.is_registered(_depois_do_desenho):
        bpy.app.timers.register(_depois_do_desenho, first_interval=0.0)


def _depois_do_desenho() -> None:
    """Fora do desenho: o pedido de redesenho feito dentro dele se perde na janela que está sendo desenhada."""
    _redesenhar({"VIEW_3D", "IMAGE_EDITOR"})
    if bpy.context.window_manager.windows:
        _devolver_as_passadas(bpy.context.window_manager.windows[0].scene)


def _no_cabecalho_da_fita(menu: bpy.types.Header, contexto: bpy.types.Context) -> None:
    """Na janela da Fita, os ícones de shading do visor, os mesmos do cabeçalho da sala simulada."""
    if contexto.screen is None or not contexto.screen.get(VISOR.marca_da_janela):
        return
    area = _area_da_fonte()
    if area is not None:
        menu.layout.prop(area.spaces.active.shading, "type", expand=True, icon_only=True)


def _desenhar_na_fita() -> None:
    """No Image Editor com a fita ao vivo, cada textura no retângulo da superfície, espelhada como na fita renderizada."""
    contexto = bpy.context
    espaco = contexto.space_data
    if espaco is None or espaco.image is None or espaco.image.name != VISOR.nome_da_imagem:
        return
    try:
        sala = visor.sala_do_visor(contexto.scene)
        cameras = {c[VISOR.propriedade_da_superficie]: c for c in visor.cameras_da_sala(sala)}
        lugares = visor.lugares_na_fita(contexto.scene.visor_da_sala.primeira_da_fita)
    except RuntimeError:
        return
    largura_da_fita, altura_da_fita = visor.tamanho_da_fita()
    no_ecra = contexto.region.view2d.view_to_region
    sombreador = gpu.shader.from_builtin("IMAGE")
    for nome, (x, y, w, h) in lugares.items():
        textura_ = textura(nome)
        if textura_ is None:
            continue
        x0, y0 = no_ecra(x / largura_da_fita, y / altura_da_fita, clip=False)
        x1, y1 = no_ecra(min(1.0, (x + w) / largura_da_fita), (y + h) / altura_da_fita, clip=False)
        u0, u1 = (1.0, 0.0) if cameras[nome]["espelhar_no_visor"] else (0.0, 1.0)
        lote = batch_for_shader(sombreador, "TRI_FAN", {"pos": [(x0, y0, 0.0), (x1, y0, 0.0), (x1, y1, 0.0), (x0, y1, 0.0)],
                                                        "texCoord": [(u0, 0.0), (u1, 0.0), (u1, 1.0), (u0, 1.0)]})
        sombreador.uniform_sampler("image", textura_)
        lote.draw(sombreador)


def _muda_as_superficies(grafo: bpy.types.Depsgraph) -> bool:
    """Se a atualização mexe no que as câmeras da sala veem. Fica de fora a cena sem nada marcado, que é o que esconder a
    cena na sala simulada produz."""
    for atualizacao in grafo.updates:
        marcada = atualizacao.is_updated_geometry or atualizacao.is_updated_transform or atualizacao.is_updated_shading
        if isinstance(atualizacao.id, bpy.types.Scene) and not marcada:
            continue
        return True
    return False


@bpy.app.handlers.persistent
def _ao_mudar(_cena: bpy.types.Scene, grafo: bpy.types.Depsgraph | None = None) -> None:
    if _estado["ignorar_a_troca"]:
        _estado["ignorar_a_troca"] = False
        return
    if not aberto() or (grafo is not None and not _muda_as_superficies(grafo)):
        return
    tela = bpy.context.screen
    if tela is not None and tela.is_animation_playing:
        return
    pedir()


@bpy.app.handlers.persistent
def _ao_mudar_o_quadro(_cena: bpy.types.Scene, _grafo: object = None) -> None:
    """Ao mudar o quadro, fora da reprodução, e ao parar a reprodução."""
    tela = bpy.context.screen
    if aberto() and not (tela is not None and tela.is_animation_playing):
        pedir()


@bpy.app.handlers.persistent
def _ao_abrir(_arquivo: str, _grafo: object = None) -> None:
    """Num arquivo salvo com a janela do visor, as texturas recomeçam do zero."""
    _texturas.clear()
    _estado["assinatura"] = _estado["assinatura_da_sala"] = None
    if aberto():
        seguir()


HANDLERS = ((bpy.app.handlers.depsgraph_update_post, _ao_mudar), (bpy.app.handlers.frame_change_post, _ao_mudar_o_quadro),
            (bpy.app.handlers.animation_playback_post, _ao_mudar_o_quadro), (bpy.app.handlers.load_post, _ao_abrir))


def register() -> None:
    # As texturas saem no desenho de uma 3D View: dentro do desenho do Image Editor, o desenho fora da tela faz a Fita
    # parar de se redesenhar.
    _desenhos.append((bpy.types.SpaceView3D,
                      bpy.types.SpaceView3D.draw_handler_add(_desenhar_as_superficies, (), "WINDOW", "POST_PIXEL")))
    _desenhos.append((bpy.types.SpaceImageEditor,
                      bpy.types.SpaceImageEditor.draw_handler_add(_desenhar_na_fita, (), "WINDOW", "POST_PIXEL")))
    for lista, funcao in HANDLERS:
        lista.append(funcao)
    bpy.types.IMAGE_HT_header.append(_no_cabecalho_da_fita)


def unregister() -> None:
    for funcao in (_refazer, _seguir_o_shading, _depois_do_desenho):
        if bpy.app.timers.is_registered(funcao):
            bpy.app.timers.unregister(funcao)
    bpy.types.IMAGE_HT_header.remove(_no_cabecalho_da_fita)
    for lista, funcao in HANDLERS:
        lista.remove(funcao)
    for espaco, desenho in _desenhos:
        espaco.draw_handler_remove(desenho, "WINDOW")
    _desenhos.clear()
    _texturas.clear()
