"""A sala simulada na vista do olho do visor (a 3D View da janela do visor, onde a cena fica escondida): cada superfície
com o desenho dela ao vivo (ao_vivo.py), e por cima as arestas da sala, a letra de cada parede, o teto e a porta. Na fita (o Image
Editor com a imagem do visor), o contorno e a letra de cada parede, o contorno do piso e a porta. Não criam objeto nem
mudam a cena ou a imagem: são só desenho; as marcas se ligam e desligam no painel (Arestas, Letras, Teto, Divisórias,
Porta)."""
import math

import blf
import bpy
import gpu
from bpy_extras.view3d_utils import location_3d_to_region_2d
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

from . import ao_vivo, visor
from .visor import VISOR

_desenhos: list[tuple[type, object]] = []


def _na_vista_do_olho() -> bool:
    """A sala simulada da janela do visor, fora do desenho das texturas (que passa pela mesma vista)."""
    tela = bpy.context.screen
    return tela is not None and bool(tela.get(VISOR.marca_da_janela)) and not ao_vivo.desenhando_fora_da_tela()


def superficies(sala: bpy.types.Object) -> dict[str, list[Vector]]:
    """Os cantos de cada superfície da sala, no mundo, pelo nome dela (o mesmo da câmera: "Parede A", "Piso")."""
    cantos: dict[str, list[Vector]] = {}
    for filho in sala.children:
        if filho.type != "MESH" or not filho.name.startswith(VISOR.prefixo_da_superficie):
            continue
        nome = filho.name.removeprefix(VISOR.prefixo_da_superficie)
        cantos[nome] = [filho.matrix_world @ v.co for v in filho.data.vertices]
    return cantos


def _altura(ponto: Vector, sala: bpy.types.Object) -> float:
    return ponto.dot(sala.matrix_world.to_3x3().col[2].normalized())


def _em_volta(cantos: list[Vector]) -> list[Vector]:
    """Os cantos do retângulo na ordem em volta do centro."""
    centro = sum(cantos, Vector()) / len(cantos)
    eixo_a = (cantos[0] - centro).normalized()
    eixo_b = (cantos[1] - centro) - (cantos[1] - centro).project(eixo_a)
    eixo_b = eixo_b.normalized() if eixo_b.length > 1e-9 else eixo_a.orthogonal().normalized()
    return sorted(cantos, key=lambda p: math.atan2((p - centro).dot(eixo_b), (p - centro).dot(eixo_a)))


def _bordas(cantos: list[Vector]) -> list[Vector]:
    """As quatro bordas do retângulo, em pares de pontos, na ordem dos cantos em volta do centro."""
    em_volta = _em_volta(cantos)
    pares: list[Vector] = []
    for i, ponto in enumerate(em_volta):
        pares += [ponto, em_volta[(i + 1) % len(em_volta)]]
    return pares


def _projecao(sala: bpy.types.Object, cantos: dict[str, list[Vector]]) -> dict[str, tuple[list[Vector], list[tuple[float, float]]]]:
    """Os triângulos de cada superfície e, em cada canto, onde ele cai na imagem da câmera dela: a direita e o cima da
    imagem nos da câmera."""
    cameras = {c[VISOR.propriedade_da_superficie]: c for c in visor.cameras_da_sala(sala)}
    projecao: dict[str, tuple[list[Vector], list[tuple[float, float]]]] = {}
    for nome, pontos in cantos.items():
        giro = cameras[nome].matrix_world.to_3x3()
        direita, cima = giro.col[0].normalized(), giro.col[1].normalized()
        us, vs = [p.dot(direita) for p in pontos], [p.dot(cima) for p in pontos]
        em_volta = _em_volta(pontos)
        na_imagem = [((p.dot(direita) - min(us)) / (max(us) - min(us)), (p.dot(cima) - min(vs)) / (max(vs) - min(vs)))
                     for p in em_volta]
        indices = (0, 1, 2, 0, 2, 3)
        projecao[nome] = ([em_volta[i] for i in indices], [na_imagem[i] for i in indices])
    return projecao


def _porta_em_fracao() -> list[tuple[float, float]]:
    """O vão da porta (as quatro bordas), as bordas do encosto entre as duas folhas e a barra, em pares de pontos, em
    fração da imagem da parede dela."""
    esquerda, direita, topo, barra, barra_0, barra_1, encosto_0, encosto_1 = visor.SALA.porta_na_parede()
    cantos = [(esquerda, 0.0), (direita, 0.0), (direita, topo), (esquerda, topo)]
    pares: list[tuple[float, float]] = []
    for i, canto in enumerate(cantos):
        pares += [canto, cantos[(i + 1) % 4]]
    return [*pares, (encosto_0, 0.0), (encosto_0, topo), (encosto_1, 0.0), (encosto_1, topo), (barra_0, barra), (barra_1, barra)]


def _porta_na_cena(sala: bpy.types.Object, cantos: dict[str, list[Vector]]) -> list[Vector]:
    """A porta no mundo, sobre a parede dela, com a direita e o cima da câmera dessa parede."""
    nome = visor.SALA.porta.parede
    camera = next(c for c in visor.cameras_da_sala(sala) if c[VISOR.propriedade_da_superficie] == nome)
    giro = camera.matrix_world.to_3x3()
    direita, cima = giro.col[0].normalized(), giro.col[1].normalized()
    pontos = cantos[nome]
    us, vs = [p.dot(direita) for p in pontos], [p.dot(cima) for p in pontos]
    origem = min(pontos, key=lambda p: p.dot(direita) + p.dot(cima))
    largura, altura = max(us) - min(us), max(vs) - min(vs)
    return [origem + direita * (x * largura) + cima * (y * altura) for x, y in _porta_em_fracao()]


def _desenhar_linhas(pontos: list[tuple[float, float, float]], cor: tuple[float, float, float, float], espessura: float) -> None:
    sombreador = gpu.shader.from_builtin("POLYLINE_UNIFORM_COLOR")
    lote = batch_for_shader(sombreador, "LINES", {"pos": pontos})
    regiao = bpy.context.region
    sombreador.uniform_float("viewportSize", (regiao.width, regiao.height))
    sombreador.uniform_float("lineWidth", espessura)
    sombreador.uniform_float("color", cor)
    lote.draw(sombreador)


def _desenhar_a_projecao(sala: bpy.types.Object, cantos: dict[str, list[Vector]]) -> None:
    # As texturas já saem com a gestão de cor da vista; o sombreador só as copia.
    sombreador = gpu.shader.from_builtin("IMAGE")
    for nome, (posicoes, uvs) in _projecao(sala, cantos).items():
        textura = ao_vivo.textura(nome)
        if textura is None:
            continue
        lote = batch_for_shader(sombreador, "TRIS", {"pos": [tuple(p) for p in posicoes], "texCoord": uvs})
        sombreador.uniform_sampler("image", textura)
        lote.draw(sombreador)


def _desenhar_na_cena() -> None:
    if not _na_vista_do_olho():
        return
    cena = bpy.context.scene
    opcoes = cena.visor_da_sala
    try:
        sala = visor.sala_do_visor(cena)
        cantos = superficies(sala)
    except RuntimeError:
        return
    # A cena aparece na vista (é dela que saem as texturas): as superfícies e o teto a cobrem, sem teste de profundidade,
    # porque o olho está dentro da sala. As marcas vão por cima.
    estado_da_profundidade = gpu.state.depth_test_get()
    gpu.state.depth_test_set("NONE")
    _desenhar_a_projecao(sala, cantos)
    gpu.state.blend_set("ALPHA")
    if VISOR.superficie_do_piso in cantos:
        paredes = [p for nome, ps in cantos.items() if nome != VISOR.superficie_do_piso for p in ps]
        piso = cantos[VISOR.superficie_do_piso]
        subir = max(_altura(p, sala) for p in paredes) - max(_altura(p, sala) for p in piso)
        acima = sala.matrix_world.to_3x3().col[2].normalized() * subir
        teto = [p + acima for p in _bordas(piso)[::2]]
        sombreador = gpu.shader.from_builtin("UNIFORM_COLOR")
        lote = batch_for_shader(sombreador, "TRIS", {"pos": [tuple(p) for p in teto]}, indices=[(0, 1, 2), (0, 2, 3)])
        sombreador.uniform_float("color", VISOR.cor_do_teto if opcoes.teto else (*VISOR.cor_fora_da_sala, 1.0))
        lote.draw(sombreador)
    if opcoes.arestas:
        linhas = [tuple(p) for ps in cantos.values() for p in _bordas(ps)]
        _desenhar_linhas(linhas, VISOR.cor_das_arestas, VISOR.espessura_das_arestas_px)
    if opcoes.porta:
        _desenhar_linhas([tuple(p) for p in _porta_na_cena(sala, cantos)], VISOR.cor_da_porta, VISOR.espessura_da_porta_px)
    gpu.state.blend_set("NONE")
    gpu.state.depth_test_set(estado_da_profundidade)


def _desenhar_letras() -> None:
    if not _na_vista_do_olho() or not bpy.context.scene.visor_da_sala.letras:
        return
    try:
        sala = visor.sala_do_visor(bpy.context.scene)
    except RuntimeError:
        return
    regiao, r3d = bpy.context.region, bpy.context.region_data
    olho = r3d.view_matrix.inverted().translation
    blf.size(0, VISOR.tamanho_das_letras_px)
    blf.color(0, *VISOR.cor_das_letras)
    for nome, cantos in superficies(sala).items():
        if nome == VISOR.superficie_do_piso:
            continue
        alturas = sorted(cantos, key=lambda p: _altura(p, sala))
        topo = (alturas[-1] + alturas[-2]) / 2
        para_o_topo = topo - olho
        if para_o_topo.dot(r3d.view_rotation @ Vector((0.0, 0.0, -1.0))) <= 0:
            continue
        ponto = location_3d_to_region_2d(regiao, r3d, topo)
        if ponto is None:
            continue
        letra = nome.split()[-1]
        largura = blf.dimensions(0, letra)[0]
        blf.position(0, ponto.x - largura / 2, ponto.y + VISOR.letras_acima_do_topo_px, 0)
        blf.draw(0, letra)


def retangulos_da_fita(primeira: str) -> dict[str, tuple[float, float, float, float]]:
    """Onde cada superfície fica na fita, em fração da imagem (x0, y0, x1, y1, com y de baixo para cima), pela mesma conta
    da fita ao vivo e de Renderizar a fita (`visor.lugares_na_fita`)."""
    lugares = visor.lugares_na_fita(primeira)
    largura, altura = visor.tamanho_da_fita()
    return {nome: (x / largura, y / altura, min(1.0, (x + w) / largura), (y + h) / altura)
            for nome, (x, y, w, h) in lugares.items()}


def _desenhar_na_fita() -> None:
    espaco = bpy.context.space_data
    opcoes = bpy.context.scene.visor_da_sala
    if espaco is None or espaco.image is None or espaco.image.name not in {VISOR.nome_da_imagem, VISOR.nome_do_render}:
        return
    if not (opcoes.divisorias or opcoes.letras or opcoes.porta):
        return
    try:
        retangulos = retangulos_da_fita(opcoes.primeira_da_fita)
    except RuntimeError:
        return
    regiao = bpy.context.region
    no_ecra = regiao.view2d.view_to_region
    if opcoes.divisorias:
        linhas = []
        for x0, y0, x1, y1 in retangulos.values():
            cantos = [no_ecra(x0, y0, clip=False), no_ecra(x1, y0, clip=False), no_ecra(x1, y1, clip=False),
                      no_ecra(x0, y1, clip=False)]
            for i, canto in enumerate(cantos):
                linhas += [(*canto, 0.0), (*cantos[(i + 1) % 4], 0.0)]
        gpu.state.blend_set("ALPHA")
        _desenhar_linhas(linhas, VISOR.cor_das_divisorias, VISOR.espessura_das_divisorias_px)
        gpu.state.blend_set("NONE")
    if opcoes.porta:
        x0, y0, x1, y1 = retangulos[visor.SALA.porta.parede]
        linhas = [(*no_ecra(x0 + x * (x1 - x0), y0 + y * (y1 - y0), clip=False), 0.0) for x, y in _porta_em_fracao()]
        gpu.state.blend_set("ALPHA")
        _desenhar_linhas(linhas, VISOR.cor_da_porta, VISOR.espessura_da_porta_px)
        gpu.state.blend_set("NONE")
    if opcoes.letras:
        blf.size(0, VISOR.tamanho_das_letras_px)
        blf.color(0, *VISOR.cor_das_letras)
        for nome, (x0, _y0, x1, y1) in retangulos.items():
            if nome == VISOR.superficie_do_piso:
                continue
            letra = nome.split()[-1]
            x, y = no_ecra((x0 + x1) / 2, y1, clip=False)
            blf.position(0, x - blf.dimensions(0, letra)[0] / 2, y + VISOR.letras_acima_do_topo_px, 0)
            blf.draw(0, letra)


def register() -> None:
    _desenhos.append((bpy.types.SpaceView3D, bpy.types.SpaceView3D.draw_handler_add(_desenhar_na_cena, (), "WINDOW", "POST_VIEW")))
    _desenhos.append((bpy.types.SpaceView3D, bpy.types.SpaceView3D.draw_handler_add(_desenhar_letras, (), "WINDOW", "POST_PIXEL")))
    _desenhos.append((bpy.types.SpaceImageEditor,
                      bpy.types.SpaceImageEditor.draw_handler_add(_desenhar_na_fita, (), "WINDOW", "POST_PIXEL")))


def unregister() -> None:
    for espaco, desenho in _desenhos:
        espaco.draw_handler_remove(desenho, "WINDOW")
    _desenhos.clear()
