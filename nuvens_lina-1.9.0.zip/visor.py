"""Visor da sala, a parte do editor: a fita das quatro paredes com o piso embaixo, como o público vai ver a sala, e a
sala simulada vista do olho do público. Não cria nada no arquivo do artista além da imagem da fita; o que sai pelo motor
da cena e as câmeras ficam em renderizar.py.

A fita fica num Image Editor: a sala aberta no chão, com todas as superfícies na mesma escala, pelas medidas em metros do
sala.json, e não nos pixels de cada projetor (o piso tem menos pixels por metro que as paredes). Ela é desenhada ao vivo,
como a 3D View (ao_vivo.py). As câmeras são as da Sala, que precisam bater com o sala.json. Os nomes e limites, de
dados.json.

O olho do público não é um objeto: é o lugar, o giro, a inclinação e o campo de visão guardados na cena (`visor_da_sala`),
a partir do ponto de vista da sala, e a vista da janela do visor é posta nele como uma 3D View qualquer.
Na barra lateral da 3D View (N), aba "Sala", painel "Visor da sala": abrir a janela do visor e o olho. O shading do visor é
o da sala simulada, no cabeçalho dela, como em qualquer 3D View.
Os botões Sala e Fita, no cabeçalho da 3D View, abrem cada um a sua janela: a sala simulada, vista do olho, no formato
da janela, e a fita. A vista do olho é a sala simulada: a cena fica escondida, e cada
superfície mostra o pedaço dela na fita (marcas.py), como o público verá a projeção. Nela, arrastar com o botão do meio
do mouse ou com dois dedos no trackpad gira o olho (giro e inclinação), a roda ou a pinça abrem e fecham o campo de visão,
e W, A, S, D ou as setas andam com o olho pela sala.

Serve à sala vinculada direto na cena (as cenas prontas), à liberada com Library Override e à copiada pela Tomada
modelo. A sala que chegou como instância (um vazio que mostra a coleção) não serve: as câmeras dela não acompanham o
vazio, e o visor pede o Library Override.
"""
import math

import bpy
from mathutils import Euler, Matrix

from . import dados

VISOR = dados.visor()
SALA = dados.sala()


def _e_sala(objeto: bpy.types.Object) -> bool:
    return VISOR.propriedade_da_sala in objeto


def salas(cena: bpy.types.Scene) -> list[bpy.types.Object]:
    return [objeto for objeto in cena.objects if _e_sala(objeto)]


def instancias_de_sala(cena: bpy.types.Scene) -> list[bpy.types.Object]:
    return [objeto for objeto in cena.objects
            if objeto.instance_type == "COLLECTION" and objeto.instance_collection is not None
            and any(_e_sala(o) for o in objeto.instance_collection.all_objects)]


def sala_do_visor(cena: bpy.types.Scene) -> bpy.types.Object:
    escolhida = cena.visor_da_sala.sala
    if escolhida is not None:
        return escolhida
    encontradas = salas(cena)
    if len(encontradas) == 1:
        return encontradas[0]
    if encontradas:
        raise RuntimeError(f"A cena tem {len(encontradas)} salas: escolha uma em Sala do visor.")
    instancias = instancias_de_sala(cena)
    if instancias:
        raise RuntimeError(f'A sala "{instancias[0].name}" está como instância: selecione-a e use '
                           "Object > Library Override > Make, ou solte a sala de novo com o complemento ligado.")
    raise RuntimeError("A cena não tem sala: traga a Sala do Asset Browser (Ferramentas > Sala).")


def cameras_da_sala(sala: bpy.types.Object) -> list[bpy.types.Object]:
    cameras = [filho for filho in sala.children if VISOR.propriedade_da_superficie in filho]
    if len(cameras) != 5:
        raise RuntimeError(f'A sala "{sala.name}" tem {len(cameras)} câmeras; esperadas 5 (quatro paredes e o piso).')
    conferir_cameras(sala, cameras)
    return cameras


def conferir_cameras(sala: bpy.types.Object, cameras: list[bpy.types.Object]) -> None:
    """As câmeras da Sala precisam ser as superfícies de sala.json, com a mesma resolução: se não forem, a Sala foi feita
    com outras medidas e precisa ser refeita."""
    nomes = {c[VISOR.propriedade_da_superficie] for c in cameras}
    esperados = {s.nome for s in (*SALA.paredes, SALA.piso)}
    if nomes != esperados:
        raise RuntimeError(f'A sala "{sala.name}" tem as câmeras {sorted(nomes)}; o sala.json do complemento tem {sorted(esperados)}.')
    for camera in cameras:
        s = SALA.superficie(camera[VISOR.propriedade_da_superficie])
        if (int(camera["resolucao_x"]), int(camera["resolucao_y"])) != (s.largura_px, s.altura_px):
            raise RuntimeError(f'A câmera "{s.nome}" da sala "{sala.name}" tem {camera["resolucao_x"]} × {camera["resolucao_y"]} px; '
                               f"o sala.json do complemento diz {s.largura_px} × {s.altura_px}. A Sala está desatualizada.")


def pixels_por_metro() -> float:
    """A escala da fita do visor, a mesma em todas as superfícies: a do master (`pixels_por_metro` do sala.json)."""
    return SALA.pixels_por_metro


def tamanho_da_fita() -> tuple[float, float]:
    """Largura e altura da fita do visor, em pixels: as paredes lado a lado em cima e o piso embaixo, na mesma escala."""
    escala = pixels_por_metro()
    return sum(p.largura_m for p in SALA.paredes) * escala, (SALA.paredes[0].altura_m + SALA.piso.altura_m) * escala


def lugares_na_fita(primeira: str) -> dict[str, tuple[float, float, float, float]]:
    """Onde cada superfície fica na fita do visor, em pixels (x, y a partir de baixo, largura, altura): a sala aberta no chão,
    como ela será vista, com todas as superfícies na mesma escala (`pixels_por_metro`), e não nos pixels de cada projetor. As
    paredes em cima, na ordem do sala.json a partir de `primeira`, e o piso embaixo, centrado sob a parede junto da qual fica
    a borda de cima da imagem dele (`topo_junto_a`)."""
    nomes = [p.nome for p in SALA.paredes]
    for nome in (primeira, SALA.topo_do_piso):
        if nome not in nomes:
            raise RuntimeError(f'O sala.json do complemento não tem a "{nome}"; tem {nomes}.')
    escala = pixels_por_metro()
    largura_da_fita, _ = tamanho_da_fita()
    base = SALA.piso.altura_m * escala
    inicio = nomes.index(primeira)
    lugares: dict[str, tuple[float, float, float, float]] = {}
    x = 0.0
    for parede in SALA.paredes[inicio:] + SALA.paredes[:inicio]:
        lugares[parede.nome] = (x, base, parede.largura_m * escala, parede.altura_m * escala)
        x += parede.largura_m * escala
    x, _, largura_da_parede, _ = lugares[SALA.topo_do_piso]
    largura_do_piso = SALA.piso.largura_m * escala
    x_do_piso = min(max(0.0, x + (largura_da_parede - largura_do_piso) / 2), max(0.0, largura_da_fita - largura_do_piso))
    lugares[SALA.piso.nome] = (x_do_piso, 0.0, largura_do_piso, base)
    return lugares


def ponto_de_vista(sala: bpy.types.Object) -> bpy.types.Object:
    ponto = next((filho for filho in sala.children if filho.name.startswith(VISOR.ponto_de_vista)), None)
    if ponto is None:
        raise RuntimeError(f'A sala "{sala.name}" não tem o "{VISOR.ponto_de_vista}".')
    return ponto


def giro_de_frente_para(sala: bpy.types.Object, superficie: str) -> float:
    """O giro, em graus no espaço da sala, que põe o centro da superfície no meio da vista, a partir do olho."""
    camera = next(c for c in cameras_da_sala(sala) if c[VISOR.propriedade_da_superficie] == superficie)
    para_a_frente = camera.matrix_basis.to_3x3().col[2] * -1.0
    return math.degrees(math.atan2(-para_a_frente.x, para_a_frente.y))


def primeira_parede(sala: bpy.types.Object) -> str:
    return next(c[VISOR.propriedade_da_superficie] for c in cameras_da_sala(sala)
                if c[VISOR.propriedade_da_superficie] != VISOR.superficie_do_piso)


def limites_do_olho(sala: bpy.types.Object) -> tuple[float, float, float, float]:
    """Até onde o olho anda, a partir do ponto de vista e nos eixos dele (x mínimo, x máximo, y mínimo, y máximo): o piso,
    menos `margem_das_paredes_m` de cada lado."""
    ponto = ponto_de_vista(sala)
    piso = next((filho for filho in sala.children if filho.name == VISOR.prefixo_da_superficie + VISOR.superficie_do_piso), None)
    if piso is None:
        raise RuntimeError(f'A sala "{sala.name}" não tem a "{VISOR.prefixo_da_superficie + VISOR.superficie_do_piso}".')
    para_o_ponto = ponto.matrix_world.inverted() @ piso.matrix_world
    cantos = [para_o_ponto @ v.co for v in piso.data.vertices]
    margem = VISOR.margem_das_paredes_m
    return (min(c.x for c in cantos) + margem, max(c.x for c in cantos) - margem,
            min(c.y for c in cantos) + margem, max(c.y for c in cantos) - margem)


def olho_no_ponto_de_vista(cena: bpy.types.Scene) -> Matrix:
    """O olho do público em relação ao ponto de vista da sala: o lugar do painel, levado para dentro da sala
    (`limites_do_olho`), o giro e a inclinação. Olha para -Z, como uma câmera."""
    visor = cena.visor_da_sala
    x0, x1, y0, y1 = limites_do_olho(sala_do_visor(cena))
    # Direto na propriedade, sem passar pelo update, que chamaria esta conta de novo.
    visor["posicao_x"] = min(max(visor.posicao_x, x0), x1)
    visor["posicao_y"] = min(max(visor.posicao_y, y0), y1)
    giro = Euler((math.radians(90.0 + visor.inclinacao), 0.0, math.radians(visor.giro)), "XYZ")
    return Matrix.LocRotScale((visor.posicao_x, visor.posicao_y, 0.0), giro, None)


def olho(cena: bpy.types.Scene) -> Matrix:
    """O olho do público no mundo."""
    return ponto_de_vista(sala_do_visor(cena)).matrix_world @ olho_no_ponto_de_vista(cena)


def _virar_para_a_primeira_parede(cena: bpy.types.Scene) -> None:
    """Na primeira vez que o visor abre na cena, o olho olha para a primeira parede da sala."""
    visor = cena.visor_da_sala
    if "giro" not in visor:
        sala = sala_do_visor(cena)
        visor["giro"] = giro_de_frente_para(sala, primeira_parede(sala))


def _ao_mudar_o_olhar(_grupo: "VisorDaSala", contexto: bpy.types.Context) -> None:
    if not salas(contexto.scene) and contexto.scene.visor_da_sala.sala is None:
        return
    seguir_o_olho(contexto.scene)


def _redesenhar_o_olho(_grupo: "VisorDaSala", _contexto: bpy.types.Context) -> None:
    for area, _regiao in vistas_do_olho():
        area.tag_redraw()


def _redesenhar_a_fita(_grupo: "VisorDaSala", _contexto: bpy.types.Context) -> None:
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type == "IMAGE_EDITOR":
                area.tag_redraw()


def _redesenhar_o_olho_e_a_fita(grupo: "VisorDaSala", contexto: bpy.types.Context) -> None:
    _redesenhar_o_olho(grupo, contexto)
    _redesenhar_a_fita(grupo, contexto)


def _pedir_desenho(_grupo: "VisorDaSala", _contexto: bpy.types.Context) -> None:
    from . import ao_vivo
    ao_vivo.pedir()


# O Blender só guarda a lista de um EnumProperty dinâmico enquanto o Python a referencia.
_paredes_para_escolher: list[tuple[str, str, str]] = []


def _paredes_da_fita(_grupo: "VisorDaSala", _contexto: bpy.types.Context | None) -> list[tuple[str, str, str]]:
    """As paredes na ordem da fita, a começar pela `primeira_parede_da_fita`, que é a primeira da lista e por isso o padrão."""
    ordem = [p.nome for p in SALA.paredes]
    i = ordem.index(VISOR.primeira_parede_da_fita)
    ordem = ordem[i:] + ordem[:i]
    _paredes_para_escolher[:] = [(nome, nome.split()[-1], f"A fita começa pela {nome}") for nome in ordem]
    return _paredes_para_escolher


# O Blender desenha a vista livre com um sensor de 72 mm na maior dimensão da área (36 mm vezes o zoom 2 da perspectiva).
MEIO_SENSOR_DA_VISTA_MM = 36.0


def vistas_do_olho() -> list[tuple[bpy.types.Area, bpy.types.Region]]:
    """As 3D Views das janelas do visor (a tela marcada com `marca_da_janela`), com a região de desenho de cada uma."""
    vistas = []
    for janela in bpy.context.window_manager.windows:
        if not janela.screen.get(VISOR.marca_da_janela):
            continue
        for area in janela.screen.areas:
            if area.type == "VIEW_3D":
                vistas.append((area, next(r for r in area.regions if r.type == "WINDOW")))
    return vistas


def pos_no_olho(area: bpy.types.Area, regiao: bpy.types.Region, olho_: Matrix, campo: float) -> None:
    """A vista livre no lugar e no rumo do olho, ocupando a área inteira, com `campo` graus na vertical. Sem câmera não há
    quadro nem faixa fora dele, e o formato é o da janela."""
    espaco = area.spaces.active
    r3d = espaco.region_3d
    largura, altura = max(regiao.width, 1), max(regiao.height, 1)
    meia_tangente = math.tan(math.radians(campo) / 2.0)
    espaco.lens = MEIO_SENSOR_DA_VISTA_MM / (meia_tangente * max(largura, altura) / altura)
    espaco.clip_start, espaco.clip_end = VISOR.recorte_do_olho
    r3d.view_perspective = "PERSP"
    r3d.view_distance = 0.0
    r3d.view_location = olho_.translation
    r3d.view_rotation = olho_.to_quaternion()
    area.tag_redraw()


def seguir_o_olho(cena: bpy.types.Scene) -> None:
    olho_ = olho(cena)
    for area, regiao in vistas_do_olho():
        pos_no_olho(area, regiao, olho_, cena.visor_da_sala.campo)


_tamanhos: dict[int, tuple[int, int]] = {}


def _acompanhar_as_janelas() -> float | None:
    """Refaz a vista do olho e encaixa a fita de novo quando a janela do visor muda de tamanho. Para sozinho quando não há
    janela do visor."""
    if not any(janela.screen.get(VISOR.marca_da_janela) for janela in bpy.context.window_manager.windows):
        _tamanhos.clear()
        return None
    vistas = vistas_do_olho()
    for janela in bpy.context.window_manager.windows:
        if not janela.screen.get(VISOR.marca_da_janela):
            continue
        for area in janela.screen.areas:
            if area.type == "IMAGE_EDITOR" and _tamanhos.get(area.as_pointer()) != (area.width, area.height):
                _tamanhos[area.as_pointer()] = (area.width, area.height)
                _encaixar_imagem(janela, area)
    for area, regiao in vistas:
        tamanho = (regiao.width, regiao.height)
        if _tamanhos.get(area.as_pointer()) != tamanho:
            _tamanhos[area.as_pointer()] = tamanho
            cena = bpy.context.window_manager.windows[0].scene
            try:
                pos_no_olho(area, regiao, olho(cena), cena.visor_da_sala.campo)
            except RuntimeError as erro:
                print(f"Visor da sala: {erro}")
    return VISOR.intervalo_da_janela_s


def _encaixar_imagem(janela: bpy.types.Window, area: bpy.types.Area) -> None:
    """A fita inteira à vista, ocupando `fracao_da_area_na_fita` da área. Roda depois de a janela ser desenhada, quando a
    área já tem tamanho, e de novo quando ela muda de tamanho."""
    regiao = next(r for r in area.regions if r.type == "WINDOW")
    imagem = area.spaces.active.image
    if imagem is None or 0 in imagem.size:
        return
    # As letras ficam acima das paredes, fora da imagem: a altura delas sobra em cima e embaixo, para a fita ficar no meio.
    letras = VISOR.letras_acima_do_topo_px + VISOR.tamanho_das_letras_px
    zoom = min(regiao.width * VISOR.fracao_da_area_na_fita / imagem.size[0],
               (regiao.height * VISOR.fracao_da_area_na_fita - 2 * letras) / imagem.size[1])
    with bpy.context.temp_override(window=janela, area=area, region=regiao):
        bpy.ops.image.view_all(fit_view=True)
        bpy.ops.image.view_zoom_ratio(ratio=zoom)


class VisorDaSala(bpy.types.PropertyGroup):
    escala: bpy.props.FloatProperty(name="Escala", description="Fração da resolução da sala em que o visor desenha",
                                    default=VISOR.escala, min=0.05, max=1.0, update=_pedir_desenho)
    sala: bpy.props.PointerProperty(name="Sala do visor", type=bpy.types.Object,
                                    poll=lambda _grupo, objeto: _e_sala(objeto),
                                    description="Vazio: a única sala da cena")
    posicao_x: bpy.props.FloatProperty(name="X", description="Onde o olho está, a partir do centro da sala, em metros",
                                       default=0.0, subtype="DISTANCE", update=_ao_mudar_o_olhar)
    posicao_y: bpy.props.FloatProperty(name="Y", description="Onde o olho está, a partir do centro da sala, em metros",
                                       default=0.0, subtype="DISTANCE", update=_ao_mudar_o_olhar)
    inverter_arrasto: bpy.props.BoolProperty(name="Inverter arrasto",
                                             description="Na vista do olho, o arrasto do mouse ou do trackpad vira o olho "
                                                         "para o lado contrário: para a direita, olha para a esquerda; para "
                                                         "cima, olha para baixo",
                                             default=VISOR.inverter_arrasto)
    giro: bpy.props.FloatProperty(name="Giro", description="Para onde o público olha, em graus no espaço da sala",
                                  default=0.0, min=-180.0, max=180.0, update=_ao_mudar_o_olhar)
    inclinacao: bpy.props.FloatProperty(name="Inclinação", description="Para cima (+) ou para o piso (-), em graus",
                                        default=0.0, min=-VISOR.inclinacao_maxima, max=VISOR.inclinacao_maxima,
                                        update=_ao_mudar_o_olhar)
    campo: bpy.props.FloatProperty(name="Campo de visão", description="Campo de visão vertical, em graus",
                                   default=VISOR.campo_padrao, min=VISOR.campo_minimo, max=VISOR.campo_maximo,
                                   update=_ao_mudar_o_olhar)
    arestas: bpy.props.BoolProperty(name="Arestas da sala", description="Na vista do olho, as bordas das paredes e do piso",
                                    default=True, update=_redesenhar_o_olho)
    letras: bpy.props.BoolProperty(name="Letras das paredes",
                                   description="Na vista do olho e na fita, a letra acima de cada parede",
                                   default=True, update=_redesenhar_o_olho_e_a_fita)
    teto: bpy.props.BoolProperty(name="Teto", description="Na vista do olho, o teto da sala, que não recebe projeção",
                                 default=True, update=_redesenhar_o_olho)
    porta: bpy.props.BoolProperty(name="Porta", description="Na vista do olho e na fita, o vão da porta e a barra de abrir",
                                  default=True, update=_redesenhar_o_olho_e_a_fita)
    divisorias: bpy.props.BoolProperty(name="Divisórias", description="Na fita, o contorno de cada parede e do piso",
                                       default=True, update=_redesenhar_a_fita)
    primeira_da_fita: bpy.props.EnumProperty(name="Primeira parede", description="A parede que abre a fita, à esquerda",
                                             items=_paredes_da_fita, default=0,
                                             update=_redesenhar_o_olho_e_a_fita)


def _janela_nova(tipo: str) -> tuple[bpy.types.Window, bpy.types.Area]:
    """Uma janela nova com uma área só, do `tipo` dado, marcada como janela do visor."""
    bpy.ops.wm.window_new()
    janela = bpy.context.window_manager.windows[-1]
    janela.screen[VISOR.marca_da_janela] = True
    area = max(janela.screen.areas, key=lambda a: a.width * a.height)
    for outra in [a for a in janela.screen.areas if a != area]:
        with bpy.context.temp_override(window=janela, screen=janela.screen, area=outra):
            bpy.ops.screen.area_close()
    area.type = tipo
    if not bpy.app.timers.is_registered(_acompanhar_as_janelas):
        bpy.app.timers.register(_acompanhar_as_janelas, first_interval=0.0)
    return janela, area


class SALA_OT_abrir_visor(bpy.types.Operator):
    bl_idname = "sala.abrir_visor"
    bl_label = "Sala"
    bl_description = "Abre uma janela com a sala simulada, vista do olho do público"

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        cena = contexto.scene
        from . import ao_vivo
        try:
            cameras_da_sala(sala_do_visor(cena))
            _virar_para_a_primeira_parede(cena)
            olho_ = olho(cena)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}
        ao_vivo.criar_a_fonte(contexto)
        _janela, area = _janela_nova("VIEW_3D")
        ao_vivo.preparar_a_vista(area)
        regiao = next(r for r in area.regions if r.type == "WINDOW")
        pos_no_olho(area, regiao, olho_, cena.visor_da_sala.campo)
        ao_vivo.seguir()
        return {"FINISHED"}


class SALA_OT_abrir_fita(bpy.types.Operator):
    bl_idname = "sala.abrir_fita"
    bl_label = "Fita"
    bl_description = "Abre uma janela com a fita: as quatro paredes lado a lado e o piso embaixo, como a sala aberta no chão"

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        cena = contexto.scene
        from . import ao_vivo
        try:
            cameras_da_sala(sala_do_visor(cena))
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}
        imagem = ao_vivo.tela_da_fita(cena)
        ao_vivo.criar_a_fonte(contexto)
        _janela, area = _janela_nova("IMAGE_EDITOR")
        area.spaces.active.image = imagem
        ao_vivo.seguir()
        return {"FINISHED"}


class SALA_OT_encarar(bpy.types.Operator):
    bl_idname = "sala.encarar"
    bl_label = "Encarar"
    bl_description = "Vira o olho do público de frente para uma superfície"

    superficie: bpy.props.StringProperty()

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        visor = contexto.scene.visor_da_sala
        try:
            if self.superficie == VISOR.superficie_do_piso:
                visor.inclinacao = -VISOR.inclinacao_do_piso
                return {"FINISHED"}
            visor.giro = giro_de_frente_para(sala_do_visor(contexto.scene), self.superficie)
            visor.inclinacao = 0.0
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}
        return {"FINISHED"}


def _olhando_pelo_olho(contexto: bpy.types.Context) -> bool:
    """A 3D View é a vista do olho do público, a da janela do visor."""
    espaco = contexto.space_data
    if espaco is None or espaco.type != "VIEW_3D":
        return False
    return contexto.screen is not None and bool(contexto.screen.get(VISOR.marca_da_janela))


def _girar_o_olho(cena: bpy.types.Scene, dx: float, dy: float) -> None:
    """Arrastar para a direita olha para a direita, e para cima olha para cima; com `inverter_arrasto`, o contrário. O giro dá a volta em ±180°."""
    visor = cena.visor_da_sala
    if visor.inverter_arrasto:
        dx, dy = -dx, -dy
    giro = visor.giro - dx * VISOR.graus_por_pixel
    visor.giro = (giro + 180.0) % 360.0 - 180.0
    visor.inclinacao = max(-VISOR.inclinacao_maxima, min(VISOR.inclinacao_maxima, visor.inclinacao + dy * VISOR.graus_por_pixel))


class SALA_OT_girar_o_olho(bpy.types.Operator):
    bl_idname = "sala.girar_o_olho"
    bl_label = "Girar o olho"
    bl_description = "Gira o olho do público no lugar, arrastando na vista do olho"
    bl_options = {"BLOCKING", "GRAB_CURSOR"}

    @classmethod
    def poll(cls, contexto: bpy.types.Context) -> bool:
        return _olhando_pelo_olho(contexto)

    def invoke(self, contexto: bpy.types.Context, evento: bpy.types.Event) -> set[str]:
        visor = contexto.scene.visor_da_sala
        if evento.type in {"WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
            passo = -VISOR.graus_por_passo_da_roda if evento.type == "WHEELUPMOUSE" else VISOR.graus_por_passo_da_roda
            visor.campo = max(VISOR.campo_minimo, min(VISOR.campo_maximo, visor.campo + passo))
            return {"FINISHED"}
        if evento.type == "TRACKPADZOOM":
            passo = (evento.mouse_y - evento.mouse_prev_y) * VISOR.graus_por_pixel
            visor.campo = max(VISOR.campo_minimo, min(VISOR.campo_maximo, visor.campo - passo))
            return {"FINISHED"}
        if evento.type == "TRACKPADPAN":
            _girar_o_olho(contexto.scene, evento.mouse_x - evento.mouse_prev_x, evento.mouse_y - evento.mouse_prev_y)
            return {"FINISHED"}
        self._botao = evento.type
        self._x, self._y = evento.mouse_x, evento.mouse_y
        contexto.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, contexto: bpy.types.Context, evento: bpy.types.Event) -> set[str]:
        if evento.type == "MOUSEMOVE":
            _girar_o_olho(contexto.scene, evento.mouse_x - self._x, evento.mouse_y - self._y)
            self._x, self._y = evento.mouse_x, evento.mouse_y
            return {"RUNNING_MODAL"}
        if (evento.type == self._botao and evento.value == "RELEASE") or evento.type in {"ESC", "RIGHTMOUSE"}:
            return {"FINISHED"}
        return {"RUNNING_MODAL"}


def _botao_no_cabecalho(menu: bpy.types.Header, contexto: bpy.types.Context) -> None:
    if contexto.screen is not None and contexto.screen.get(VISOR.marca_da_janela):
        return
    linha = menu.layout.row(align=True)
    linha.operator(SALA_OT_abrir_visor.bl_idname, text=VISOR.rotulo_no_cabecalho, icon="WINDOW")
    linha.operator(SALA_OT_abrir_fita.bl_idname, text=VISOR.rotulo_da_fita_no_cabecalho, icon="IMAGE_DATA")


def _opcoes_da_fita(layout: bpy.types.UILayout, visor: VisorDaSala) -> None:
    linha = layout.row(align=True)
    linha.label(text="Começar por")
    linha.prop(visor, "primeira_da_fita", expand=True)
    linha = layout.row(align=True)
    linha.prop(visor, "divisorias", toggle=True)
    linha.prop(visor, "letras", toggle=True)
    linha.prop(visor, "porta", toggle=True)


def _andar(cena: bpy.types.Scene, frente: float, lado: float) -> None:
    """Anda `frente` e `lado` metros a partir de para onde o olho olha, no chão da sala."""
    visor = cena.visor_da_sala
    giro = math.radians(visor.giro)
    visor.posicao_x += -math.sin(giro) * frente + math.cos(giro) * lado
    visor.posicao_y += math.cos(giro) * frente + math.sin(giro) * lado


class SALA_OT_andar_o_olho(bpy.types.Operator):
    bl_idname = "sala.andar_o_olho"
    bl_label = "Andar com o olho"
    bl_description = "Anda com o olho do público pela sala, a partir de para onde ele olha"

    frente: bpy.props.IntProperty(default=0, min=-1, max=1)
    lado: bpy.props.IntProperty(default=0, min=-1, max=1)

    @classmethod
    def poll(cls, contexto: bpy.types.Context) -> bool:
        return _olhando_pelo_olho(contexto)

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        try:
            _andar(contexto.scene, self.frente * VISOR.passo_do_olho_m, self.lado * VISOR.passo_do_olho_m)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}
        return {"FINISHED"}


class SALA_OT_olho_no_centro(bpy.types.Operator):
    bl_idname = "sala.olho_no_centro"
    bl_label = "Voltar ao centro"
    bl_description = "Põe o olho do público de volta no centro da sala"

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        visor = contexto.scene.visor_da_sala
        visor.posicao_x = 0.0
        visor.posicao_y = 0.0
        return {"FINISHED"}


class SALA_PT_visor(bpy.types.Panel):
    bl_label = "Visor da sala"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Sala"

    def draw(self, contexto: bpy.types.Context) -> None:
        layout = self.layout
        visor = contexto.scene.visor_da_sala
        if len(salas(contexto.scene)) > 1:
            layout.prop(visor, "sala")
        linha = layout.row(align=True)
        linha.operator(SALA_OT_abrir_visor.bl_idname, icon="WINDOW")
        linha.operator(SALA_OT_abrir_fita.bl_idname, icon="IMAGE_DATA")
        layout.prop(visor, "escala")
        _opcoes_da_fita(layout, visor)
        try:
            cameras = cameras_da_sala(sala_do_visor(contexto.scene))
        except RuntimeError as erro:
            layout.label(text=str(erro), icon="ERROR")
            return
        caixa = layout.box()
        caixa.label(text="Olho do público", icon="HIDE_OFF")
        linha = caixa.row(align=True)
        linha.label(text="Encarar")
        for camera in cameras:
            nome = camera[VISOR.propriedade_da_superficie]
            rotulo = "piso" if nome == VISOR.superficie_do_piso else nome.split()[-1]
            linha.operator(SALA_OT_encarar.bl_idname, text=rotulo).superficie = nome
        linha = caixa.row(align=True)
        linha.prop(visor, "posicao_x")
        linha.prop(visor, "posicao_y")
        linha.operator(SALA_OT_olho_no_centro.bl_idname, text="", icon="PIVOT_BOUNDBOX")
        caixa.prop(visor, "inverter_arrasto")
        caixa.prop(visor, "giro")
        caixa.prop(visor, "inclinacao")
        caixa.prop(visor, "campo")
        linha = caixa.row(align=True)
        linha.prop(visor, "arestas", toggle=True)
        linha.prop(visor, "letras", toggle=True)
        linha.prop(visor, "teto", toggle=True)


class SALA_PT_visor_na_imagem(bpy.types.Panel):
    bl_label = "Visor da sala"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Sala"

    def draw(self, contexto: bpy.types.Context) -> None:
        _opcoes_da_fita(self.layout, contexto.scene.visor_da_sala)


CLASSES = (VisorDaSala, SALA_OT_abrir_visor, SALA_OT_abrir_fita, SALA_OT_encarar, SALA_OT_girar_o_olho, SALA_OT_andar_o_olho,
           SALA_OT_olho_no_centro, SALA_PT_visor, SALA_PT_visor_na_imagem)
# Na vista do olho, estes eventos giram o olho; fora dela, o poll falha e o Blender orbita como sempre.
EVENTOS_DO_OLHO = (("MIDDLEMOUSE", "PRESS"), ("TRACKPADPAN", "ANY"), ("WHEELUPMOUSE", "PRESS"), ("WHEELDOWNMOUSE", "PRESS"),
                   ("TRACKPADZOOM", "ANY"))
# Na janela do visor, estas teclas andam com o olho (frente, lado); fora dela, o poll falha e a tecla faz o de sempre.
TECLAS_DE_ANDAR = (("W", 1, 0), ("UP_ARROW", 1, 0), ("S", -1, 0), ("DOWN_ARROW", -1, 0),
                   ("D", 0, 1), ("RIGHT_ARROW", 0, 1), ("A", 0, -1), ("LEFT_ARROW", 0, -1))
_atalhos: list[tuple[bpy.types.KeyMap, bpy.types.KeyMapItem]] = []


def register() -> None:
    for classe in CLASSES:
        bpy.utils.register_class(classe)
    bpy.types.Scene.visor_da_sala = bpy.props.PointerProperty(type=VisorDaSala)
    bpy.types.VIEW3D_HT_header.append(_botao_no_cabecalho)
    configuracao = bpy.context.window_manager.keyconfigs.addon
    if configuracao is None:
        return
    mapa = configuracao.keymaps.new(name="3D View", space_type="VIEW_3D")
    for tipo, valor in EVENTOS_DO_OLHO:
        _atalhos.append((mapa, mapa.keymap_items.new(SALA_OT_girar_o_olho.bl_idname, tipo, valor)))
    for tecla, frente, lado in TECLAS_DE_ANDAR:
        atalho = mapa.keymap_items.new(SALA_OT_andar_o_olho.bl_idname, tecla, "PRESS", repeat=True)
        atalho.properties.frente, atalho.properties.lado = frente, lado
        _atalhos.append((mapa, atalho))


def unregister() -> None:
    if bpy.app.timers.is_registered(_acompanhar_as_janelas):
        bpy.app.timers.unregister(_acompanhar_as_janelas)
    for mapa, atalho in _atalhos:
        mapa.keymap_items.remove(atalho)
    _atalhos.clear()
    bpy.types.VIEW3D_HT_header.remove(_botao_no_cabecalho)
    del bpy.types.Scene.visor_da_sala
    for classe in reversed(CLASSES):
        bpy.utils.unregister_class(classe)
