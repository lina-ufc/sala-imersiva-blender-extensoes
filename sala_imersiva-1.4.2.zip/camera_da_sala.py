"""A câmera da sala inteira (`sala_camera.osl`, a do render final) com as medidas da sala do sala.json, e o enquadramento de
cada superfície por ela, que o visor usa para desenhar a fita igual ao render.

A câmera guarda dois tipos de parâmetro. Os da sala (medidas, olho do público, tamanhos em pixels e a parede que abre a
fita, `primeira`) não são dela: este módulo os escreve a partir do sala.json e da cena ao abrir um arquivo e antes de cada
render, e o render.py do nuvens-blender, antes de desenhar. A `primeira` é a do *Começar por* do visor de cada cena
(`primeira_da_cena`). Os do artista (`horizonte`, `alongamento`, `perto`, `aproximacao`) ficam na câmera e não são tocados.

A câmera de um arquivo feito com um `sala_camera.osl` mais antigo recebe o deste complemento, compilado de novo, ao abrir e
antes de cada render (`atualizar_o_osl`), como o artista faria recarregando o texto; os valores dela ficam.

Na Sala dos artistas, a câmera da sala inteira chega com os dados vinculados; ao soltar a Sala e ao abrir um arquivo, os
dados dela são liberados também (`liberar_os_dados`).

Uma câmera é da sala quando é do tipo personalizado (OSL) e tem os parâmetros `horizonte` e `alongamento`. Câmera vinculada
de outro arquivo não se escreve: ela recebe os valores no arquivo dela.

Sem importar nada do complemento, para scripts de fora (o render.py do nuvens-blender) o carregarem sozinho.
"""
from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path
from typing import TYPE_CHECKING

import bpy
from mathutils import Matrix, Vector

if TYPE_CHECKING:
    from .dados import Sala, Visor

OSL_DA_SALA = Path(__file__).resolve().parent / "sala_camera.osl"
PARAMETROS_DO_ARTISTA = ("horizonte", "alongamento")
GRUPO_DO_VISOR = "visor_da_sala"            # a propriedade da cena com as opções do visor (visor.py)
PRIMEIRA_NO_VISOR = "primeira_da_fita"      # o Começar por, dentro dela
PARAMETROS_DO_ENQUADRAMENTO = ("horizonte", "alongamento", "aproximacao", "perto")


def valores_da_sala(sala: Sala, primeira: str) -> dict[str, float | int]:
    """Os parâmetros da sala, na ordem do OSL: a parede A dá o comprimento, a B a largura, os pixels são os do master, e
    `primeira` vira a posição da parede no sala.json."""
    a, b = sala.paredes[0], sala.paredes[1]
    return {"comprimento": a.largura_m, "largura": b.largura_m, "altura": a.altura_m, "olho": sala.altura_do_olho_m,
            "px_longa": a.largura_px, "px_curta": b.largura_px, "px_altura": a.altura_px, "px_piso": sala.piso.altura_px,
            "primeira": [p.nome for p in sala.paredes].index(sala.paredes_da_fita(primeira)[0].nome)}


def eh_da_sala(dados: bpy.types.Camera) -> bool:
    return dados.type == "CUSTOM" and all(p in dados.cycles_custom for p in PARAMETROS_DO_ARTISTA)


def atualizar_o_osl(dados: bpy.types.Camera) -> bool:
    """Põe na câmera o `sala_camera.osl` deste complemento, se o texto dela for outro ou se ela ainda não foi compilada com
    ele, e a compila de novo, devolvendo os valores que ela tinha (a compilação pode zerá-los). Devolve se compilou."""
    osl_novo = OSL_DA_SALA.read_text(encoding="utf-8")
    texto = dados.custom_shader
    if texto.as_string() == osl_novo and "primeira" in dados.cycles_custom:
        return False
    from cycles import osl
    valores = dict(dados.cycles_custom.items())
    if texto.as_string() != osl_novo:
        texto.from_string(osl_novo)
    erros: list[str] = []
    osl.update_custom_camera_shader(dados, lambda tipo, mensagem: erros.append(f"{tipo} {mensagem}") if "ERROR" in tipo else None)
    if erros:
        raise RuntimeError(f'sala_camera.osl não compilou na câmera "{dados.name}": {erros}')
    for chave, valor in valores.items():
        if chave in dados.cycles_custom:
            dados.cycles_custom[chave] = valor
    return True


def primeira_da_cena(cena: bpy.types.Scene, sala: Sala, visor: Visor) -> str:
    """A parede que abre a fita na cena: a do *Começar por* do visor. Sem o complemento registrado (os scripts de fora, com
    --factory-startup), lida do que a cena guardou; se a cena nunca mexeu nele, a `primeira_parede_da_fita` do dados.json,
    o padrão dele."""
    if GRUPO_DO_VISOR in cena.bl_rna.properties:
        return str(getattr(getattr(cena, GRUPO_DO_VISOR), PRIMEIRA_NO_VISOR))
    guardadas = cena.bl_system_properties_get()
    grupo = None if guardadas is None else guardadas.get(GRUPO_DO_VISOR)
    indice = 0 if grupo is None else int(grupo.get(PRIMEIRA_NO_VISOR, 0))
    return sala.primeira_pelo_indice(visor.primeira_parede_da_fita, indice)


def escrever(dados: bpy.types.Camera, sala: Sala, primeira: str) -> None:
    """Escreve na câmera os parâmetros da sala que estiverem diferentes."""
    for chave, valor in valores_da_sala(sala, primeira).items():
        if chave not in dados.cycles_custom:
            raise KeyError(f'a câmera "{dados.name}" não tem o parâmetro "{chave}" de sala_camera.osl: o OSL dela é de antes')
        if dados.cycles_custom[chave] != valor:
            dados.cycles_custom[chave] = valor


def liberar_os_dados(objetos: Iterable[bpy.types.Object]) -> int:
    """Câmera da sala de uma Sala liberada (Library Override) com os dados ainda vinculados: libera também os dados, como o
    artista faria no Outliner (Library Override > Make no dado da câmera), para o horizonte e o alongamento serem editados e
    animados nela. Devolve quantas."""
    liberadas = 0
    for objeto in objetos:
        if (objeto.type != "CAMERA" or objeto.override_library is None or objeto.data.library is None
                or not eh_da_sala(objeto.data)):
            continue
        objeto.data = objeto.data.override_create(remap_local_usages=True)
        liberadas += 1
    return liberadas


def enquadramentos(sala: Sala, parametros: dict[str, float]) -> dict[str, tuple[Matrix, tuple[float, float, float, float]]]:
    """De cada superfície, a câmera comum que dá a mesma imagem que sala_camera.osl: a matriz dela no espaço da câmera da
    sala inteira (no chão, x para a parede A, z para cima) e o quadro (esquerda, direita, baixo, cima) a 1 m dela.

    No OSL, o raio sai do olho, `olho` metros acima da câmera, para um ponto de um plano (a parede ou o piso do desenho, de
    `altura * 100 / alongamento` de altura, com o olho na fração `horizonte` dela), com o eixo que vai até o plano
    multiplicado pela `aproximacao`. Cada pixel cai num ponto do plano na proporção dele: é uma câmera comum, com o quadro
    deslocado e esticado, e não uma imitação."""
    if sala.topo_do_piso != sala.paredes[0].nome:
        raise ValueError(f"sala_camera.osl põe a borda de cima do piso junto da {sala.paredes[0].nome}; o sala.json diz {sala.topo_do_piso}")
    v = valores_da_sala(sala, sala.paredes[0].nome)   # a primeira parede não muda o enquadramento de cada superfície
    comprimento, largura = float(v["comprimento"]), float(v["largura"])
    altura_desenhada = float(v["altura"]) * 100.0 / parametros["alongamento"]
    olho_desenhado = parametros["horizonte"] * altura_desenhada
    meio = altura_desenhada / 2 - olho_desenhado
    meia_altura = Vector((0.0, 0.0, altura_desenhada / 2))
    ap = parametros["aproximacao"]
    # O centro de cada plano e os vetores do centro à borda direita e à de cima, como o OSL os calcula.
    planos = {
        sala.paredes[0].nome: (Vector((largura / 2 * ap, 0.0, meio)), Vector((0.0, -comprimento / 2, 0.0)), meia_altura),
        sala.paredes[1].nome: (Vector((0.0, -comprimento / 2 * ap, meio)), Vector((-largura / 2, 0.0, 0.0)), meia_altura),
        sala.paredes[2].nome: (Vector((-largura / 2 * ap, 0.0, meio)), Vector((0.0, comprimento / 2, 0.0)), meia_altura),
        sala.paredes[3].nome: (Vector((0.0, comprimento / 2 * ap, meio)), Vector((largura / 2, 0.0, 0.0)), meia_altura),
        sala.piso.nome: (Vector((0.0, 0.0, -olho_desenhado * ap)), Vector((0.0, -comprimento / 2, 0.0)), Vector((largura / 2, 0.0, 0.0))),
    }
    olho = Matrix.Translation((0.0, 0.0, float(v["olho"])))
    resultado: dict[str, tuple[Matrix, tuple[float, float, float, float]]] = {}
    for nome, (centro, direita, cima) in planos.items():
        frente = direita.cross(cima).normalized()   # para trás da câmera, o z dela
        distancia = -centro.dot(frente)
        giro = Matrix((direita.normalized(), cima.normalized(), frente)).transposed().to_4x4()
        x, y = centro.dot(direita.normalized()), centro.dot(cima.normalized())
        resultado[nome] = (olho @ giro, ((x - direita.length) / distancia, (x + direita.length) / distancia,
                                         (y - cima.length) / distancia, (y + cima.length) / distancia))
    return resultado


def projecao(quadro: tuple[float, float, float, float], perto: float, longe: float) -> Matrix:
    """A projeção em perspectiva do quadro a 1 m (esquerda, direita, baixo, cima), como o glFrustum."""
    e, d, b, c = (lado * perto for lado in quadro)
    return Matrix(((2 * perto / (d - e), 0.0, (d + e) / (d - e), 0.0),
                   (0.0, 2 * perto / (c - b), (c + b) / (c - b), 0.0),
                   (0.0, 0.0, -(longe + perto) / (longe - perto), -2 * longe * perto / (longe - perto)),
                   (0.0, 0.0, -1.0, 0.0)))


def parametros(dados: bpy.types.Camera) -> dict[str, float]:
    """Os parâmetros do artista que mudam o enquadramento, já com a animação do quadro se `dados` for o avaliado."""
    return {chave: float(dados.cycles_custom[chave]) for chave in PARAMETROS_DO_ENQUADRAMENTO}


def _cameras_da_sala(objetos: Iterable[bpy.types.Object]) -> list[bpy.types.Camera]:
    """Os dados das câmeras da sala deste arquivo (as vinculadas recebem os valores no arquivo delas), sem repetir."""
    cameras: dict[str, bpy.types.Camera] = {}
    for objeto in objetos:
        if objeto.type == "CAMERA" and objeto.data.library is None and eh_da_sala(objeto.data):
            cameras[objeto.data.name] = objeto.data
    return list(cameras.values())


def escrever_na_cena(cena: bpy.types.Scene, sala: Sala, visor: Visor) -> int:
    """Escreve a sala, com a primeira parede da cena, nas câmeras da sala da cena; devolve quantas."""
    primeira = primeira_da_cena(cena, sala, visor)
    cameras = _cameras_da_sala(cena.objects)
    for dados in cameras:
        atualizar_o_osl(dados)
        escrever(dados, sala, primeira)
    return len(cameras)


def escrever_em_todas(sala: Sala, visor: Visor) -> int:
    """Escreve a sala nas câmeras da sala deste arquivo, cada uma com a primeira parede da cena em que está; a que não está
    em nenhuma cena (a da sala na memória do visor), com a `primeira_parede_da_fita`. Câmera em duas cenas com primeiras
    paredes diferentes não tem um valor certo: é erro. Devolve quantas."""
    de_quem: dict[str, tuple[str, str]] = {}
    for cena in bpy.data.scenes:
        primeira = primeira_da_cena(cena, sala, visor)
        for dados in _cameras_da_sala(cena.objects):
            antes = de_quem.setdefault(dados.name, (cena.name, primeira))
            if antes[1] != primeira:
                raise RuntimeError(f'a câmera "{dados.name}" está nas cenas "{antes[0]}" e "{cena.name}", que começam a fita '
                                   f"por paredes diferentes ({antes[1]} e {primeira}): use uma câmera em cada cena")
    cameras = _cameras_da_sala(bpy.data.objects)
    for dados in cameras:
        atualizar_o_osl(dados)
        escrever(dados, sala, de_quem.get(dados.name, ("", visor.primeira_parede_da_fita))[1])
    return len(cameras)


@bpy.app.handlers.persistent
def _escrever_a_sala(*_: object) -> None:
    from . import dados
    escrever_em_todas(dados.sala(), dados.visor())


@bpy.app.handlers.persistent
def _ao_abrir(*_: object) -> None:
    liberar_os_dados(bpy.data.objects)
    _escrever_a_sala()


HANDLERS = ((bpy.app.handlers.load_post, _ao_abrir), (bpy.app.handlers.render_init, _escrever_a_sala))


def register() -> None:
    for lista, funcao in HANDLERS:
        lista.append(funcao)


def unregister() -> None:
    for lista, funcao in HANDLERS:
        if funcao in lista:
            lista.remove(funcao)
