"""Render da sala: o que sai pelo motor da cena e cria coisas no arquivo do artista. O editor (visor.py, ao_vivo.py) não
cria nada; tudo o que fica no arquivo nasce aqui, só quando o artista pede.

- Renderizar a fita: renderiza cada superfície com o motor e os ajustes de render da cena, numa fração do tamanho
  (`Escala do render`), e junta as imagens na imagem `nome_do_render`, na ordem da fita do visor. Cada superfície sai pela
  câmera comum que dá a mesma imagem da câmera da sala inteira, a do render final (`camera_da_sala.enquadramentos`, a mesma
  do visor), com o Horizonte, o Alongamento, a Aproximação e o Perto dela no quadro atual. Essa câmera é temporária, com o
  nome `nome_do_render`, e sai do arquivo no fim.
- Olhar pela superfície: a câmera de uma parede ou do piso vira a câmera da cena, com a resolução dela.
- Olhar do ponto de vista: a câmera do olho do público (`nome_do_olhar`), presa ao ponto de vista da sala, posta onde o
  olho do visor está naquele momento, vira a câmera da cena. Mexer no olho do visor depois não a move; apertar de novo a
  traz para o olho.

Na barra lateral da 3D View (N), aba "Sala", painel "Render da sala"; Renderizar a fita também no Image Editor.
"""
import math
import os
import tempfile

import bpy
import numpy as np
from mathutils import Matrix

from . import camera_da_sala, marcadores, sala_na_memoria, visor
from .visor import SALA, VISOR

SEM_SALA_NO_ARQUIVO = ("Esta cena não tem a Sala no arquivo: o visor usa uma sala só na memória, e as câmeras dela não servem "
                       "de câmera da cena. Traga a Sala do Asset Browser para olhar por ela.")


def por_camera(cena: bpy.types.Scene, camera: bpy.types.Object, escala: float) -> None:
    superficie = SALA.superficie(camera[VISOR.propriedade_da_superficie])
    cena.camera = camera
    cena.render.resolution_x = max(1, round(superficie.largura_px * escala))
    cena.render.resolution_y = max(1, round(superficie.altura_px * escala))
    cena.render.resolution_percentage = 100
    # O Blender só aceita proporção de pixel a partir de 1: o lado menor fica com 1.
    anamorfose = superficie.anamorfose
    cena.render.pixel_aspect_x, cena.render.pixel_aspect_y = (1.0, anamorfose) if anamorfose >= 1 else (1 / anamorfose, 1.0)


def enquadrar(dados: bpy.types.Camera, quadro: tuple[float, float, float, float], tamanho: tuple[int, int]) -> tuple[float, float]:
    """Põe na câmera comum o quadro a 1 m (esquerda, direita, baixo, cima) e devolve a proporção de pixel (x, y) com que
    `tamanho` pixels cobrem esse quadro inteiro. Com o encaixe horizontal, o Blender mede a lente e os dois deslocamentos
    pela largura do quadro, e a altura sai da resolução vezes a proporção de pixel."""
    esquerda, direita, baixo, cima = quadro
    largura = direita - esquerda
    dados.type = "PERSP"
    dados.sensor_fit = "HORIZONTAL"
    dados.lens = dados.sensor_width / largura
    dados.shift_x = (direita + esquerda) / 2 / largura
    dados.shift_y = (cima + baixo) / 2 / largura
    # O Blender só aceita proporção de pixel a partir de 1: o lado menor fica com 1.
    razao = (cima - baixo) * tamanho[0] / (largura * tamanho[1])
    return (1.0, razao) if razao >= 1 else (1 / razao, 1.0)


def renderizar(cena: bpy.types.Scene, camera: bpy.types.Object, tamanho: tuple[int, int], proporcao: tuple[float, float],
               arquivo: str) -> np.ndarray:
    """A imagem de `camera` em `tamanho` pixels, em linhas de baixo para cima como o Blender guarda, RGBA em float."""
    cena.camera = camera
    cena.render.resolution_x, cena.render.resolution_y = tamanho
    cena.render.resolution_percentage = 100
    cena.render.pixel_aspect_x, cena.render.pixel_aspect_y = proporcao
    cena.render.filepath = arquivo
    bpy.ops.render.render(write_still=True, scene=cena.name)
    imagem = bpy.data.images.load(cena.render.filepath)
    try:
        largura, altura = imagem.size
        pixels = np.empty(largura * altura * 4, np.float32)
        imagem.pixels.foreach_get(pixels)
    finally:
        bpy.data.images.remove(imagem)
    return pixels.reshape(altura, largura, 4)


def renderizar_a_fita(cena: bpy.types.Scene) -> bpy.types.Image:
    """Renderiza cada superfície com o motor da cena, pelo enquadramento do render final, e monta a fita
    (`visor.lugares_na_fita`) na imagem `nome_do_render`. Devolve a cena como estava."""
    sala = visor.sala_do_visor(cena)
    escala = cena.render_da_sala.escala
    largura = round(visor.tamanho_da_fita()[0] * escala)
    altura_da_fita = round(SALA.paredes[0].altura_m * visor.pixels_por_metro() * escala)
    cameras = visor.cameras_da_sala(sala)
    lugares = visor.lugares_na_fita(cena.visor_da_sala.primeira_da_fita)
    altura_do_piso = round(lugares[VISOR.superficie_do_piso][3] * escala)

    avaliada = visor.camera_da_sala_inteira(cena, sala).evaluated_get(bpy.context.evaluated_depsgraph_get())
    lugar, giro, _ = avaliada.matrix_world.decompose()
    na_cena = Matrix.Translation(lugar) @ giro.to_matrix().to_4x4()
    valores = camera_da_sala.parametros(avaliada.data)
    enquadramentos = camera_da_sala.enquadramentos(SALA, valores)

    render = cena.render
    antes = (cena.camera, render.resolution_x, render.resolution_y, render.resolution_percentage,
             render.pixel_aspect_x, render.pixel_aspect_y, render.filepath, render.image_settings.file_format)
    quadro = np.zeros((altura_da_fita + altura_do_piso, largura, 4), np.float32)
    quadro[..., 3] = 1.0
    dados = bpy.data.cameras.new(VISOR.nome_do_render)
    temporaria = bpy.data.objects.new(VISOR.nome_do_render, dados)
    cena.collection.objects.link(temporaria)
    dados.clip_start, dados.clip_end = max(valores["perto"], avaliada.data.clip_start), avaliada.data.clip_end
    try:
        render.image_settings.file_format = "PNG"
        with tempfile.TemporaryDirectory(prefix="visor-da-sala-") as pasta, marcadores.soltos_da_camera(cena.timeline_markers):
            for camera in cameras:
                nome = camera[VISOR.propriedade_da_superficie]
                x, y, w, h = (round(valor * escala) for valor in lugares[nome])
                tamanho = (max(1, w), max(1, h))
                local, quadro_a_1m = enquadramentos[nome]
                temporaria.matrix_world = na_cena @ local
                proporcao = enquadrar(dados, quadro_a_1m, tamanho)
                imagem = renderizar(cena, temporaria, tamanho, proporcao, os.path.join(pasta, f"{nome}.png"))
                if camera["espelhar_no_visor"]:
                    imagem = imagem[:, ::-1]
                altura, largura_da_imagem = imagem.shape[:2]
                fim = min(largura, x + largura_da_imagem)
                quadro[y:y + altura, x:fim] = imagem[:, :fim - x]
    finally:
        (cena.camera, render.resolution_x, render.resolution_y, render.resolution_percentage,
         render.pixel_aspect_x, render.pixel_aspect_y, render.filepath, render.image_settings.file_format) = antes
        bpy.data.objects.remove(temporaria)
        bpy.data.cameras.remove(dados)

    imagem = bpy.data.images.get(VISOR.nome_do_render)
    if imagem is None:
        imagem = bpy.data.images.new(VISOR.nome_do_render, largura, quadro.shape[0], alpha=False)
    elif tuple(imagem.size) != (largura, quadro.shape[0]):
        # Mudar o tamanho da mesma imagem mantém os editores que a mostram.
        imagem.scale(largura, quadro.shape[0])
    imagem.pixels.foreach_set(quadro.ravel())
    imagem.update()
    return imagem


def mostrar(contexto: bpy.types.Context, imagem: bpy.types.Image) -> None:
    """Nos Image Editors da tela, menos a Sala e a Fita ao vivo."""
    for area in contexto.screen.areas:
        if area.type == "IMAGE_EDITOR" and not visor.mostra(area.spaces.active, {VISOR.nome_do_olho, VISOR.nome_da_imagem}):
            area.spaces.active.image = imagem
            area.tag_redraw()


def camera_do_olho(cena: bpy.types.Scene) -> bpy.types.Object:
    """A câmera do olho, criada na primeira vez como objeto do arquivo do artista, na coleção da cena, presa ao ponto de
    vista da sala (que pode ser vinculado), e posta onde o olho do visor está, com o campo de visão dele."""
    sala = visor.sala_do_visor(cena)
    if sala_na_memoria.e_da_memoria(sala):
        raise RuntimeError(SEM_SALA_NO_ARQUIVO)
    ponto = visor.ponto_de_vista(sala)
    camera = next((filho for filho in ponto.children if filho.name.startswith(VISOR.nome_do_olhar)), None)
    if camera is None:
        camera = bpy.data.objects.new(VISOR.nome_do_olhar, bpy.data.cameras.new(VISOR.nome_do_olhar))
        camera.parent = ponto
        cena.collection.objects.link(camera)
        camera.data.sensor_fit = "VERTICAL"
        camera.hide_render = False
    camera.data.clip_start, camera.data.clip_end = VISOR.recorte_do_olho
    camera.matrix_parent_inverse.identity()
    camera.matrix_basis = visor.olho_no_ponto_de_vista(cena)
    camera.data.angle_y = math.radians(cena.visor_da_sala.campo)
    return camera


class RenderDaSala(bpy.types.PropertyGroup):
    escala: bpy.props.FloatProperty(name="Escala do render", description="Fração da resolução da sala em que a fita é renderizada",
                                    default=VISOR.escala, min=0.05, max=1.0)


class SALA_OT_renderizar_fita(bpy.types.Operator):
    bl_idname = "sala.renderizar_fita"
    bl_label = "Renderizar a fita"
    bl_description = ("Renderiza as quatro paredes e o piso com o motor e as amostras da cena, no enquadramento do render "
                      "final, e monta a fita. Com o Cycles, pode levar minutos")

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        try:
            imagem = renderizar_a_fita(contexto.scene)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}
        mostrar(contexto, imagem)
        return {"FINISHED"}


class SALA_OT_olhar_pela_superficie(bpy.types.Operator):
    bl_idname = "sala.olhar_pela_superficie"
    bl_label = "Olhar pela superfície"
    bl_description = "Faz da câmera desta superfície a câmera da cena, com a resolução dela, e olha por ela"

    superficie: bpy.props.StringProperty()

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        try:
            sala = visor.sala_do_visor(contexto.scene)
            if sala_na_memoria.e_da_memoria(sala):
                raise RuntimeError(SEM_SALA_NO_ARQUIVO)
            camera = next((c for c in visor.cameras_da_sala(sala) if c[VISOR.propriedade_da_superficie] == self.superficie), None)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}
        if camera is None:
            self.report({"ERROR"}, f'Sem câmera para "{self.superficie}".')
            return {"CANCELLED"}
        por_camera(contexto.scene, camera, 1.0)
        if contexto.space_data is not None and contexto.space_data.type == "VIEW_3D":
            contexto.space_data.region_3d.view_perspective = "CAMERA"
        return {"FINISHED"}


class SALA_OT_olhar_do_ponto_de_vista(bpy.types.Operator):
    bl_idname = "sala.olhar_do_ponto_de_vista"
    bl_label = "Olhar do ponto de vista"
    bl_description = ("Põe a câmera do olho do público onde o olho do visor está e faz dela a câmera da cena. Cria a câmera "
                      "na primeira vez")

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        cena = contexto.scene
        try:
            camera = camera_do_olho(cena)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}
        cena.camera = camera
        cena.render.pixel_aspect_x = cena.render.pixel_aspect_y = 1.0
        if contexto.space_data is not None and contexto.space_data.type == "VIEW_3D":
            contexto.space_data.region_3d.view_perspective = "CAMERA"
        return {"FINISHED"}


class SALA_PT_render(bpy.types.Panel):
    bl_label = "Render da sala"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Sala"

    def draw(self, contexto: bpy.types.Context) -> None:
        layout = self.layout
        layout.prop(contexto.scene.render_da_sala, "escala")
        layout.operator(SALA_OT_renderizar_fita.bl_idname, icon="RENDER_STILL")
        layout.operator(SALA_OT_olhar_do_ponto_de_vista.bl_idname, icon="CAMERA_DATA")
        try:
            cameras = visor.cameras_da_sala(visor.sala_do_visor(contexto.scene))
        except RuntimeError as erro:
            layout.label(text=str(erro), icon="ERROR")
            return
        coluna = layout.column(align=True)
        coluna.label(text="Olhar pela superfície")
        for camera in cameras:
            nome = camera[VISOR.propriedade_da_superficie]
            coluna.operator(SALA_OT_olhar_pela_superficie.bl_idname, text=nome).superficie = nome


class SALA_PT_render_na_imagem(bpy.types.Panel):
    bl_label = "Render da sala"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Sala"

    def draw(self, contexto: bpy.types.Context) -> None:
        self.layout.prop(contexto.scene.render_da_sala, "escala")
        self.layout.operator(SALA_OT_renderizar_fita.bl_idname, icon="RENDER_STILL")


CLASSES = (RenderDaSala, SALA_OT_renderizar_fita, SALA_OT_olhar_pela_superficie, SALA_OT_olhar_do_ponto_de_vista,
           SALA_PT_render, SALA_PT_render_na_imagem)


def register() -> None:
    for classe in CLASSES:
        bpy.utils.register_class(classe)
    bpy.types.Scene.render_da_sala = bpy.props.PointerProperty(type=RenderDaSala)


def unregister() -> None:
    del bpy.types.Scene.render_da_sala
    for classe in reversed(CLASSES):
        bpy.utils.unregister_class(classe)
