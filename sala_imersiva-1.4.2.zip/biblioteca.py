"""A Sala no Asset Browser de qualquer projeto: enquanto o complemento está ligado, a pasta `biblioteca/` dele é uma biblioteca
de assets nas preferências do Blender, com o nome e o jeito de importar do dados.json (`biblioteca`). Ao desligar o
complemento, a biblioteca sai das preferências.

A pasta de um complemento instalado muda de máquina para máquina: a Sala entra como cópia (APPEND), e um vínculo para ela
quebraria no computador do vizinho. Um projeto que vincula a Sala de uma pasta dividida pela equipe (o Nuvens, pelo Drive)
continua usando a pasta dele.
"""
import bpy

from . import dados

BIBLIOTECA = dados.biblioteca()


def _a_nossa() -> bpy.types.UserAssetLibrary | None:
    pasta = str(BIBLIOTECA.pasta)
    return next((b for b in bpy.context.preferences.filepaths.asset_libraries if b.path == pasta), None)


def register() -> None:
    biblioteca = _a_nossa()
    if biblioteca is None:
        biblioteca = bpy.context.preferences.filepaths.asset_libraries.new(name=BIBLIOTECA.nome, directory=str(BIBLIOTECA.pasta))
    biblioteca.import_method = BIBLIOTECA.importar_como


def unregister() -> None:
    biblioteca = _a_nossa()
    if biblioteca is not None:
        bpy.context.preferences.filepaths.asset_libraries.remove(biblioteca)
