"""A vista de 360° chapada, do olho do público no centro da sala, num Image Editor (a imagem `nome_da_vista_360`): a mesma
conta do `vista_360.py` do nuvens-blender, que faz a vista do site, mas na placa e ao vivo. Para cada direção da imagem
equirretangular, o desenho acha o ponto da parede ou do piso que ela atinge e pega a cor da textura dessa superfície, a
mesma que a Fita mostra (ao_vivo.py); acima das paredes fica `cor_do_teto`, e no chão fora do piso projetado,
`cor_fora_da_sala`. O meio da imagem fica na primeira parede do sala.json e a direita na segunda, como na fita.

Referencial da sala, o mesmo de sala_camera.osl: x aponta para a primeira parede, a segunda fica em -y, z para cima, com a
origem no chão, no meio da sala. Só desenha: não muda a cena nem a imagem.
"""
import math

import blf
import bpy
import gpu
from gpu_extras.batch import batch_for_shader

from . import ao_vivo, visor
from .visor import SALA, VISOR

_desenhos: list[tuple[type, object]] = []
_sombreador: dict[str, gpu.types.GPUShader] = {}

NOMES_DAS_TEXTURAS = ("parede_0", "parede_1", "parede_2", "parede_3", "piso")

FRAGMENTO = """
float virar(float u, float espelho) { return espelho > 0.5 ? 1.0 - u : u; }

void main()
{
  float giro = uv.x * 6.28318530718 - 3.14159265359;
  float elevacao = mix(faixa.x, faixa.y, uv.y);
  vec3 d = vec3(cos(elevacao) * cos(giro), -cos(elevacao) * sin(giro), sin(elevacao));
  float L = medidas.x, C = medidas.y, alt = medidas.z, base = medidas.w;
  float olho = piso_e_olho.x, piso_l = piso_e_olho.y, piso_a = piso_e_olho.z;
  float topo = base + alt;
  float longe = 1.0e30;
  float tx = d.x != 0.0 ? sign(d.x) * L * 0.5 / d.x : longe;
  float ty = d.y != 0.0 ? sign(d.y) * C * 0.5 / d.y : longe;
  float tz = d.z < 0.0 ? -olho / d.z : (d.z > 0.0 ? (topo - olho) / d.z : longe);
  float t = min(min(tx, ty), tz);
  vec3 p = vec3(d.x * t, d.y * t, olho + d.z * t);
  cor = d.z > 0.0 ? teto : fora;
  if (t < tz && p.z >= base && p.z <= topo) {
    float v = (p.z - base) / alt;
    if (tx <= ty) {
      if (d.x > 0.0) {
        cor = texture(parede_0, vec2(virar((C * 0.5 - p.y) / C, espelho.x), v));
      }
      else {
        cor = texture(parede_2, vec2(virar((C * 0.5 + p.y) / C, espelho.z), v));
      }
    }
    else {
      if (d.y < 0.0) {
        cor = texture(parede_1, vec2(virar((L * 0.5 - p.x) / L, espelho.y), v));
      }
      else {
        cor = texture(parede_3, vec2(virar((L * 0.5 + p.x) / L, espelho.w), v));
      }
    }
  }
  else if (d.z < 0.0 && tz <= min(tx, ty) && abs(p.y) <= piso_l * 0.5 && abs(p.x) <= piso_a * 0.5) {
    float u = (piso_l * 0.5 - p.y) / piso_l;
    float v = 1.0 - (piso_a * 0.5 - p.x) / piso_a;
    cor = texture(piso, vec2(virar(u, piso_e_olho.w), v));
  }
  cor.a = 1.0;
}
"""


def _criar_o_sombreador() -> gpu.types.GPUShader:
    interface = gpu.types.GPUStageInterfaceInfo("sala_vista_360")
    interface.smooth("VEC2", "uv")
    info = gpu.types.GPUShaderCreateInfo()
    info.push_constant("VEC4", "medidas")
    info.push_constant("VEC4", "piso_e_olho")
    info.push_constant("VEC4", "espelho")
    info.push_constant("VEC4", "teto")
    info.push_constant("VEC4", "fora")
    info.push_constant("VEC4", "faixa")
    for i, nome in enumerate(NOMES_DAS_TEXTURAS):
        info.sampler(i, "FLOAT_2D", nome)
    info.vertex_in(0, "VEC2", "pos")
    info.vertex_in(1, "VEC2", "coord")
    info.vertex_out(interface)
    info.fragment_out(0, "VEC4", "cor")
    info.vertex_source("void main() { uv = coord; gl_Position = vec4(pos, 0.0, 1.0); }")
    info.fragment_source(FRAGMENTO)
    return gpu.shader.create_from_info(info)


def sombreador() -> gpu.types.GPUShader:
    if "vista" not in _sombreador:
        _sombreador["vista"] = _criar_o_sombreador()
    return _sombreador["vista"]


def _conferir_a_sala() -> None:
    if SALA.topo_do_piso != SALA.paredes[0].nome:
        raise RuntimeError(f'A vista de 360° conta com o piso junto da primeira parede do sala.json ("{SALA.paredes[0].nome}"); '
                           f'o topo do piso está junto da "{SALA.topo_do_piso}".')


def faixa() -> tuple[float, float]:
    """As elevações, em radianos, de baixo e de cima da imagem: do chão bem embaixo do olho até `teto_na_360_graus` acima do
    topo das paredes no ponto mais perto do olho, o mais alto que ele vê; o resto do teto fica de fora."""
    topo = SALA.altura_da_base_m + SALA.paredes[0].altura_m - SALA.altura_do_olho_m
    mais_perto = min(SALA.paredes[0].largura_m, SALA.paredes[1].largura_m) / 2
    return -math.pi / 2, min(math.pi / 2, math.atan2(topo, mais_perto) + math.radians(VISOR.teto_na_360_graus))


def imagem_da_vista() -> bpy.types.Image:
    """A imagem que marca o Image Editor da vista de 360°: preta, com a largura da fita do visor e a altura da faixa vista,
    com os mesmos graus por pixel."""
    escala = bpy.context.scene.visor_da_sala.escala
    largura = max(2, round(visor.tamanho_da_fita()[0] * escala))
    baixo, cima = faixa()
    altura = max(1, round(largura * (cima - baixo) / (2 * math.pi)))
    imagem = bpy.data.images.get(VISOR.nome_da_vista_360)
    if imagem is None:
        imagem = bpy.data.images.new(VISOR.nome_da_vista_360, largura, altura, alpha=False)
    elif tuple(imagem.size) != (largura, altura):
        imagem.scale(largura, altura)
    else:
        return imagem
    imagem.pixels.foreach_set([0.0, 0.0, 0.0, 1.0] * (largura * altura))
    imagem.update()
    return imagem


def _na_regiao(u: float, v: float) -> tuple[float, float]:
    return bpy.context.region.view2d.view_to_region(u, v, clip=False)


def _desenhar_as_letras() -> None:
    """A letra de cada parede no meio dela, acima da borda de cima."""
    _conferir_a_sala()
    largura_x, largura_y = SALA.paredes[1].largura_m, SALA.paredes[0].largura_m
    centros = ((largura_x / 2, 0.0), (0.0, -largura_y / 2), (-largura_x / 2, 0.0), (0.0, largura_y / 2))
    topo = SALA.altura_da_base_m + SALA.paredes[0].altura_m
    baixo, cima = faixa()
    blf.size(0, VISOR.tamanho_das_letras_px)
    blf.color(0, *VISOR.cor_das_letras)
    for parede, (x, y) in zip(SALA.paredes, centros, strict=True):
        letra = parede.nome.split()[-1]
        u = (math.atan2(-y, x) + math.pi) / (2 * math.pi)
        v = (math.atan2(topo - SALA.altura_do_olho_m, math.hypot(x, y)) - baixo) / (cima - baixo)
        for u_ in {u, 1.0 - u} if u in (0.0, 1.0) else {u}:
            px, py = _na_regiao(u_, v)
            blf.position(0, px - blf.dimensions(0, letra)[0] / 2, py + VISOR.letras_acima_do_topo_px, 0)
            blf.draw(0, letra)


def _desenhar() -> None:
    contexto = bpy.context
    if not visor.mostra(contexto.space_data, {VISOR.nome_da_vista_360}):
        return
    try:
        _conferir_a_sala()
        sala = visor.sala_do_visor(visor.cena_do_conteudo(contexto.scene))
        cameras = {c[VISOR.propriedade_da_superficie]: c for c in visor.cameras_da_sala(sala)}
    except RuntimeError as erro:
        print(f"Visor da sala: {erro}")
        return
    nomes = [p.nome for p in SALA.paredes] + [SALA.piso.nome]
    texturas = [ao_vivo.textura(nome) for nome in nomes]
    if any(t is None for t in texturas):
        return
    regiao = contexto.region
    cantos = [_na_regiao(u, v) for u, v in ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))]
    pos = [(2.0 * x / regiao.width - 1.0, 2.0 * y / regiao.height - 1.0) for x, y in cantos]
    s = sombreador()
    lote = batch_for_shader(s, "TRI_FAN", {"pos": pos, "coord": [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]})
    espelhos = [1.0 if cameras[nome]["espelhar_no_visor"] else 0.0 for nome in nomes]
    s.bind()
    s.uniform_float("medidas", (SALA.paredes[1].largura_m, SALA.paredes[0].largura_m, SALA.paredes[0].altura_m,
                                SALA.altura_da_base_m))
    s.uniform_float("piso_e_olho", (SALA.altura_do_olho_m, SALA.piso.largura_m, SALA.piso.altura_m, espelhos[4]))
    s.uniform_float("espelho", tuple(espelhos[:4]))
    s.uniform_float("teto", VISOR.cor_do_teto)
    s.uniform_float("fora", (*VISOR.cor_fora_da_sala, 1.0))
    s.uniform_float("faixa", (*faixa(), 0.0, 0.0))
    for nome, textura in zip(NOMES_DAS_TEXTURAS, texturas, strict=True):
        s.uniform_sampler(nome, textura)
    gpu.state.blend_set("NONE")
    lote.draw(s)
    if contexto.scene.visor_da_sala.letras:
        gpu.state.blend_set("ALPHA")
        _desenhar_as_letras()
        gpu.state.blend_set("NONE")


def register() -> None:
    _desenhos.append((bpy.types.SpaceImageEditor,
                      bpy.types.SpaceImageEditor.draw_handler_add(_desenhar, (), "WINDOW", "POST_PIXEL")))


def unregister() -> None:
    for espaco, desenho in _desenhos:
        espaco.draw_handler_remove(desenho, "WINDOW")
    _desenhos.clear()
    _sombreador.clear()
