"""Contas do desenho pela placa que não precisam do Blender: o campo de visão, o sorteio dos pontos de uma peça, a posição
compacta em 16 bits e a divisão do teto de pontos entre as peças. Sem bpy, para os testes rodarem fora do Blender."""
import numpy as np

MAIOR_COMPACTO = 65535


def planos_do_campo(projecao_vezes_vista: np.ndarray) -> np.ndarray:
    """Os seis planos do campo de visão (esquerda, direita, baixo, cima, perto, longe) no mundo, de (a, b, c, d) apontando
    para dentro: o ponto p está dentro de um plano quando a·p.x + b·p.y + c·p.z + d >= 0. A matriz é a de recorte do OpenGL
    (profundidade de -1 a 1), a mesma que o Blender dá em `perspective_matrix`."""
    m = np.asarray(projecao_vezes_vista, np.float64)
    planos = np.array([m[3] + m[0], m[3] - m[0], m[3] + m[1], m[3] - m[1], m[3] + m[2], m[3] - m[2]])
    comprimento = np.linalg.norm(planos[:, :3], axis=1, keepdims=True)
    return planos / np.maximum(comprimento, 1e-12)


def cantos_da_caixa(minimo: np.ndarray, maximo: np.ndarray, modelo: np.ndarray) -> np.ndarray:
    """Os oito cantos da caixa (coordenadas da malha) no mundo, pela matriz do objeto."""
    lo, hi = np.asarray(minimo, np.float64), np.asarray(maximo, np.float64)
    cantos = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])
    return cantos @ np.asarray(modelo, np.float64)[:3, :3].T + np.asarray(modelo, np.float64)[:3, 3]


def caixa_fora(planos: np.ndarray, cantos: np.ndarray) -> bool:
    """Verdadeiro quando todos os cantos ficam do lado de fora de algum dos planos: a caixa inteira está fora. Pode dizer
    "dentro" de uma caixa que está fora perto de uma quina do campo; nunca diz "fora" de uma que aparece."""
    if len(planos) == 0:
        return False
    distancias = cantos @ planos[:, :3].T + planos[:, 3]
    return bool((distancias < 0).all(axis=0).any())


def escala_da_matriz(modelo: np.ndarray) -> float:
    """O tamanho de uma unidade da malha no mundo: a raiz cúbica do determinante da parte 3×3."""
    return float(abs(np.linalg.det(np.asarray(modelo, np.float64)[:3, :3])) ** (1 / 3))


def sorteio(total: int, maximo: int, semente: int) -> np.ndarray:
    """A ordem em que os pontos de uma peça entram na placa: os índices embaralhados, só os `maximo` primeiros quando a peça
    tem mais. Os primeiros N são uma amostra espalhada da peça, e a ordem é sempre a mesma para o mesmo total e semente."""
    gerador = np.random.default_rng(semente)
    ordem = gerador.permutation(total)
    return ordem[:maximo] if total > maximo else ordem


def compactar(pontos: np.ndarray, minimo: np.ndarray, maximo: np.ndarray) -> np.ndarray:
    """A posição de cada ponto como inteiro de 16 bits dentro da caixa, com um quarto componente zero: o Metal não aceita
    atributo de 3 componentes de 16 bits. Devolve (n, 4) uint16."""
    tamanho = np.maximum(np.asarray(maximo, np.float64) - np.asarray(minimo, np.float64), 1e-9)
    unidade = np.rint((pontos.astype(np.float64) - np.asarray(minimo, np.float64)) / tamanho * MAIOR_COMPACTO)
    saida = np.zeros((len(pontos), 4), np.uint16)
    saida[:, :3] = np.clip(unidade, 0, MAIOR_COMPACTO).astype(np.uint16)
    return saida


def cor_em_bytes(srgb: np.ndarray) -> np.ndarray:
    """A cor de cada ponto (sRGB, 0 a 1, (n, 3) ou (n, 4)) como (n, 4) uint8, com alfa cheio."""
    saida = np.full((len(srgb), 4), 255, np.uint8)
    saida[:, :3] = np.rint(np.clip(srgb[:, :3], 0.0, 1.0) * 255).astype(np.uint8)
    return saida


def quantos_desenhar(totais: list[int], fracoes: list[float], teto: int) -> list[int]:
    """Quantos pontos desenhar de cada peça: o total dela vezes a fração dela, e todas as peças reduzidas na mesma proporção
    quando a soma passa do teto. Cada peça com pontos desenha pelo menos um."""
    pedidos = [max(1, int(total * fracao)) if total > 0 and fracao > 0 else 0 for total, fracao in zip(totais, fracoes, strict=True)]
    soma = sum(pedidos)
    if soma <= teto or soma == 0:
        return pedidos
    escala = teto / soma
    return [max(1, int(p * escala)) if p else 0 for p in pedidos]


def numero_em_cor(numero: int) -> tuple[float, float, float, float]:
    """O número da peça como RGBA de 8 bits (byte menos significativo no vermelho), em 0 a 1."""
    return tuple(((numero >> (8 * i)) & 255) / 255.0 for i in range(4))  # type: ignore[return-value]
