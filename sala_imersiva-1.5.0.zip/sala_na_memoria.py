"""A sala do visor de uma cena que não tem a Sala no arquivo, só a câmera da sala inteira como câmera da cena (como as cenas
que animam a sala inteira pela câmera). O complemento traz a Sala da pasta `biblioteca/` só para a memória, fora de qualquer cena (o
Outliner da cena não a mostra), a põe onde a câmera da sala da cena está quando o visor a pede e a tira antes de salvar: o
arquivo do artista não leva nada dela. Ao abrir, desfazer, refazer e depois de salvar, ela volta, se alguma cena precisa
dela. Serve também às cenas vinculadas de uma montagem, que não aceitam objeto novo. Nomes em `sala_na_memoria`, no dados.json.
"""
import bpy
from bpy.app.handlers import persistent
from mathutils import Matrix

from . import camera_da_sala, dados

NA_MEMORIA = dados.sala_na_memoria()
VISOR = dados.visor()
BIBLIOTECA = dados.biblioteca()


def e_da_memoria(objeto: bpy.types.Object) -> bool:
    return NA_MEMORIA.propriedade in objeto


def _camera(cena: bpy.types.Scene) -> bpy.types.Object | None:
    camera = cena.camera
    if camera is None or camera.type != "CAMERA" or not camera_da_sala.eh_da_sala(camera.data):
        return None
    return camera


def precisa(cena: bpy.types.Scene) -> bool:
    """A cena desenha pela câmera da sala inteira e não tem Sala própria, nem como objeto, nem como instância."""
    from . import visor
    return _camera(cena) is not None and not visor.salas(cena) and not visor.instancias_de_sala(cena)


def _colecao() -> bpy.types.Collection | None:
    return next((c for c in bpy.data.collections if NA_MEMORIA.propriedade in c), None)


def apagar() -> None:
    objetos = [o for o in bpy.data.objects if NA_MEMORIA.propriedade in o]
    dados_soltos = {o.data for o in objetos if o.data is not None and o.data.users == 1}
    bpy.data.batch_remove([*objetos, *(c for c in bpy.data.collections if NA_MEMORIA.propriedade in c), *dados_soltos])


def _trazer() -> None:
    caminho = BIBLIOTECA.pasta / NA_MEMORIA.arquivo
    with bpy.data.libraries.load(str(caminho), link=False) as (de, para):
        if NA_MEMORIA.colecao not in de.collections:
            raise RuntimeError(f'"{caminho}" não tem a coleção "{NA_MEMORIA.colecao}".')
        para.collections = [NA_MEMORIA.colecao]
    (colecao,) = para.collections
    colecao.asset_clear()
    colecao[NA_MEMORIA.propriedade] = True
    for objeto in colecao.all_objects:
        objeto[NA_MEMORIA.propriedade] = True


def garantir() -> None:
    """Traz a sala para a memória se alguma cena precisa dela e ela ainda não está lá (ao abrir, depois de desfazer)."""
    if _colecao() is not None or not any(precisa(c) for c in bpy.data.scenes):
        return
    apagar()
    _trazer()


def _na_raiz(objeto: bpy.types.Object) -> Matrix:
    """Onde o objeto fica em relação ao topo da Sala, pela hierarquia dela."""
    if objeto.parent is None:
        return Matrix.Identity(4)
    return _na_raiz(objeto.parent) @ objeto.matrix_parent_inverse @ objeto.matrix_basis


def _por_no_lugar(objeto: bpy.types.Object, mundo: Matrix) -> None:
    """Fora de qualquer cena, nada calcula o lugar dos objetos: cada um recebe o seu, do topo para baixo."""
    if any(abs(a - b) > 1e-6 for linha_a, linha_b in zip(objeto.matrix_world, mundo, strict=True)
           for a, b in zip(linha_a, linha_b, strict=True)):
        objeto.matrix_world = mundo
    for filho in objeto.children:
        _por_no_lugar(filho, mundo @ filho.matrix_parent_inverse @ filho.matrix_basis)


def sala(cena: bpy.types.Scene) -> bpy.types.Object | None:
    """A sala do visor na memória, com a câmera da sala inteira dela onde está a da cena; nenhuma, se a cena não precisa
    dela ou se ela ainda não foi trazida."""
    colecao = _colecao()
    if colecao is None or not precisa(cena):
        return None
    objetos = list(colecao.all_objects)
    raiz = next(o for o in objetos if o.parent is None)
    da_sala = next(o for o in objetos if VISOR.propriedade_da_sala in o)
    camera = next(o for o in objetos if o.type == "CAMERA" and camera_da_sala.eh_da_sala(o.data))
    _por_no_lugar(raiz, _camera(cena).matrix_world @ _na_raiz(camera).inverted())
    return da_sala


@persistent
def _antes_de_salvar(*_: object) -> None:
    apagar()


def _garantir_depois() -> None:
    garantir()


@persistent
def _de_novo(*_: object) -> None:
    bpy.app.timers.register(_garantir_depois, first_interval=0.0)


GANCHOS = (bpy.app.handlers.load_post, bpy.app.handlers.save_post, bpy.app.handlers.undo_post, bpy.app.handlers.redo_post)


def register() -> None:
    bpy.app.handlers.save_pre.append(_antes_de_salvar)
    for gancho in GANCHOS:
        gancho.append(_de_novo)
    bpy.app.timers.register(_garantir_depois, first_interval=0.0)


def unregister() -> None:
    if _antes_de_salvar in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.remove(_antes_de_salvar)
    for gancho in GANCHOS:
        if _de_novo in gancho:
            gancho.remove(_de_novo)
    if bpy.app.timers.is_registered(_garantir_depois):
        bpy.app.timers.unregister(_garantir_depois)
    apagar()
