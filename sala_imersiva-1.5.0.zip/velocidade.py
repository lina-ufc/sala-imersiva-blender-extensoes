"""Analisador de velocidade e giro da sala no painel da aba Sala.

Mede quanto a sala anda e gira por segundo entre os quadros da linha do tempo e marca os trechos acima dos limites de
`velocidade` no `dados.json` (editáveis na cena).
"""
from __future__ import annotations

import bpy
import gpu
from gpu_extras.batch import batch_for_shader

from . import dados
from . import medicao_da_velocidade as medicao

_trajetos: dict[str, tuple[list[tuple[float, float, float]], list[tuple[float, float, float, float]]]] = {}
_ultimas_amostras: dict[str, tuple[str, float, list[tuple[int, str]], list[medicao.Amostra]]] = {}
_desenho_3d: object | None = None


def _objeto_alvo(cena: bpy.types.Scene) -> tuple[bpy.types.Object, str]:
    visor_props = getattr(cena, "visor_da_sala", None)
    if visor_props is not None and visor_props.sala is not None:
        return visor_props.sala, visor_props.sala.name
    prop_sala = dados.visor().propriedade_da_sala
    encontradas = [o for o in cena.objects if o.get(prop_sala)]
    if encontradas:
        return encontradas[0], encontradas[0].name
    if cena.camera is not None:
        return cena.camera, f"câmera ({cena.camera.name})"
    raise RuntimeError("A cena não tem sala nem câmera ativa para medir.")


def medir_cena(
    cena: bpy.types.Scene,
    limites: dados.LimitesDeVelocidade,
) -> tuple[str, medicao.ResultadoDaVelocidade]:
    """Mede a sala do visor (ou a câmera ativa) quadro a quadro e guarda as amostras para recalcular quando um limite muda."""
    alvo, nome_alvo = _objeto_alvo(cena)
    fps = medicao.fps_da_cena(cena)
    marcas = medicao.marcas_da_cena(cena)
    amostras = medicao.amostrar(cena, alvo, bpy.context.view_layer)
    _ultimas_amostras[cena.name] = (nome_alvo, fps, marcas, amostras)
    return nome_alvo, medicao.analisar_posicoes(amostras, fps, marcas, limites)


def _aplicar_resultado(cena: bpy.types.Scene, nome_alvo: str, resultado: medicao.ResultadoDaVelocidade) -> None:
    props = cena.velocidade_da_sala
    props.medido = True
    props.alvo = nome_alvo
    props.vmax = resultado.vmax
    props.gmax = resultado.gmax
    props.segundos_acima = resultado.segundos_acima
    props.quadros_com_salto = resultado.quadros_com_salto
    props.itens.clear()

    for t in resultado.trechos:
        item = props.itens.add()
        item.tipo = "TRECHO"
        item.inicio, item.fim, item.duracao_s = t.inicio, t.fim, t.duracao_s
        item.marcador, item.vmax, item.gmax = t.marcador, t.vmax, t.gmax
    for c in resultado.cortes:
        item = props.itens.add()
        item.tipo = "CORTE" if c.inicio == c.fim else "VOO"
        item.inicio, item.fim, item.duracao_s = c.inicio, c.fim, c.duracao_s
        item.marcador = c.marcador

    posicoes: list[tuple[float, float, float]] = []
    cores: list[tuple[float, float, float, float]] = []
    for p0, p1, cor in resultado.segmentos:
        posicoes.append(p0)
        posicoes.append(p1)
        cores.append(cor)
        cores.append(cor)
    _trajetos[cena.name] = (posicoes, cores)
    if bpy.context.screen is not None:
        for area in bpy.context.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _recalcular_ao_mudar_limite(self: bpy.types.PropertyGroup, contexto: bpy.types.Context) -> None:
    cena = contexto.scene if contexto is not None else bpy.context.scene
    guardado = _ultimas_amostras.get(cena.name)
    if guardado is None:
        return
    nome_alvo, fps, marcas, amostras = guardado
    limites = dados.LimitesDeVelocidade(
        self.metros_por_segundo,
        self.graus_por_segundo,
        self.folga,
        self.salto_metros,
        self.salto_graus,
        self.trecho_minimo_quadros,
    )
    _aplicar_resultado(cena, nome_alvo, medicao.analisar_posicoes(amostras, fps, marcas, limites))


_LIMITES_PADRAO = dados.limites_de_velocidade()


class TrechoVelocidade(bpy.types.PropertyGroup):
    tipo: bpy.props.StringProperty(name="Tipo")
    inicio: bpy.props.IntProperty(name="Início")
    fim: bpy.props.IntProperty(name="Fim")
    duracao_s: bpy.props.FloatProperty(name="Duração (s)")
    marcador: bpy.props.StringProperty(name="Marcador")
    vmax: bpy.props.FloatProperty(name="Velocidade máx. (m/s)")
    gmax: bpy.props.FloatProperty(name="Giro máx. (°/s)")


class VelocidadeDaSala(bpy.types.PropertyGroup):
    metros_por_segundo: bpy.props.FloatProperty(
        name="Limite (m/s)",
        description="Velocidade máxima permitida em metros por segundo (somando deslocamento horizontal e subida) enquanto o chão está à vista",
        default=_LIMITES_PADRAO.metros_por_segundo,
        min=0.01,
        update=_recalcular_ao_mudar_limite,
    )
    graus_por_segundo: bpy.props.FloatProperty(
        name="Giro (°/s)",
        description="Velocidade máxima de giro horizontal em graus por segundo",
        default=_LIMITES_PADRAO.graus_por_segundo,
        min=0.1,
        update=_recalcular_ao_mudar_limite,
    )
    folga: bpy.props.FloatProperty(
        name="Folga",
        description="Multiplicador de tolerância aplicado sobre os limites de velocidade e giro (ex.: 1,05 dá 5% de folga)",
        default=_LIMITES_PADRAO.folga,
        min=1.0,
        update=_recalcular_ao_mudar_limite,
    )
    trecho_minimo_quadros: bpy.props.IntProperty(
        name="Mín. quadros",
        description="Quantidade mínima de quadros seguidos acima do limite para entrar na lista de trechos (picos menores ficam só em amarelo no trajeto)",
        default=_LIMITES_PADRAO.trecho_minimo_quadros,
        min=1,
        update=_recalcular_ao_mudar_limite,
    )
    salto_metros: bpy.props.FloatProperty(
        name="Salto (m)",
        description="Deslocamento mínimo em metros de um quadro para o outro para ser classificado como corte ou voo rápido",
        default=_LIMITES_PADRAO.salto_metros,
        min=0.1,
        update=_recalcular_ao_mudar_limite,
    )
    salto_graus: bpy.props.FloatProperty(
        name="Salto (°)",
        description="Giro mínimo em graus de um quadro para o outro para ser classificado como corte ou voo rápido",
        default=_LIMITES_PADRAO.salto_graus,
        min=1.0,
        update=_recalcular_ao_mudar_limite,
    )

    medido: bpy.props.BoolProperty(default=False)
    mostrar_trajeto: bpy.props.BoolProperty(
        name="Mostrar trajeto colorido",
        description="Desenha na 3D View o caminho percorrido colorido por velocidade (verde: dentro, amarelo: pico curto, laranja/vermelho: trecho acima, azul: corte)",
        default=True,
    )
    alvo: bpy.props.StringProperty(name="Medido")
    vmax: bpy.props.FloatProperty(name="Velocidade máx. (m/s)")
    gmax: bpy.props.FloatProperty(name="Giro máx. (°/s)")
    segundos_acima: bpy.props.FloatProperty(name="Tempo acima (s)")
    quadros_com_salto: bpy.props.IntProperty(name="Saltos")
    itens: bpy.props.CollectionProperty(type=TrechoVelocidade)


class SALA_OT_medir_velocidade(bpy.types.Operator):
    bl_idname = "sala.medir_velocidade"
    bl_label = "Medir velocidade"
    bl_description = "Mede a velocidade e o giro da sala (ou câmera) quadro a quadro na cena aberta"

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        cena = contexto.scene
        props = cena.velocidade_da_sala
        limites = dados.LimitesDeVelocidade(
            props.metros_por_segundo,
            props.graus_por_segundo,
            props.folga,
            props.salto_metros,
            props.salto_graus,
            props.trecho_minimo_quadros,
        )
        try:
            nome_alvo, resultado = medir_cena(cena, limites)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}

        _aplicar_resultado(cena, nome_alvo, resultado)
        self.report({"INFO"}, f"{nome_alvo}: máx {resultado.vmax:.2f} m/s, {resultado.gmax:.1f}°/s")
        return {"FINISHED"}


class SALA_OT_ir_para_quadro(bpy.types.Operator):
    bl_idname = "sala.ir_para_quadro"
    bl_label = "Ir para quadro"
    bl_description = "Leva a linha do tempo ao início deste trecho"

    quadro: bpy.props.IntProperty(name="Quadro")

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        contexto.scene.frame_set(self.quadro)
        return {"FINISHED"}


class SALA_PT_velocidade(bpy.types.Panel):
    bl_label = "Velocidade da sala"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Sala"

    def draw(self, contexto: bpy.types.Context) -> None:
        layout = self.layout
        props = contexto.scene.velocidade_da_sala
        layout.operator(SALA_OT_medir_velocidade.bl_idname, icon="TIME")

        limites_box = layout.box()
        limites_box.label(text="Limites do movimento")
        col = limites_box.column(align=True)
        row = col.row(align=True)
        row.prop(props, "metros_por_segundo")
        row.prop(props, "graus_por_segundo")
        row = col.row(align=True)
        row.prop(props, "folga")
        row.prop(props, "trecho_minimo_quadros")

        if not props.medido:
            return

        layout.prop(props, "mostrar_trajeto")
        resumo = layout.box()
        resumo.label(text=f"Alvo: {props.alvo}")
        resumo.label(text=f"Máx: {props.vmax:.2f} m/s | Giro: {props.gmax:.1f}°/s")
        resumo.label(text=f"Acima: {props.segundos_acima:.1f} s | Saltos: {props.quadros_com_salto}")

        if not props.itens:
            if props.segundos_acima > 0:
                layout.label(text=f"Nenhum trecho com {props.trecho_minimo_quadros}+ quadros (só picos curtos).", icon="INFO")
            else:
                layout.label(text="Tudo dentro do limite.", icon="CHECKMARK")
            return

        lista_box = layout.box()
        lista_box.label(text="Trechos e cortes (clique para ir):")
        for item in props.itens:
            if item.tipo == "TRECHO":
                texto = f"{item.inicio}–{item.fim} ({item.duracao_s:.1f}s) · {item.marcador} · {item.vmax:.2f}m/s {item.gmax:.0f}°/s"
                icone = "ERROR"
            elif item.tipo == "CORTE":
                texto = f"Corte {item.inicio} · {item.marcador}"
                icone = "SCULPTMODE_HLT"
            else:
                texto = f"Voo {item.inicio}–{item.fim} ({item.duracao_s:.1f}s) · {item.marcador}"
                icone = "CON_FOLLOWPATH"
            lista_box.operator(SALA_OT_ir_para_quadro.bl_idname, text=texto, icon=icone).quadro = item.inicio


def _desenhar_trajeto() -> None:
    cena = bpy.context.scene
    props = getattr(cena, "velocidade_da_sala", None)
    if props is None or not props.medido or not props.mostrar_trajeto:
        return
    dados_trajeto = _trajetos.get(cena.name)
    if not dados_trajeto:
        return
    posicoes, cores = dados_trajeto
    if not posicoes:
        return
    regiao = bpy.context.region
    sombreador = gpu.shader.from_builtin("POLYLINE_SMOOTH_COLOR")
    lote = batch_for_shader(sombreador, "LINES", {"pos": posicoes, "color": cores})
    gpu.state.blend_set("ALPHA")
    sombreador.uniform_float("viewportSize", (regiao.width, regiao.height))
    sombreador.uniform_float("lineWidth", 4.0)
    lote.draw(sombreador)
    gpu.state.blend_set("NONE")


CLASSES = (TrechoVelocidade, VelocidadeDaSala, SALA_OT_medir_velocidade, SALA_OT_ir_para_quadro, SALA_PT_velocidade)


def register() -> None:
    global _desenho_3d
    for classe in CLASSES:
        bpy.utils.register_class(classe)
    bpy.types.Scene.velocidade_da_sala = bpy.props.PointerProperty(type=VelocidadeDaSala)
    _desenho_3d = bpy.types.SpaceView3D.draw_handler_add(_desenhar_trajeto, (), "WINDOW", "POST_VIEW")


def unregister() -> None:
    global _desenho_3d
    if _desenho_3d is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_desenho_3d, "WINDOW")
        _desenho_3d = None
    _trajetos.clear()
    _ultimas_amostras.clear()
    del bpy.types.Scene.velocidade_da_sala
    for classe in reversed(CLASSES):
        bpy.utils.unregister_class(classe)
