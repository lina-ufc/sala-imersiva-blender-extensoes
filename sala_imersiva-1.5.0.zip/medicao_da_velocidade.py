"""A conta da velocidade e do giro da sala quadro a quadro, contra os limites do movimento (`velocidade` no dados.json):
enquanto o chão está à vista, a sala anda até `metros_por_segundo` (somando a subida) e gira até `graus_por_segundo`, com a
`folga`; acima disso, só com corte ou transição. Um passo de mais de `salto_metros` ou `salto_graus` de um quadro para o outro
é corte (um quadro) ou voo rápido (vários seguidos), e não entra na velocidade. Os trechos acima do limite com
`trecho_minimo_quadros` ou mais entram na lista; os picos menores, só no trajeto colorido do painel.

As distâncias contam na medida da sala, e não na do mundo: com a sala reduzida a 1/5, o público é do tamanho dela e sente o
mundo cinco vezes maior, então cada metro andado no mundo vale cinco metros na sala. O passo de cada quadro é dividido pela
escala da sala nos dois quadros (a média), e o limite e o salto valem nessa medida.

O painel *Velocidade da sala* (velocidade.py) e os scripts de fora (o `correcoes/velocidade_da_sala.py` do nuvens-blender)
usam esta mesma conta. Sem importar nada do complemento, para os scripts de fora o carregarem sozinho.
"""
from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING

import bpy

if TYPE_CHECKING:
    from .dados import LimitesDeVelocidade

Ponto = tuple[float, float, float]
Amostra = tuple[int, Ponto, float, float]    # quadro, posição no mundo, giro em Z (graus), escala da sala no mundo
Cor = tuple[float, float, float, float]


@dataclass(frozen=True)
class TrechoDeVelocidade:
    inicio: int
    fim: int
    duracao_s: float
    marcador: str
    vmax: float
    gmax: float


@dataclass(frozen=True)
class CorteDeVelocidade:
    inicio: int
    fim: int
    duracao_s: float
    marcador: str


@dataclass(frozen=True)
class ResultadoDaVelocidade:
    vmax: float
    gmax: float
    segundos_acima: float
    quadros_com_salto: int
    trechos: tuple[TrechoDeVelocidade, ...]
    cortes: tuple[CorteDeVelocidade, ...]
    segmentos: tuple[tuple[Ponto, Ponto, Cor], ...] = ()


def _marcador_em(quadro: int, marcas: Sequence[tuple[int, str]]) -> str:
    nome = "-"
    for q, n in marcas:
        if q <= quadro:
            nome = n
    return nome


def analisar_posicoes(
    amostras: Sequence[Amostra],
    fps: float,
    marcas: Sequence[tuple[int, str]],
    limites: LimitesDeVelocidade,
) -> ResultadoDaVelocidade:
    """Analisa uma sequência de (quadro, (x, y, z), giro_z_graus, escala) contra os limites do movimento."""
    if fps <= 0:
        raise ValueError(f"FPS precisa ser positivo; veio {fps}")

    marcas_ordenadas = sorted(marcas)   # pelo quadro e, no mesmo quadro, pelo nome
    anterior: tuple[Ponto, float, float] | None = None
    acima: list[tuple[int, str, float, float]] = []
    saltos_quadros: list[tuple[int, str]] = []
    passos: list[tuple[int, Ponto, Ponto, bool, float, float]] = []
    vmax = 0.0
    gmax = 0.0
    lim_v = limites.metros_por_segundo * limites.folga
    lim_g = limites.graus_por_segundo * limites.folga

    for quadro, pos, giro, escala in amostras:
        if escala <= 0:
            raise ValueError(f"a escala da sala precisa ser positiva; no quadro {quadro} veio {escala}")
        if anterior is not None:
            passo_m = math.dist(pos, anterior[0]) / ((escala + anterior[2]) / 2)
            passo_graus = abs((giro - anterior[1] + 180.0) % 360.0 - 180.0)
            mk = _marcador_em(quadro, marcas_ordenadas)
            if passo_m > limites.salto_metros or passo_graus > limites.salto_graus:
                saltos_quadros.append((quadro, mk))
                passos.append((quadro, anterior[0], pos, True, 0.0, 0.0))
            else:
                v = passo_m * fps
                g = passo_graus * fps
                vmax = max(vmax, v)
                gmax = max(gmax, g)
                if v > lim_v or g > lim_g:
                    acima.append((quadro, mk, v, g))
                passos.append((quadro, anterior[0], pos, False, v, g))
        anterior = (pos, giro, escala)

    grupos: list[list] = []   # [primeiro, último, marcador, m/s máx, °/s máx]
    for f, mk, v, g in acima:
        if grupos and f - grupos[-1][1] <= 2:
            grupos[-1][1] = f
            grupos[-1][3] = max(grupos[-1][3], v)
            grupos[-1][4] = max(grupos[-1][4], g)
            continue
        grupos.append([f, f, mk, v, g])

    trechos = tuple(
        TrechoDeVelocidade(a, b, (b - a + 1) / fps, mk, v, g)
        for a, b, mk, v, g in grupos
        if b - a >= limites.trecho_minimo_quadros
    )

    quadros_em_trecho = {q for t in trechos for q in range(t.inicio, t.fim + 1)}
    segmentos: list[tuple[Ponto, Ponto, Cor]] = []
    for quadro, p0, p1, eh_salto, v, g in passos:
        if eh_salto:
            cor = (0.75, 0.9, 1.0, 0.35)
        elif quadro in quadros_em_trecho:
            excesso = min(1.0, max(v / lim_v, g / lim_g) - 1.0)
            cor = (1.0, max(0.1, 0.55 - 0.45 * excesso), 0.1, 1.0)
        elif v > lim_v or g > lim_g:
            # Pico curto (< trecho_minimo_quadros): amarelo para distinguir dos trechos da lista
            cor = (1.0, 0.85, 0.15, 0.95)
        else:
            cor = (0.15, 0.9, 0.35, 1.0)
        segmentos.append((p0, p1, cor))

    saltos: list[list] = []   # saltos seguidos são um voo rápido, não um corte
    for f, mk in saltos_quadros:
        if saltos and f - saltos[-1][1] <= 1:
            saltos[-1][1] = f
            continue
        saltos.append([f, f, mk])

    cortes = tuple(CorteDeVelocidade(a, b, (b - a + 1) / fps, mk) for a, b, mk in saltos)
    return ResultadoDaVelocidade(vmax, gmax, len(acima) / fps, len(saltos_quadros), trechos, cortes, tuple(segmentos))


def relatorio(titulo: str, resultado: ResultadoDaVelocidade, limites: LimitesDeVelocidade) -> list[str]:
    """O resultado em linhas de texto, para a linha de comando: o máximo, depois os trechos acima e os cortes e voos rápidos."""
    linhas = [(f"{titulo}: vmax {resultado.vmax:.2f} m/s, giro máx {resultado.gmax:.1f}°/s, {resultado.segundos_acima:.1f} s "
               f"acima do limite, quadros com salto {resultado.quadros_com_salto}")]
    for t in resultado.trechos:
        linhas.append(f"  {t.inicio}-{t.fim} ({t.duracao_s:.1f} s) em {t.marcador}: até {t.vmax:.2f} m/s, {t.gmax:.1f}°/s")
    for c in resultado.cortes:
        if c.inicio == c.fim:
            linhas.append(f"  corte no {c.inicio} ({c.marcador})")
            continue
        linhas.append(f"  {c.inicio}-{c.fim} ({c.duracao_s:.1f} s) em {c.marcador}: mais de {limites.salto_metros:.0f} m ou "
                      f"{limites.salto_graus:.0f}° por quadro (voo rápido)")
    return linhas


def quem_move(alvo: bpy.types.Object) -> set[bpy.types.Object]:
    """O alvo e tudo de que a posição dele depende: os pais e os alvos das restrições, deles também."""
    precisa: set[bpy.types.Object] = set()
    fila: list[bpy.types.Object] = [alvo]
    while fila:
        atual = fila.pop()
        if atual in precisa:
            continue
        precisa.add(atual)
        if atual.parent is not None:
            fila.append(atual.parent)
        for restricao in atual.constraints:
            alvo_da_restricao = getattr(restricao, "target", None)
            if alvo_da_restricao is not None:
                fila.append(alvo_da_restricao)
    return precisa


def _estado_das_camadas(camada: bpy.types.LayerCollection) -> dict[bpy.types.LayerCollection, bool]:
    estado: dict[bpy.types.LayerCollection, bool] = {}
    for filha in camada.children:
        estado[filha] = filha.exclude
        estado.update(_estado_das_camadas(filha))
    return estado


def _so_o_que_move(camada: bpy.types.LayerCollection, precisa: set[bpy.types.Object]) -> None:
    """Exclui da avaliação as coleções sem o alvo nem quem o move: cada quadro avalia só o que fica, e as peças pesadas (milhões
    de pontos) deixam de ser calculadas a cada quadro."""
    for filha in camada.children:
        if not set(filha.collection.all_objects) & precisa:
            filha.exclude = True
            continue
        _so_o_que_move(filha, precisa)


def fps_da_cena(cena: bpy.types.Scene) -> float:
    return cena.render.fps / cena.render.fps_base


def marcas_da_cena(cena: bpy.types.Scene) -> list[tuple[int, str]]:
    return [(m.frame, m.name) for m in cena.timeline_markers]


def amostrar(cena: bpy.types.Scene, alvo: bpy.types.Object, camada_de_vista: bpy.types.ViewLayer) -> list[Amostra]:
    """A posição, o giro em Z e a escala (a média dos três eixos) do `alvo` no mundo em cada quadro da cena, com só ele e quem o
    move na avaliação. A cena volta como estava: as coleções excluídas e o quadro."""
    quadro_original = cena.frame_current
    raiz = camada_de_vista.layer_collection
    estado_original = _estado_das_camadas(raiz)
    amostras: list[Amostra] = []
    try:
        _so_o_que_move(raiz, quem_move(alvo))
        for f in range(cena.frame_start, cena.frame_end + 1):
            cena.frame_set(f)
            p = alvo.matrix_world.translation
            giro = math.degrees(alvo.matrix_world.to_euler().z)
            escala = sum(alvo.matrix_world.to_scale()) / 3
            amostras.append((f, (float(p.x), float(p.y), float(p.z)), float(giro), float(escala)))
    finally:
        for camada, excluida in estado_original.items():
            camada.exclude = excluida
        cena.frame_set(quadro_original)
    return amostras


def medir_cena(
    cena: bpy.types.Scene,
    alvo: bpy.types.Object,
    camada_de_vista: bpy.types.ViewLayer,
    limites: LimitesDeVelocidade,
) -> ResultadoDaVelocidade:
    """Mede o `alvo` (a sala ou a câmera) em cada quadro da cena contra os `limites`."""
    return analisar_posicoes(amostrar(cena, alvo, camada_de_vista), fps_da_cena(cena), marcas_da_cena(cena), limites)
