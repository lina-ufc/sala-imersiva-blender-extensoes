"""Complemento do Blender da sala imersiva do ITA: a Sala pronta para soltar, o visor das cinco telas e o render da fita.
Cada parte é um módulo com register e unregister:

- biblioteca: a pasta `biblioteca/`, com a Sala, como biblioteca de assets nas preferências enquanto o complemento está ligado.
- ao_soltar: a coleção marcada (a Sala, as peças de nuvem do Nuvens) chega liberada com Library Override quando é solta do
  Asset Browser.
- camera_da_sala: as medidas do sala.json na câmera da sala inteira (sala_camera.osl), ao abrir e antes de cada render.
- visor: o editor do visor da sala: a janela com a sala simulada, vista do olho do público, e a fita das cinco telas.
- ao_vivo: as cinco telas do visor desenhadas como a 3D View, com o enquadramento da câmera da sala inteira.
- vista_360: a vista de 360° chapada, do olho do público no centro da sala, a partir das cinco telas do visor.
- renderizar: o que sai pelo motor da cena e cria coisas no arquivo: Renderizar a fita e as câmeras da cena.
- marcas: as arestas da sala, a letra de cada parede e o teto, desenhados por cima da vista do olho do visor.
"""
from . import (
    ao_soltar,
    ao_vivo,
    biblioteca,
    camera_da_sala,
    marcas,
    renderizar,
    visor,
    vista_360,
)

PARTES = (biblioteca, ao_soltar, camera_da_sala, visor, ao_vivo, vista_360, renderizar, marcas)


def register() -> None:
    for parte in PARTES:
        parte.register()


def unregister() -> None:
    for parte in reversed(PARTES):
        parte.unregister()
