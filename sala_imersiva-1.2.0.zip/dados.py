"""Lê dados.json e sala.json, ao lado deste arquivo. Não depende do Blender, para os scripts que usam a sala (o nuvens-blender,
por exemplo) lerem os mesmos arquivos."""
import json
from dataclasses import dataclass
from pathlib import Path

ARQUIVO = Path(__file__).resolve().parent / "dados.json"
ARQUIVO_DA_SALA = Path(__file__).resolve().parent / "sala.json"


@dataclass(frozen=True)
class AoSoltar:
    propriedade: str
    propriedade_do_lugar: str


@dataclass(frozen=True)
class Visor:
    propriedade_da_sala: str
    propriedade_da_superficie: str
    superficie_do_piso: str
    ponto_de_vista: str
    nome_do_olhar: str
    nome_da_imagem: str
    nome_do_olho: str
    nome_do_render: str
    escala: float
    campo_padrao: float
    campo_minimo: float
    campo_maximo: float
    inclinacao_maxima: float
    inclinacao_do_piso: float
    atraso_s: float
    redesenhar_no_play: bool
    passadas_do_visor: int
    shading_de_partida: str
    recorte_do_olho: tuple[float, float]
    graus_por_pixel: float
    graus_por_passo_da_roda: float
    fracao_da_divisao: float
    intervalo_da_janela_s: float
    prefixo_da_superficie: str
    cor_das_arestas: tuple[float, float, float, float]
    espessura_das_arestas_px: float
    cor_das_letras: tuple[float, float, float, float]
    tamanho_das_letras_px: int
    letras_acima_do_topo_px: float
    cor_do_teto: tuple[float, float, float, float]
    cor_das_divisorias: tuple[float, float, float, float]
    espessura_das_divisorias_px: float
    primeira_parede_da_fita: str
    fracao_da_area_na_fita: float
    cor_da_porta: tuple[float, float, float, float]
    espessura_da_porta_px: float
    passo_do_olho_m: float
    inverter_arrasto: bool
    margem_das_paredes_m: float
    cor_fora_da_sala: tuple[float, float, float]
    rotulo_no_cabecalho: str
    rotulo_da_fita_no_cabecalho: str
    nome_da_fonte: str
    nome_da_vista_360: str
    rotulo_da_360_no_cabecalho: str
    teto_na_360_graus: float


@dataclass(frozen=True)
class Biblioteca:
    nome: str
    pasta: Path
    importar_como: str


@dataclass(frozen=True)
class SalaNaMemoria:
    propriedade: str
    arquivo: str
    colecao: str


@dataclass(frozen=True)
class Superficie:
    nome: str
    x_px: int          # o canto de cima à esquerda do pedaço do master que é dela, com y a partir de cima
    y_px: int
    largura_px: int
    altura_px: int
    largura_m: float
    altura_m: float

    @property
    def anamorfose(self) -> float:
        """Quanto o pixel é mais alto que largo, na superfície: pixels por metro na largura sobre pixels por metro na altura."""
        return (self.largura_px / self.largura_m) / (self.altura_px / self.altura_m)


@dataclass(frozen=True)
class Porta:
    parede: str
    largura_m: float
    altura_m: float
    deslocamento_do_centro_m: float
    altura_da_barra_m: float
    comprimento_da_barra_m: float
    largura_do_encosto_m: float


@dataclass(frozen=True)
class Sala:
    composicao: tuple[int, int]      # o tamanho do master, em pixels
    pixels_por_metro: float
    paredes: tuple[Superficie, ...]
    piso: Superficie
    topo_do_piso: str
    altura_da_base_m: float
    altura_do_olho_m: float
    porta: Porta

    def porta_na_parede(self) -> tuple[float, float, float, float, float, float, float, float]:
        """A porta em fração da imagem da parede dela: esquerda, direita, topo, altura da barra, as duas pontas da barra e
        as duas bordas do encosto entre as folhas, no meio (x da esquerda para a direita de quem está dentro, y de baixo
        para cima)."""
        parede = self.superficie(self.porta.parede)
        meio = parede.largura_m / 2 + self.porta.deslocamento_do_centro_m
        esquerda = meio - self.porta.largura_m / 2
        barra = meio - self.porta.comprimento_da_barra_m / 2
        return (esquerda / parede.largura_m, (esquerda + self.porta.largura_m) / parede.largura_m,
                (self.porta.altura_m - self.altura_da_base_m) / parede.altura_m,
                (self.porta.altura_da_barra_m - self.altura_da_base_m) / parede.altura_m,
                barra / parede.largura_m, (barra + self.porta.comprimento_da_barra_m) / parede.largura_m,
                (meio - self.porta.largura_do_encosto_m / 2) / parede.largura_m,
                (meio + self.porta.largura_do_encosto_m / 2) / parede.largura_m)

    def superficie(self, nome: str) -> Superficie:
        for s in (*self.paredes, self.piso):
            if s.nome == nome:
                return s
        raise KeyError(f'sala.json não tem a superfície "{nome}"; tem {[s.nome for s in (*self.paredes, self.piso)]}')


def _tabela(arquivo: Path) -> dict[str, dict[str, object]]:
    return json.loads(arquivo.read_text(encoding="utf-8"))


def _rgba(valor: object) -> tuple[float, float, float, float]:
    cor = tuple(float(c) for c in valor)
    if len(cor) != 4:
        raise ValueError(f"cor precisa de RGBA (quatro números de 0 a 1); veio {valor}")
    return cor


def _rgb(valor: object) -> tuple[float, float, float]:
    cor = tuple(float(c) for c in valor)
    if len(cor) != 3:
        raise ValueError(f"cor precisa de RGB (três números de 0 a 1); veio {valor}")
    return cor


def ao_soltar(arquivo: Path = ARQUIVO) -> AoSoltar:
    a = _tabela(arquivo)["ao_soltar"]
    return AoSoltar(str(a["propriedade"]), str(a["propriedade_do_lugar"]))


def biblioteca(arquivo: Path = ARQUIVO) -> Biblioteca:
    b = _tabela(arquivo)["biblioteca"]
    return Biblioteca(str(b["nome"]), arquivo.parent / str(b["pasta"]), str(b["importar_como"]))


def _recorte(valores: list) -> tuple[float, float]:
    perto, longe = (float(v) for v in valores)
    if not 0 < perto < longe:
        raise ValueError(f"visor.recorte_do_olho_m precisa de (perto, longe), com 0 < perto < longe; veio {valores}")
    return perto, longe


def sala_na_memoria(arquivo: Path = ARQUIVO) -> SalaNaMemoria:
    s = _tabela(arquivo)["sala_na_memoria"]
    return SalaNaMemoria(str(s["propriedade"]), str(s["arquivo"]), str(s["colecao"]))


def visor(arquivo: Path = ARQUIVO) -> Visor:
    v = _tabela(arquivo)["visor"]
    campo = [float(c) for c in v["campo_graus"]]
    if len(campo) != 3 or not campo[1] <= campo[0] <= campo[2]:
        raise ValueError(f"visor.campo_graus precisa de (padrão, mínimo, máximo), com o padrão entre os dois; veio {campo}")
    return Visor(str(v["propriedade_da_sala"]), str(v["propriedade_da_superficie"]), str(v["superficie_do_piso"]),
                 str(v["ponto_de_vista"]), str(v["nome_do_olhar"]), str(v["nome_da_imagem"]), str(v["nome_do_olho"]),
                 str(v["nome_do_render"]),
                 float(v["escala"]),
                 campo[0], campo[1], campo[2], float(v["inclinacao_maxima_graus"]), float(v["inclinacao_do_piso_graus"]),
                 float(v["atraso_s"]), bool(v["redesenhar_no_play"]), int(v["passadas_do_visor"]), str(v["shading_de_partida"]), _recorte(v["recorte_do_olho_m"]), float(v["graus_por_pixel"]),
                 float(v["graus_por_passo_da_roda"]), float(v["fracao_da_divisao"]), float(v["intervalo_da_janela_s"]),
                 str(v["prefixo_da_superficie"]), _rgba(v["cor_das_arestas"]), float(v["espessura_das_arestas_px"]),
                 _rgba(v["cor_das_letras"]), int(v["tamanho_das_letras_px"]), float(v["letras_acima_do_topo_px"]),
                 _rgba(v["cor_do_teto"]), _rgba(v["cor_das_divisorias"]), float(v["espessura_das_divisorias_px"]),
                 str(v["primeira_parede_da_fita"]), float(v["fracao_da_area_na_fita"]),
 _rgba(v["cor_da_porta"]),
                 float(v["espessura_da_porta_px"]), float(v["passo_do_olho_m"]), bool(v["inverter_arrasto"]),
                 float(v["margem_das_paredes_m"]), _rgb(v["cor_fora_da_sala"]), str(v["rotulo_no_cabecalho"]),
                 str(v["rotulo_da_fita_no_cabecalho"]), str(v["nome_da_fonte"]), str(v["nome_da_vista_360"]),
                 str(v["rotulo_da_360_no_cabecalho"]), float(v["teto_na_360_graus"]))


def sala(arquivo: Path = ARQUIVO_DA_SALA) -> Sala:
    """As medidas da sala e o lugar de cada superfície no master, que sai da conta: a medida em metros vezes a densidade."""
    t = json.loads(arquivo.read_text(encoding="utf-8"))
    densidade = float(t["pixels_por_metro"])
    altura_m = float(t["altura_da_projecao_m"])
    p = t["piso"]
    medidas = [(str(w["superficie"]), float(w["largura_m"]), altura_m) for w in t["paredes"]]
    medidas.append((str(p["superficie"]), float(p["largura_m"]), float(p["altura_m"])))
    if densidade <= 0 or any(min(largura, altura) <= 0 for _, largura, altura in medidas):
        raise ValueError(f"sala.json: a densidade e as medidas precisam ser positivas; veio {densidade} px/m e {medidas}")
    if len({nome for nome, _, _ in medidas}) != len(medidas):
        raise ValueError(f"sala.json: superfícies com nome repetido: {[nome for nome, _, _ in medidas]}")
    topo = str(p["topo_junto_a"])
    if topo not in {nome for nome, _, _ in medidas[:-1]}:
        raise ValueError(f'sala.json: piso.topo_junto_a é "{topo}", que não é uma das paredes {[n for n, _, _ in medidas[:-1]]}')
    paredes: list[Superficie] = []
    x = 0
    for nome, largura, altura in medidas[:-1]:
        paredes.append(Superficie(nome, x, 0, round(largura * densidade), round(altura * densidade), largura, altura))
        x += paredes[-1].largura_px
    altura_das_paredes = paredes[0].altura_px
    sob = next(w for w in paredes if w.nome == topo)
    nome, largura, altura = medidas[-1]
    largura_px, altura_px = round(largura * densidade), round(altura * densidade)
    x_do_piso = min(max(0, sob.x_px + (sob.largura_px - largura_px) // 2), max(0, x - largura_px))
    piso = Superficie(nome, x_do_piso, altura_das_paredes, largura_px, altura_px, largura, altura)
    d = t["porta"]
    porta = Porta(str(d["parede"]), float(d["largura_m"]), float(d["altura_m"]), float(d["deslocamento_do_centro_m"]),
                  float(d["altura_da_barra_m"]), float(d["comprimento_da_barra_m"]),
                  float(d["largura_do_encosto_m"]))
    resultado = Sala((max(x, largura_px), altura_das_paredes + altura_px), densidade, tuple(paredes), piso, topo,
                     float(t["altura_da_base_m"]), float(t["altura_do_olho_m"]), porta)
    if porta.parede not in {w.nome for w in paredes}:
        raise ValueError(f'sala.json: porta.parede é "{porta.parede}", que não é uma das paredes {[w.nome for w in paredes]}')
    esquerda, direita, topo_da_porta, barra, barra_0, barra_1, encosto_0, encosto_1 = resultado.porta_na_parede()
    if not (0 <= esquerda < encosto_0 <= encosto_1 < direita <= 1 and 0 < barra < topo_da_porta <= 1
            and esquerda <= barra_0 < barra_1 <= direita + 1e-9):
        raise ValueError(f"sala.json: a porta precisa caber na parede e na altura da projeção, e a barra e o encosto, dentro da porta; "
                         f"veio {porta}")
    return resultado
