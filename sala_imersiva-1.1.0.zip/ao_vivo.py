"""Visor ao vivo: as cinco superfícies da sala desenhadas como a 3D View se desenha, e não renderizadas.

Cada superfície é desenhada numa textura fora da tela (`GPUOffScreen.draw_view3d`) pela câmera comum que dá a mesma imagem
da câmera da sala inteira, a do render final (`camera_da_sala.enquadramentos`): o Horizonte, o Alongamento, a Aproximação e o
Perto dela, animados ou não, valem no visor. Outro complemento pode desenhar por cima de cada superfície
(`desenhar_por_cima`), como o Nuvens do LInA faz com as peças que o Modo leve desenha pela placa. A Sala (a sala simulada,
marcas.py) e a Fita, cada uma num Image Editor, mostram essas texturas. Mexer na cena,
mudar o quadro ou o shading refaz as texturas depois de `atraso_s` parado; durante a reprodução, a cada quadro, se
`redesenhar_no_play` estiver ligado, e senão só quando ela para. O
desenho fora da tela só roda no desenho de uma 3D View: alguma janela precisa ter uma à vista, como a principal.

O desenho usa a 3D View de uma tela do Blender que nenhuma janela mostra (`nome_da_fonte`, criada na primeira vez, como o
Camera Viewer faz), sem as sobreposições (grade, câmeras, luzes). O shading do visor é o dela, e muda pelos ícones de
shading no cabeçalho da Sala e da Fita. O Rendered só serve quando o motor da cena desenha fora da tela (Eevee, Workbench);
com o Cycles, sairia preto, e o visor volta ao `shading_de_partida`. Para ver a fita com o render da cena, o painel tem
Renderizar a fita (renderizar.py).

No Material Preview e no Rendered do Eevee, o visor desenha com `passadas_do_visor` passadas, e não com as da cena: fora da
tela, o Eevee faz todas de uma vez para cada superfície (com 16, segundos por parede), enquanto a janela faz uma por quadro.
As da cena voltam logo depois do desenho.

O desenho fora da tela é copiado para uma textura simples e liberado em seguida. Guardado até o Blender fechar, ele seria
liberado pelo Python depois de o Blender já ter liberado o arquivo, e o Blender caía ao sair.
"""
from collections.abc import Callable

import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Matrix

from . import camera_da_sala, visor
from .visor import SALA, VISOR

DesenhoPorCima = Callable[[Matrix, Matrix, int, int], None]
_por_cima: list[DesenhoPorCima] = []

# Motores que desenham em Rendered fora da tela; com os outros, o visor não fica no Rendered.
MOTORES_DA_VISTA = {"BLENDER_EEVEE", "BLENDER_EEVEE_NEXT", "BLENDER_WORKBENCH"}
# Shadings que o Eevee desenha. Fora da tela, ele faz todas as passadas de uma vez, e não uma por quadro como na janela.
SHADINGS_DO_EEVEE = {"MATERIAL", "RENDERED"}

_texturas: dict[str, gpu.types.GPUTexture] = {}
_estado: dict = {"sujo": False, "assinatura": None, "passadas_da_cena": None, "cena_das_passadas": None, "ignorar_a_troca": False}
_desenhos: list[tuple[type, object]] = []


def aberto() -> bool:
    """Se há alguma Sala ou Fita à vista."""
    return visor.visores_abertos()


def _area_da_fonte() -> bpy.types.Area | None:
    """A 3D View que desenha as texturas, na tela `nome_da_fonte`, que nenhuma janela mostra; nada antes de `fonte`."""
    tela = bpy.data.screens.get(VISOR.nome_da_fonte)
    areas = [] if tela is None else [a for a in tela.areas if a.spaces.active.type == "VIEW_3D"]
    return max(areas, key=lambda a: a.width * a.height) if areas else None


def criar_a_fonte(contexto: bpy.types.Context) -> None:
    """Na primeira vez, a tela da fonte, cópia da tela da janela de onde o visor é aberto, que tem a 3D View de onde ele foi
    aberto. Roda no operador que abre a Sala ou a Fita, antes delas."""
    if bpy.data.screens.get(VISOR.nome_da_fonte) is not None:
        return
    janela = contexto.window
    original = janela.screen
    antes = set(bpy.data.screens)
    bpy.ops.screen.new()
    tela = next(s for s in bpy.data.screens if s not in antes)
    tela.name = VISOR.nome_da_fonte
    janela.screen = original
    if _area_da_fonte() is None:
        raise RuntimeError(f'A tela "{original.name}" não tem 3D View: o visor se abre por uma.')


def fonte() -> bpy.types.Area | None:
    """A 3D View da fonte, pronta para desenhar. Não roda dentro de um desenho, que não aceita mudanças."""
    area = _area_da_fonte()
    if area is None:
        return None
    espaco = area.spaces.active
    if espaco.overlay.show_overlays:
        espaco.overlay.show_overlays = False
    if espaco.show_gizmo:
        espaco.show_gizmo = False
    mostrar_a_cena(area, True)
    return area


def mostrar_a_cena(area: bpy.types.Area, mostrar: bool) -> None:
    espaco = area.spaces.active
    for propriedade in espaco.bl_rna.properties:
        if propriedade.identifier.startswith("show_object_viewport_") and getattr(espaco, propriedade.identifier) != mostrar:
            setattr(espaco, propriedade.identifier, mostrar)


def _trocar_as_passadas(cena: bpy.types.Scene, passadas: int) -> None:
    """A troca refaz o grafo da cena inteira; a atualização que ela produz não pede outro desenho."""
    if cena.eevee.taa_samples == passadas:
        return
    cena.eevee.taa_samples = passadas
    _estado["ignorar_a_troca"] = True


def _baixar_as_passadas(cena: bpy.types.Scene, tipo: str) -> None:
    """A cena vinculada de outro arquivo (a de uma faixa da montagem) não se muda: o visor desenha com as passadas dela."""
    if tipo not in SHADINGS_DO_EEVEE or cena.library is not None:
        return
    if _estado["passadas_da_cena"] is None:
        _estado["passadas_da_cena"] = cena.eevee.taa_samples
        _estado["cena_das_passadas"] = cena
    _trocar_as_passadas(cena, VISOR.passadas_do_visor)


def _devolver_as_passadas() -> None:
    if _estado["passadas_da_cena"] is None:
        return
    _trocar_as_passadas(_estado["cena_das_passadas"], _estado["passadas_da_cena"])
    _estado["passadas_da_cena"] = None
    _estado["cena_das_passadas"] = None


def _propriedades_do_shading(shading: bpy.types.View3DShading) -> list[str]:
    return [p.identifier for p in shading.bl_rna.properties
            if not p.is_readonly and p.type not in {"POINTER", "COLLECTION"} and p.identifier != "rna_type"]


def _assinatura(espaco: bpy.types.SpaceView3D) -> tuple:
    valores = [getattr(espaco.shading, nome) for nome in _propriedades_do_shading(espaco.shading)]
    return tuple(tuple(v) if hasattr(v, "__len__") and not isinstance(v, str) else v for v in valores)


def _shading_mudou(espaco: bpy.types.SpaceView3D) -> bool:
    """Se o shading da fonte mudou desde o último desenho."""
    return _assinatura(espaco) != _estado["assinatura"]


def _shading_que_desenha(espaco: bpy.types.SpaceView3D, motor: str) -> None:
    """O Rendered com um motor que não desenha fora da tela (o Cycles) sairia preto: o visor volta ao `shading_de_partida`."""
    if espaco.shading.type == "RENDERED" and motor not in MOTORES_DA_VISTA:
        espaco.shading.type = VISOR.shading_de_partida


def tela_da_fita(cena: bpy.types.Scene) -> bpy.types.Image:
    """A imagem preta do tamanho da fita, sobre a qual o Image Editor desenha as texturas (a fita ao vivo)."""
    largura, altura = (max(1, round(t * cena.visor_da_sala.escala)) for t in visor.tamanho_da_fita())
    imagem = bpy.data.images.get(VISOR.nome_da_imagem)
    if imagem is None:
        imagem = bpy.data.images.new(VISOR.nome_da_imagem, largura, altura, alpha=False)
    elif tuple(imagem.size) != (largura, altura):
        imagem.scale(largura, altura)
    else:
        return imagem
    imagem.pixels.foreach_set([0.0, 0.0, 0.0, 1.0] * (largura * altura))
    imagem.update()
    return imagem


def _redesenhar(tipos: set[str]) -> None:
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type in tipos:
                area.tag_redraw()


def _refazer() -> None:
    """Pede as texturas no próximo desenho de uma 3D View."""
    cena = bpy.context.window_manager.windows[0].scene if bpy.context.window_manager.windows else None
    if cena is None or not aberto():
        return None
    area = fonte()
    if area is None:
        return None
    espaco = area.spaces.active
    conteudo = visor.acompanhar_a_montagem(cena)
    _shading_que_desenha(espaco, conteudo.render.engine)
    _estado["assinatura"] = _assinatura(espaco)
    _baixar_as_passadas(conteudo, espaco.shading.type)
    tela_da_fita(cena)
    _estado["sujo"] = True
    _redesenhar({"VIEW_3D"})
    return None


def pedir() -> None:
    """Refaz as texturas depois de `atraso_s` sem novo pedido."""
    if bpy.app.background:
        return
    if bpy.app.timers.is_registered(_refazer):
        bpy.app.timers.unregister(_refazer)
    bpy.app.timers.register(_refazer, first_interval=VISOR.atraso_s)


def _seguir_o_shading() -> float | None:
    """Pede um desenho novo quando o shading do visor muda, no cabeçalho da Sala ou da Fita. Para sozinho sem Sala nem Fita
    à vista."""
    if not aberto():
        return None
    area = fonte()
    if area is not None and _shading_mudou(area.spaces.active):
        pedir()
    return VISOR.intervalo_da_janela_s


def seguir() -> None:
    if not bpy.app.timers.is_registered(_seguir_o_shading):
        bpy.app.timers.register(_seguir_o_shading, first_interval=0.0)
    pedir()


def desenhar_por_cima(desenho: DesenhoPorCima) -> None:
    """Outro complemento (o Nuvens do LInA, com o Modo leve) desenha no visor o que não passa pelo draw_view3d: depois de
    cada superfície, dentro do desenho fora da tela, com a vista e a projeção dela, a largura e a altura em pixels."""
    if desenho not in _por_cima:
        _por_cima.append(desenho)
    pedir()


def parar_de_desenhar_por_cima(desenho: DesenhoPorCima) -> None:
    if desenho in _por_cima:
        _por_cima.remove(desenho)
        pedir()


def textura(superficie: str) -> gpu.types.GPUTexture | None:
    return _texturas.get(superficie)


def _copiar(origem: gpu.types.GPUTexture, destino: gpu.types.GPUTexture) -> None:
    """Desenha `origem` cobrindo `destino` inteiro, sem mistura."""
    sombreador = gpu.shader.from_builtin("IMAGE")
    lote = batch_for_shader(sombreador, "TRI_FAN", {"pos": [(-1.0, -1.0, 0.0), (1.0, -1.0, 0.0), (1.0, 1.0, 0.0), (-1.0, 1.0, 0.0)],
                                                    "texCoord": [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]})
    quadro = gpu.types.GPUFrameBuffer(color_slots=destino)
    with quadro.bind():
        quadro.viewport_set(0, 0, destino.width, destino.height)
        gpu.state.blend_set("NONE")
        with gpu.matrix.push_pop(), gpu.matrix.push_pop_projection():
            gpu.matrix.load_identity()
            gpu.matrix.load_projection_matrix(Matrix.Identity(4))
            sombreador.uniform_sampler("image", origem)
            lote.draw(sombreador)


def _desenhar_as_superficies() -> None:
    """No desenho de qualquer 3D View, com a Sala ou a Fita à vista e um pedido: cada superfície pela câmera dela, no
    tamanho dela na fita, pela 3D View da fonte."""
    contexto = bpy.context
    if not _estado["sujo"] or not aberto():
        return
    _estado["sujo"] = False
    da_janela = contexto.scene
    cena = visor.cena_do_conteudo(da_janela)
    area = _area_da_fonte()
    if area is None:
        return
    regiao = next(r for r in area.regions if r.type == "WINDOW")
    try:
        cameras = visor.cameras_da_sala(visor.sala_do_visor(cena))
    except RuntimeError as erro:
        print(f"Visor da sala: {erro}")
        return
    if cena == da_janela:
        camada, grafo = contexto.view_layer, contexto.evaluated_depsgraph_get()
    else:
        camada = visor.camada(cena)
        grafo = camada.depsgraph
    escala = da_janela.visor_da_sala.escala
    try:
        inteira = visor.camera_da_sala_inteira(cena, visor.sala_do_visor(cena))
    except RuntimeError as erro:
        print(f"Visor da sala: {erro}")
        return
    avaliada = inteira.evaluated_get(grafo)
    lugar, giro, _ = avaliada.matrix_world.decompose()
    na_cena = Matrix.Translation(lugar) @ giro.to_matrix().to_4x4()
    valores = camera_da_sala.parametros(avaliada.data)
    perto, longe = max(valores["perto"], avaliada.data.clip_start), avaliada.data.clip_end
    enquadramentos = camera_da_sala.enquadramentos(SALA, valores)
    for camera in cameras:
        nome = camera[VISOR.propriedade_da_superficie]
        superficie = SALA.superficie(nome)
        largura = max(1, round(superficie.largura_m * SALA.pixels_por_metro * escala))
        altura = max(1, round(superficie.altura_m * SALA.pixels_por_metro * escala))
        guardada = _texturas.get(nome)
        if guardada is None or (guardada.width, guardada.height) != (largura, altura):
            guardada = _texturas[nome] = gpu.types.GPUTexture((largura, altura), format="RGBA8")
        fora = gpu.types.GPUOffScreen(largura, altura)
        try:
            # A mesma imagem do render final: a câmera comum que sala_camera.osl equivale nesta superfície.
            local, quadro = enquadramentos[nome]
            vista = (na_cena @ local).inverted()
            projecao = camera_da_sala.projecao(quadro, perto, longe)
            fora.draw_view3d(cena, camada, area.spaces.active, regiao, vista, projecao, do_color_management=True)
            if _por_cima:
                with fora.bind():
                    for desenho in _por_cima:
                        desenho(vista, projecao, largura, altura)
            _copiar(fora.texture_color, guardada)
        finally:
            fora.free()
    if not bpy.app.timers.is_registered(_depois_do_desenho):
        bpy.app.timers.register(_depois_do_desenho, first_interval=0.0)


def _depois_do_desenho() -> None:
    """Fora do desenho: o pedido de redesenho feito dentro dele se perde na janela que está sendo desenhada."""
    _redesenhar({"IMAGE_EDITOR"})
    _devolver_as_passadas()


def _no_cabecalho(menu: bpy.types.Header, contexto: bpy.types.Context) -> None:
    """Na Sala e na Fita, os ícones de shading do visor."""
    if not visor.mostra(contexto.space_data, {VISOR.nome_do_olho, VISOR.nome_da_imagem}):
        return
    area = _area_da_fonte()
    if area is not None:
        menu.layout.prop(area.spaces.active.shading, "type", expand=True, icon_only=True)


def _desenhar_na_fita() -> None:
    """No Image Editor com a fita ao vivo, cada textura no retângulo da superfície, espelhada como na fita renderizada."""
    contexto = bpy.context
    espaco = contexto.space_data
    if not visor.mostra(espaco, {VISOR.nome_da_imagem}):
        return
    try:
        sala = visor.sala_do_visor(visor.cena_do_conteudo(contexto.scene))
        cameras = {c[VISOR.propriedade_da_superficie]: c for c in visor.cameras_da_sala(sala)}
        lugares = visor.lugares_na_fita(contexto.scene.visor_da_sala.primeira_da_fita)
    except RuntimeError:
        return
    largura_da_fita, altura_da_fita = visor.tamanho_da_fita()
    no_ecra = contexto.region.view2d.view_to_region
    sombreador = gpu.shader.from_builtin("IMAGE")
    for nome, (x, y, w, h) in lugares.items():
        textura_ = textura(nome)
        if textura_ is None:
            continue
        x0, y0 = no_ecra(x / largura_da_fita, y / altura_da_fita, clip=False)
        x1, y1 = no_ecra(min(1.0, (x + w) / largura_da_fita), (y + h) / altura_da_fita, clip=False)
        u0, u1 = (1.0, 0.0) if cameras[nome]["espelhar_no_visor"] else (0.0, 1.0)
        lote = batch_for_shader(sombreador, "TRI_FAN", {"pos": [(x0, y0, 0.0), (x1, y0, 0.0), (x1, y1, 0.0), (x0, y1, 0.0)],
                                                        "texCoord": [(u0, 0.0), (u1, 0.0), (u1, 1.0), (u0, 1.0)]})
        sombreador.uniform_sampler("image", textura_)
        lote.draw(sombreador)


def _muda_as_superficies(grafo: bpy.types.Depsgraph) -> bool:
    """Se a atualização mexe no que as câmeras da sala veem. Fica de fora a atualização da cena sem nada
    marcado, que não chega às câmeras."""
    for atualizacao in grafo.updates:
        marcada = atualizacao.is_updated_geometry or atualizacao.is_updated_transform or atualizacao.is_updated_shading
        if isinstance(atualizacao.id, bpy.types.Scene) and not marcada:
            continue
        return True
    return False


@bpy.app.handlers.persistent
def _ao_mudar(cena: bpy.types.Scene, grafo: bpy.types.Depsgraph | None = None) -> None:
    if cena != bpy.context.scene:
        return   # a cena de uma faixa da montagem, levada ao quadro pelo próprio visor
    if _estado["ignorar_a_troca"]:
        _estado["ignorar_a_troca"] = False
        return
    if not aberto() or (grafo is not None and not _muda_as_superficies(grafo)):
        return
    tela = bpy.context.screen
    if tela is not None and tela.is_animation_playing:
        return
    pedir()


@bpy.app.handlers.persistent
def _ao_mudar_o_quadro(cena: bpy.types.Scene, _grafo: object = None) -> None:
    """Ao mudar o quadro e ao parar a reprodução. Durante ela, o atraso nunca venceria: o quadro muda antes. A cena de uma
    faixa da montagem, levada ao quadro pelo próprio visor, não pede outro desenho."""
    if cena != bpy.context.scene or not aberto():
        return
    tela = bpy.context.screen
    if tela is None or not tela.is_animation_playing:
        pedir()
    elif VISOR.redesenhar_no_play:
        _refazer()


@bpy.app.handlers.persistent
def _ao_abrir(_arquivo: str, _grafo: object = None) -> None:
    """Num arquivo salvo com a Sala ou a Fita, as texturas recomeçam do zero."""
    _texturas.clear()
    _estado["assinatura"] = None
    if aberto():
        seguir()


HANDLERS = ((bpy.app.handlers.depsgraph_update_post, _ao_mudar), (bpy.app.handlers.frame_change_post, _ao_mudar_o_quadro),
            (bpy.app.handlers.animation_playback_post, _ao_mudar_o_quadro), (bpy.app.handlers.load_post, _ao_abrir))


def register() -> None:
    # As texturas saem no desenho de uma 3D View: dentro do desenho do Image Editor, o desenho fora da tela faz a Fita
    # parar de se redesenhar.
    _desenhos.append((bpy.types.SpaceView3D,
                      bpy.types.SpaceView3D.draw_handler_add(_desenhar_as_superficies, (), "WINDOW", "POST_PIXEL")))
    _desenhos.append((bpy.types.SpaceImageEditor,
                      bpy.types.SpaceImageEditor.draw_handler_add(_desenhar_na_fita, (), "WINDOW", "POST_PIXEL")))
    for lista, funcao in HANDLERS:
        lista.append(funcao)
    bpy.types.IMAGE_HT_header.append(_no_cabecalho)


def unregister() -> None:
    for funcao in (_refazer, _seguir_o_shading, _depois_do_desenho):
        if bpy.app.timers.is_registered(funcao):
            bpy.app.timers.unregister(funcao)
    bpy.types.IMAGE_HT_header.remove(_no_cabecalho)
    for lista, funcao in HANDLERS:
        lista.remove(funcao)
    for espaco, desenho in _desenhos:
        espaco.draw_handler_remove(desenho, "WINDOW")
    _desenhos.clear()
    _texturas.clear()
    _por_cima.clear()
