"""Coleção marcada chega liberada com Library Override quando é solta do Asset Browser na 3D View.

Soltar uma coleção vinculada cria um vazio que mostra a coleção (instância), e o Blender registra o operador
`object.collection_external_asset_drop` no histórico, com o `session_uid` da coleção. Depois de cada atualização da
cena, o complemento olha o último operador do histórico: se for um soltar que ele ainda não viu e a coleção tiver a
propriedade de dados.json (`ao_soltar.propriedade`), troca o vazio pela hierarquia liberada, uma vez só. Ao abrir um
arquivo, desfazer ou refazer, o último operador do histórico passa a contar como visto: nada do que já está no arquivo
é tocado.

O valor da propriedade diz o que liberar, como no menu Library Override > Make do Outliner. Hoje só
SELECTED_AND_CONTENT (a coleção e tudo dentro dela, editável) é aceito; outro valor para com erro.
"""
import bpy
from mathutils import Matrix

from . import dados

SOLTAR = "OBJECT_OT_collection_external_asset_drop"
LIBERAR_TUDO = "SELECTED_AND_CONTENT"
PROPRIEDADE = dados.ao_soltar().propriedade

_visto: int = 0


def _ultimo_operador() -> bpy.types.Operator | None:
    operadores = bpy.context.window_manager.operators
    return operadores[-1] if len(operadores) else None


def _marcar_como_visto() -> None:
    global _visto
    ultimo = _ultimo_operador()
    _visto = ultimo.as_pointer() if ultimo is not None else 0


def instancia_solta(cena: bpy.types.Scene, ativo: bpy.types.Object | None, session_uid: int) -> bpy.types.Object | None:
    """O vazio que o soltar acabou de criar: o objeto ativo, instância da coleção vinculada de `session_uid`."""
    if ativo is None or ativo.name not in cena.objects:
        return None
    colecao = ativo.instance_collection
    if ativo.instance_type != "COLLECTION" or colecao is None or colecao.session_uid != session_uid:
        return None
    if colecao.library is None:
        return None
    return ativo


def liberar(cena: bpy.types.Scene, camada: bpy.types.ViewLayer, vazio: bpy.types.Object) -> bpy.types.Collection:
    """Troca o vazio pela coleção liberada, com tudo dentro editável, no mesmo lugar e com o mesmo nome do asset."""
    colecao = vazio.instance_collection
    modo = colecao[PROPRIEDADE]
    if modo != LIBERAR_TUDO:
        raise ValueError(f'"{colecao.name}": {PROPRIEDADE} = "{modo}"; o complemento só sabe liberar {LIBERAR_TUDO}')
    # O vazio leva o nome do asset; renomeado, o objeto de cima da coleção liberada fica com o nome dele.
    vazio.name = f"{vazio.name} (soltando)"
    # A instância mostra a coleção deslocada por instance_offset e posta pela matriz do vazio; as raízes liberadas
    # recebem a mesma conta, para a sala ficar onde foi solta.
    lugar = vazio.matrix_world @ Matrix.Translation(-colecao.instance_offset)
    liberada = colecao.override_hierarchy_create(cena, camada, reference=vazio, do_fully_editable=True)
    for objeto in liberada.all_objects:
        if objeto.parent is None:
            objeto.matrix_world = lugar @ objeto.matrix_world
    bpy.data.objects.remove(vazio)
    return liberada


def _liberar_depois(nome_da_cena: str, session_uid: int) -> None:
    cena = bpy.data.scenes.get(nome_da_cena)
    if cena is None:
        return None
    camada = bpy.context.view_layer
    vazio = instancia_solta(cena, camada.objects.active, session_uid)
    if vazio is None:
        print(f"Nuvens do LInA: a coleção solta (session_uid {session_uid}) não é o objeto ativo; nada foi liberado.")
        return None
    liberada = liberar(cena, camada, vazio)
    janela = bpy.context.window_manager.windows[0]
    with bpy.context.temp_override(window=janela):
        bpy.ops.ed.undo_push(message=f"Liberar {liberada.name}")
    print(f'Nuvens do LInA: "{liberada.name}" chegou liberada (Library Override).')
    return None


@bpy.app.handlers.persistent
def ao_atualizar(cena: bpy.types.Scene, _grafo: bpy.types.Depsgraph) -> None:
    global _visto
    ultimo = _ultimo_operador()
    if ultimo is None or ultimo.bl_idname != SOLTAR or ultimo.as_pointer() == _visto:
        return
    _visto = ultimo.as_pointer()
    session_uid = ultimo.properties.session_uid
    colecao = next((c for c in bpy.data.collections if c.session_uid == session_uid), None)
    if colecao is None or PROPRIEDADE not in colecao or not ultimo.properties.use_instance:
        return
    # Mudar dados dentro do handler do depsgraph não é permitido: a troca roda logo depois, fora dele.
    nome_da_cena = cena.name
    bpy.app.timers.register(lambda: _liberar_depois(nome_da_cena, session_uid), first_interval=0.0)


@bpy.app.handlers.persistent
def ao_abrir_ou_desfazer(*_argumentos: object) -> None:
    _marcar_como_visto()


HANDLERS = ((bpy.app.handlers.depsgraph_update_post, ao_atualizar),
            (bpy.app.handlers.load_post, ao_abrir_ou_desfazer),
            (bpy.app.handlers.undo_post, ao_abrir_ou_desfazer),
            (bpy.app.handlers.redo_post, ao_abrir_ou_desfazer))


def register() -> None:
    _marcar_como_visto()
    for lista, funcao in HANDLERS:
        lista.append(funcao)


def unregister() -> None:
    for lista, funcao in HANDLERS:
        lista.remove(funcao)
