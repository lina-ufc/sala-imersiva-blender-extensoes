"""Lê dados.json, ao lado deste arquivo. Não depende do Blender, para os scripts do nuvens-blender lerem o mesmo arquivo."""
import json
import os
from dataclasses import dataclass
from pathlib import Path

ARQUIVO = Path(__file__).resolve().parent / "dados.json"


@dataclass(frozen=True)
class Reducao:
    """Os nomes da redução das peças com efeito no Modo leve (reducao.py)."""
    nome_do_modificador: str
    nome_do_grupo: str                # com {atributos}
    propriedade_do_grupo: str         # no grupo de nós, com os atributos de ponto que ele leva
    entrada_da_parte: str             # a entrada do grupo com a parte dos pontos, de 0 a 1
    entrada_do_material: str          # a entrada do grupo com o material da peça, que os pontos novos levam
    atributo_do_id: str               # o número de cada ponto na peça inteira


@dataclass(frozen=True)
class RestosDaCopia:
    """As marcas da cópia reduzida da 1.17 e da 1.18, que um salvamento automático dessas versões pode ter gravado."""
    propriedade_da_copia: str         # no objeto da cópia e na coleção dela
    propriedade_da_amostra: str       # nos dados reduzidos


@dataclass(frozen=True)
class ModoLeve:
    propriedade_da_cena: str          # até a 1.16, a fração na janela; o complemento só a apaga, o nuvens-blender ainda a lê
    nome_do_no: str
    semente: int
    propriedades_da_cena: dict[str, str]   # as do foco, que a 1.13 gravava; o complemento só as apaga das cenas
    sem_limite_m: float
    raio_da_selecao_px: int           # o quadrado lido em volta do mouse na seleção por clique do Modo leve
    reducao: Reducao
    restos_da_copia: RestosDaCopia


@dataclass(frozen=True)
class VersaoLeve:
    """As peças leves (pecas_leves.py): o fim do nome do arquivo, os textos da lista do painel e do Outliner e, para o
    versao_leve.py do nuvens-blender, a parte dos pontos que ficam e a semente do sorteio."""
    sufixo: str
    fracao_dos_pontos: float
    semente: int
    titulo_da_lista: str
    ver_completa: str
    ver_leve: str
    sem_pecas: str

    def leve_de(self, caminho: str) -> str | None:
        """O caminho da versão leve de uma peça, ou None se `caminho` já é a leve ou não é um .blend."""
        raiz, extensao = os.path.splitext(caminho)
        if extensao != ".blend" or raiz.endswith(self.sufixo):
            return None
        return raiz + self.sufixo + extensao

    def completa_de(self, caminho: str) -> str | None:
        """O caminho da peça completa de uma versão leve, ou None se `caminho` não é uma versão leve."""
        raiz, extensao = os.path.splitext(caminho)
        if extensao != ".blend" or not raiz.endswith(self.sufixo):
            return None
        return raiz[:-len(self.sufixo)] + extensao


@dataclass(frozen=True)
class GeradasNoComplemento:
    """As versões leves que o próprio complemento grava (leves_locais.py), para as peças sem a versão leve na biblioteca."""
    pasta: str                                   # dentro da pasta de usuário do complemento
    intervalo_s: float                           # entre uma conferência da fila e a seguinte
    nice_fora_do_windows: int
    classes_do_processo_no_windows: tuple[str, ...]   # nomes de constantes do módulo subprocess
    texto_gerando: str                           # com {peca} e {fila}


def _tabela(arquivo: Path) -> dict[str, dict[str, object]]:
    return json.loads(arquivo.read_text(encoding="utf-8"))


def complemento_da_sala(arquivo: Path = ARQUIVO) -> str:
    """O id do complemento Sala imersiva, cujo visor também desenha as peças do Modo leve (no_visor.py)."""
    return str(_tabela(arquivo)["complemento_da_sala"])


def modo_leve(arquivo: Path = ARQUIVO) -> ModoLeve:
    m = _tabela(arquivo)["modo_leve"]
    propriedades = {str(k): str(v) for k, v in m["propriedades_da_cena"].items()}
    faltam = {"foco", "raio_do_foco_m", "fim_da_transicao_m", "fracao_fora_do_foco"} - set(propriedades)
    if faltam:
        raise ValueError(f"modo_leve.propriedades_da_cena: faltam {sorted(faltam)}")
    leve = ModoLeve(str(m["propriedade_da_cena"]), str(m["nome_do_no"]), int(m["semente"]), propriedades, float(m["sem_limite_m"]),
                    int(m["raio_da_selecao_px"]), Reducao(**{k: str(v) for k, v in m["reducao"].items()}),
                    RestosDaCopia(**{k: str(v) for k, v in m["restos_da_copia_reduzida"].items()}))
    if "{atributos}" not in leve.reducao.nome_do_grupo:
        raise ValueError("modo_leve.reducao.nome_do_grupo: precisa de {atributos}")
    if leve.raio_da_selecao_px < 0:
        raise ValueError("modo_leve.raio_da_selecao_px: não pode ser negativo")
    return leve


def versao_leve(arquivo: Path = ARQUIVO) -> VersaoLeve:
    v = _tabela(arquivo)["modo_leve"]["versao_leve"]
    leve = VersaoLeve(str(v["sufixo"]), float(v["fracao_dos_pontos"]), int(v["semente"]), str(v["titulo_da_lista"]),
                      str(v["ver_completa"]), str(v["ver_leve"]), str(v["sem_pecas"]))
    if not leve.sufixo:
        raise ValueError("modo_leve.versao_leve.sufixo: não pode ser vazio")
    if not 0 < leve.fracao_dos_pontos < 1:
        raise ValueError(f"modo_leve.versao_leve.fracao_dos_pontos vai de 0 a 1, exclusivos; veio {leve.fracao_dos_pontos}")
    return leve


def geradas_no_complemento(arquivo: Path = ARQUIVO) -> GeradasNoComplemento:
    g = _tabela(arquivo)["modo_leve"]["versao_leve"]["geradas_no_complemento"]
    geradas = GeradasNoComplemento(str(g["pasta"]), float(g["intervalo_s"]), int(g["nice_fora_do_windows"]),
                                   tuple(str(c) for c in g["classes_do_processo_no_windows"]), str(g["texto_gerando"]))
    if not geradas.pasta:
        raise ValueError("modo_leve.versao_leve.geradas_no_complemento.pasta: não pode ser vazia")
    if geradas.intervalo_s <= 0:
        raise ValueError(f"modo_leve.versao_leve.geradas_no_complemento.intervalo_s precisa ser positivo; veio {geradas.intervalo_s}")
    return geradas
