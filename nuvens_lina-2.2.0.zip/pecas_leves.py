"""As peças leves. Ao lado de cada peça `<peça>.blend` da biblioteca, `<peça><sufixo>.blend` (`versao_leve.py` do nuvens-blender)
tem uma parte dos pontos e os mesmos nomes por dentro. Com o Modo leve ligado, a cena vincula as leves; desligado, as completas.
O Blender carrega os vínculos ao abrir o arquivo, antes de qualquer complemento agir: por isso o arquivo é sempre salvo apontando
para as leves, e abre leve em qualquer máquina. A troca é o Relocate do Outliner (modo Blender File, botão direito na biblioteca):
o caminho muda e a biblioteca é recarregada; as liberações (Library Override) seguem, porque os nomes são os mesmos. Biblioteca
sem a versão ao lado ganha uma gravada pelo próprio complemento, numa pasta da máquina (leves_locais.py); o arquivo nunca é
salvo apontando para ela. O render das paradas (`render.py` do nuvens-blender) chama `para_as_completas`."""
import os

import bpy

from . import dados, leves_locais

VERSAO_LEVE = dados.versao_leve()


def _trocas(para_leves: bool) -> list[tuple[bpy.types.Library, str]]:
    """As bibliotecas vinculadas direto pela cena que têm a outra versão no disco, com o caminho dela."""
    trocas = []
    for biblioteca in bpy.data.libraries:
        if biblioteca.parent is not None:
            continue
        novo = VERSAO_LEVE.leve_de(biblioteca.filepath) if para_leves else VERSAO_LEVE.completa_de(biblioteca.filepath)
        if novo is not None and os.path.isfile(bpy.path.abspath(novo)):
            trocas.append((biblioteca, novo))
    return trocas


def biblioteca_de(id_: bpy.types.ID) -> bpy.types.Library | None:
    """A biblioteca de onde vem um objeto ou uma coleção da cena: a da referência, se liberado; a dele, se só vinculado; a dos
    dados, num objeto local com os dados vinculados."""
    if id_.override_library is not None:
        return id_.override_library.reference.library
    if id_.library is not None:
        return id_.library
    dado = getattr(id_, "data", None)
    return dado.library if isinstance(dado, bpy.types.ID) else None


def _leve_da_biblioteca(caminho: str) -> str | None:
    """A leve ao lado da completa na biblioteca, se existe."""
    leve = VERSAO_LEVE.leve_de(caminho)
    return leve if leve is not None and os.path.isfile(bpy.path.abspath(leve)) else None


def _completas_soltas() -> list[bpy.types.Library]:
    """As bibliotecas vinculadas direto pela cena que estão na completa e não têm a leve ao lado."""
    return [b for b in bpy.data.libraries if b.parent is None and VERSAO_LEVE.completa_de(b.filepath) is None
            and not leves_locais.e_daqui(b.filepath) and _leve_da_biblioteca(b.filepath) is None]


def pecas_com_as_duas() -> list[tuple[bpy.types.Library, bool]]:
    """As bibliotecas vinculadas direto pela cena que têm a versão leve (ao lado ou gravada aqui) e a completa no disco, com
    True se estão na completa."""
    pecas = []
    for biblioteca in bpy.data.libraries:
        if biblioteca.parent is not None:
            continue
        if VERSAO_LEVE.completa_de(biblioteca.filepath) is not None or leves_locais.e_daqui(biblioteca.filepath):
            pecas.append((biblioteca, False))
            continue
        if _leve_da_biblioteca(biblioteca.filepath) is not None or leves_locais.leve_de(biblioteca.filepath) is not None:
            pecas.append((biblioteca, True))
    return sorted(pecas, key=lambda par: par[0].name)


def nome_da_peca(biblioteca: bpy.types.Library) -> str:
    caminho = VERSAO_LEVE.completa_de(biblioteca.filepath) or biblioteca.filepath
    return os.path.splitext(os.path.basename(caminho))[0]


def trocar_uma(biblioteca: bpy.types.Library, completa: bool) -> bool:
    """Põe uma peça na completa ou na leve; devolve se trocou."""
    if completa and leves_locais.e_daqui(biblioteca.filepath):
        return leves_locais.trocar_para_a_completa(biblioteca)
    if not completa and _leve_da_biblioteca(biblioteca.filepath) is None:
        return leves_locais.trocar_para_a_leve(biblioteca)
    novo = VERSAO_LEVE.completa_de(biblioteca.filepath) if completa else VERSAO_LEVE.leve_de(biblioteca.filepath)
    if novo is None or not os.path.isfile(bpy.path.abspath(novo)):
        return False
    biblioteca.filepath = novo
    biblioteca.reload()
    return True


def _trocar(para_leves: bool) -> int:
    trocas = _trocas(para_leves)
    for biblioteca, novo in trocas:
        biblioteca.filepath = novo
        biblioteca.reload()
    return len(trocas)


def para_as_leves() -> int:
    """Passa as peças da cena às versões leves; devolve quantas bibliotecas trocou. As peças sem a leve ao lado vão para a
    gravada aqui ou, sem ela, para a fila de leves_locais."""
    trocadas = _trocar(True)
    leves_locais.ativar(True)
    sem_leve = []
    for biblioteca in _completas_soltas():
        if leves_locais.trocar_para_a_leve(biblioteca):
            trocadas += 1
        else:
            sem_leve.append(biblioteca.filepath)
    leves_locais.pedir(sem_leve)
    return trocadas


def para_as_completas() -> int:
    """Volta as peças da cena às completas; devolve quantas bibliotecas trocou."""
    leves_locais.ativar(False)
    daqui = [b for b in bpy.data.libraries if b.parent is None and leves_locais.e_daqui(b.filepath)]
    return _trocar(False) + sum(leves_locais.trocar_para_a_completa(b) for b in daqui)


_caminhos_da_sessao: dict[str, str] = {}


@bpy.app.handlers.persistent
def _antes_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    """O arquivo leva o caminho das leves da biblioteca; a peça numa leve gravada aqui vai com a leve da biblioteca ou, sem
    ela, com a completa. A sessão segue com o que tem na memória, sem recarregar."""
    _caminhos_da_sessao.clear()
    for biblioteca, novo in _trocas(True):
        _caminhos_da_sessao[biblioteca.name] = biblioteca.filepath
        biblioteca.filepath = novo
    for biblioteca in bpy.data.libraries:
        completa = leves_locais.completa_de(biblioteca) if biblioteca.parent is None else None
        if completa is None:
            continue
        _caminhos_da_sessao[biblioteca.name] = biblioteca.filepath
        biblioteca.filepath = _leve_da_biblioteca(completa) or completa


@bpy.app.handlers.persistent
def _depois_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    for nome, caminho in _caminhos_da_sessao.items():
        bpy.data.libraries[nome].filepath = caminho
    _caminhos_da_sessao.clear()


HANDLERS = ((bpy.app.handlers.save_pre, _antes_de_salvar), (bpy.app.handlers.save_post, _depois_de_salvar),
            (bpy.app.handlers.save_post_fail, _depois_de_salvar))


def register() -> None:
    for lista, funcao in HANDLERS:
        lista.append(funcao)


def unregister() -> None:
    for lista, funcao in HANDLERS:
        if funcao in lista:
            lista.remove(funcao)
