"""As versões leves que o próprio complemento grava, para as peças que não têm `<peça><sufixo>.blend` ao lado na biblioteca.

Com o Modo leve ligado, cada peça da cena sem a versão leve ao lado entra numa fila. Um Blender sem janela, à parte e com
prioridade baixa, grava a versão leve dela (gerar_leve.py, o mesmo sorteio do `versao_leve.py` do nuvens-blender) numa pasta
da máquina, dentro da pasta de usuário do complemento; uma peça por vez, e nunca durante um render. Quando fica pronta, a cena
troca a peça por ela, como faz com a leve da biblioteca. Ao lado de cada uma fica `origem.json`, com a peça completa de onde
ela saiu e o tamanho e a data dela: se a completa muda, a leve é gravada de novo. Peça que não deu certo (um .blend sem nuvem
de pontos, por exemplo) fica marcada no mesmo arquivo e só é tentada de novo quando a completa mudar.

O arquivo da cena nunca é salvo apontando para esta pasta, que só existe nesta máquina: pecas_leves.py troca, antes de
salvar, cada peça daqui pela leve da biblioteca ou, sem ela, pela completa."""
import hashlib
import json
import os
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

import bpy

from . import dados

GERADAS = dados.geradas_no_complemento()
VERSAO_LEVE = dados.versao_leve()
SCRIPT = Path(__file__).resolve().parent / "gerar_leve.py"
ORIGEM = "origem.json"
PARCIAL = ".gravando"


@dataclass
class _Estado:
    fila: list[str] = field(default_factory=list)            # caminhos absolutos das completas
    processo: subprocess.Popen | None = None
    gerando: str = ""                                         # a completa que o processo está gravando
    ativo: bool = False                                       # se a cena deve trocar as peças pelas leves que ficarem prontas
    originais: dict[str, str] = field(default_factory=dict)  # biblioteca -> o caminho dela antes de ir para a leve daqui


_E = _Estado()


def pasta() -> Path:
    return Path(bpy.utils.extension_path_user(__package__, path=GERADAS.pasta, create=True))


def _absoluto(caminho: str) -> str:
    return os.path.normpath(bpy.path.abspath(caminho))


def _pasta_da_peca(completa: str) -> Path:
    return pasta() / hashlib.sha1(completa.encode("utf-8")).hexdigest()[:16]


def _destino(completa: str) -> Path:
    raiz, extensao = os.path.splitext(os.path.basename(completa))
    return _pasta_da_peca(completa) / f"{raiz}{VERSAO_LEVE.sufixo}{extensao}"


def _carimbo(completa: str) -> dict[str, int]:
    estado = os.stat(completa)
    return {"tamanho": estado.st_size, "modificada_ns": estado.st_mtime_ns}


def _origem(completa: str) -> dict[str, object] | None:
    """O origem.json da peça, se ele ainda vale para a completa como ela está no disco."""
    arquivo = _pasta_da_peca(completa) / ORIGEM
    if not arquivo.is_file():
        return None
    origem = json.loads(arquivo.read_text(encoding="utf-8"))
    if origem.get("completa") != completa or origem.get("carimbo") != _carimbo(completa):
        return None
    return origem


def leve_de(completa: str) -> str | None:
    """A leve gravada aqui para a completa (caminho absoluto), se ela existe e ainda vale."""
    completa = _absoluto(completa)
    if not os.path.isfile(completa):
        return None
    origem = _origem(completa)
    destino = _destino(completa)
    if origem is None or origem.get("falhou") or not destino.is_file():
        return None
    return str(destino)


def e_daqui(caminho: str) -> bool:
    try:
        Path(_absoluto(caminho)).relative_to(pasta())
    except ValueError:
        return False
    return True


def completa_de(biblioteca: bpy.types.Library) -> str | None:
    """O caminho da completa de uma biblioteca que está numa leve daqui: o que ela tinha antes da troca ou, num arquivo aberto
    com ela (um salvamento automático), o que o origem.json diz."""
    if not e_daqui(biblioteca.filepath):
        return None
    if biblioteca.name in _E.originais:
        return _E.originais[biblioteca.name]
    arquivo = Path(_absoluto(biblioteca.filepath)).parent / ORIGEM
    return str(json.loads(arquivo.read_text(encoding="utf-8"))["completa"]) if arquivo.is_file() else None


def trocar_para_a_leve(biblioteca: bpy.types.Library) -> bool:
    """Põe a biblioteca na leve daqui, se houver; devolve se trocou."""
    leve = leve_de(biblioteca.filepath)
    if leve is None:
        return False
    _E.originais[biblioteca.name] = biblioteca.filepath
    biblioteca.filepath = leve
    biblioteca.reload()
    return True


def trocar_para_a_completa(biblioteca: bpy.types.Library) -> bool:
    completa = completa_de(biblioteca)
    if completa is None:
        return False
    biblioteca.filepath = completa
    biblioteca.reload()
    _E.originais.pop(biblioteca.name, None)
    return True


def pedir(completas: list[str]) -> None:
    """Põe na fila as completas (caminhos como estão nas bibliotecas) que ainda não têm leve daqui nem falharam."""
    for caminho in completas:
        completa = _absoluto(caminho)
        if not os.path.isfile(completa) or completa in _E.fila or completa == _E.gerando:
            continue
        origem = _origem(completa)
        if origem is not None and (origem.get("falhou") or _destino(completa).is_file()):
            continue
        _E.fila.append(completa)
    if _E.fila and not bpy.app.timers.is_registered(_trabalhar):
        bpy.app.timers.register(_trabalhar, first_interval=GERADAS.intervalo_s, persistent=True)


def ativar(ativo: bool) -> None:
    """Com o Modo leve desligado, a fila para; a peça que está sendo gravada termina e fica pronta para a próxima vez."""
    _E.ativo = ativo
    if not ativo:
        _E.fila.clear()


def situacao() -> str:
    """A linha do painel enquanto há peça sendo gravada, ou vazio."""
    if not _E.gerando:
        return ""
    peca = os.path.splitext(os.path.basename(_E.gerando))[0]
    return GERADAS.texto_gerando.format(peca=peca, fila=len(_E.fila))


def _comecar(completa: str) -> None:
    destino = _destino(completa)
    destino.parent.mkdir(parents=True, exist_ok=True)
    parcial = destino.with_name(destino.stem + PARCIAL + destino.suffix)
    comando = [bpy.app.binary_path, "--background", "--factory-startup", "--python", str(SCRIPT), "--", completa, str(parcial)]
    with open(destino.parent / "gravacao.log", "w", encoding="utf-8") as registro:
        if sys.platform == "win32":
            classes = 0
            for nome in GERADAS.classes_do_processo_no_windows:
                classes |= getattr(subprocess, nome)
            _E.processo = subprocess.Popen(comando, stdout=registro, stderr=subprocess.STDOUT, creationflags=classes)
        else:
            # o nice da linha de comando, e não o preexec_fn, que não é seguro com a linha de fundo do Modo leve
            _E.processo = subprocess.Popen(["nice", "-n", str(GERADAS.nice_fora_do_windows), *comando], stdout=registro,
                                           stderr=subprocess.STDOUT)
    _E.gerando = completa


def _terminar() -> None:
    """Fecha a peça que o processo gravou: põe a leve no lugar e grava o origem.json, ou marca a falha nele."""
    completa, processo = _E.gerando, _E.processo
    _E.gerando, _E.processo = "", None
    if processo is None or not os.path.isfile(completa):
        return
    destino = _destino(completa)
    parcial = destino.with_name(destino.stem + PARCIAL + destino.suffix)
    origem: dict[str, object] = {"completa": completa, "carimbo": _carimbo(completa)}
    if processo.returncode == 0 and parcial.is_file():
        os.replace(parcial, destino)
    else:
        origem["falhou"] = f"código {processo.returncode}; ver gravacao.log nesta pasta"
        print(f"Nuvens do LInA: a versão leve de {completa} não saiu ({origem['falhou']}, em {destino.parent})")
    (destino.parent / ORIGEM).write_text(json.dumps(origem, ensure_ascii=False, indent=1), encoding="utf-8")
    if _E.ativo and not origem.get("falhou"):
        for biblioteca in bpy.data.libraries:
            if biblioteca.parent is None and _absoluto(biblioteca.filepath) == completa:
                trocar_para_a_leve(biblioteca)


def _redesenhar() -> None:
    """A linha do painel muda quando uma peça começa ou termina."""
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            area.tag_redraw()


def _trabalhar() -> float | None:
    if _E.processo is not None:
        if _E.processo.poll() is None:
            return GERADAS.intervalo_s
        _terminar()
        _redesenhar()
    if not _E.fila:
        return None
    if bpy.app.is_job_running("RENDER"):
        return GERADAS.intervalo_s
    _comecar(_E.fila.pop(0))
    _redesenhar()
    return GERADAS.intervalo_s


@bpy.app.handlers.persistent
def _ao_abrir(_arquivo: str, _grafo: object = None) -> None:
    _E.originais.clear()


def register() -> None:
    bpy.app.handlers.load_post.append(_ao_abrir)


def unregister() -> None:
    if _ao_abrir in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_ao_abrir)
    if bpy.app.timers.is_registered(_trabalhar):
        bpy.app.timers.unregister(_trabalhar)
    _E.fila.clear()
    if _E.processo is not None and _E.processo.poll() is None:
        _E.processo.terminate()
    _E.processo, _E.gerando = None, ""
