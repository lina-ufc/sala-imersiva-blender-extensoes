"""Grava a versão leve de uma peça: a `fracao_dos_pontos` dos pontos de cada nuvem dela, sorteados por igual com a `semente`
(`modo_leve.versao_leve` no dados.json), com todos os atributos de ponto, em níveis de novo (niveis.py) e com os mesmos nomes
por dentro, para a cena trocar uma pela outra pelo caminho do arquivo. A coleção deixa de ser asset, senão a peça aparece em
dobro no Asset Browser. Abre a peça como arquivo principal, então só roda num Blender sem janela, à parte: o `versao_leve.py`
do nuvens-blender chama `gravar`, e o complemento (leves_locais.py) roda este arquivo como script:

    blender --background --factory-startup --python gerar_leve.py -- <peça.blend> <destino.blend>

Como script, o complemento não está ligado: os módulos vizinhos entram por um pacote só deles, sem o __init__.py."""
import importlib
import sys
import types
from pathlib import Path

import bpy
import numpy as np

if __package__:
    from . import dados, niveis, pontos_da_peca
else:
    _PACOTE = "nuvens_lina_gerar_leve"
    _modulo = types.ModuleType(_PACOTE)
    _modulo.__path__ = [str(Path(__file__).resolve().parent)]
    sys.modules[_PACOTE] = _modulo
    dados = importlib.import_module(f"{_PACOTE}.dados")
    niveis = importlib.import_module(f"{_PACOTE}.niveis")
    pontos_da_peca = importlib.import_module(f"{_PACOTE}.pontos_da_peca")


def regras_dos_niveis() -> "niveis.RegrasDosNiveis":
    r = dados._tabela(dados.ARQUIVO)["modo_leve"]["niveis"]
    return niveis.RegrasDosNiveis(pontos_por_no=int(r["pontos_por_no"]), nivel_maximo=int(r["nivel_maximo"]),
                                  semente=int(r["semente"]))


def reduzir(dado: bpy.types.PointCloud, fracao: float, rng: np.random.Generator) -> bpy.types.PointCloud:
    """Uma nuvem nova com a parte sorteada dos pontos de `dado` e todos os atributos deles, no lugar de `dado` (mesmo nome,
    mesmos materiais e propriedades, os mesmos objetos usando-a)."""
    total = pontos_da_peca.quantos(dado)
    escolhidos = np.sort(rng.choice(total, max(1, round(total * fracao)), replace=False))
    nova = bpy.data.pointclouds.new(dado.name + ".leve")
    nova.resize(len(escolhidos))
    for nome, tipo in pontos_da_peca.atributos(dado):
        if nome not in nova.attributes:
            nova.attributes.new(nome, tipo, "POINT")
        pontos_da_peca.gravar(nova, nome, pontos_da_peca.ler(dado, nome, escolhidos=escolhidos))
    for material in dado.materials:
        nova.materials.append(material)
    for chave in dado.keys():   # noqa: SIM118 (o ID do Blender não se percorre sem keys)
        if chave != niveis.PROPRIEDADE:
            nova[chave] = dado[chave]
    nome = dado.name
    dado.user_remap(nova)
    bpy.data.pointclouds.remove(dado)
    nova.name = nome
    return nova


def em_niveis(nuvem: bpy.types.PointCloud, regras: "niveis.RegrasDosNiveis") -> None:
    """Reordena os pontos da nuvem em níveis e grava a tabela nela."""
    hierarquia = niveis.montar(pontos_da_peca.posicoes(nuvem), regras)
    for nome, _tipo in pontos_da_peca.atributos(nuvem):
        pontos_da_peca.gravar(nuvem, nome, pontos_da_peca.ler(nuvem, nome)[hierarquia.ordem])
    nuvem[niveis.PROPRIEDADE] = hierarquia.tabela.para_propriedade()
    nuvem.update_tag()


def gravar(completa: Path, destino: Path, leve: "dados.VersaoLeve", regras: "niveis.RegrasDosNiveis") -> None:
    bpy.ops.wm.open_mainfile(filepath=str(completa))
    rng = np.random.default_rng(leve.semente)
    nuvens = [d for d in bpy.data.pointclouds if d.library is None]
    if not nuvens:
        raise ValueError(f"{completa.name}: sem nuvem de pontos")
    for dado in nuvens:
        antes = pontos_da_peca.quantos(dado)
        nova = reduzir(dado, leve.fracao_dos_pontos, rng)
        em_niveis(nova, regras)
        print(f"{completa.stem} / {nova.name}: {antes:,} -> {pontos_da_peca.quantos(nova):,} pontos", flush=True)
    for colecao in bpy.data.collections:
        if colecao.library is None and colecao.asset_data is not None:
            colecao.asset_clear()
    bpy.ops.wm.save_as_mainfile(filepath=str(destino), compress=True, relative_remap=True)


def _principal() -> None:
    argumentos = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if len(argumentos) != 2:
        raise SystemExit("uso: blender --background --factory-startup --python gerar_leve.py -- <peça.blend> <destino.blend>")
    gravar(Path(argumentos[0]), Path(argumentos[1]), dados.versao_leve(), regras_dos_niveis())


if __name__ == "__main__":
    _principal()
