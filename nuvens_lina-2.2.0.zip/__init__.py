"""Complemento do Blender das nuvens de pontos do Filme da Nuvem. A sala (a Sala para soltar, o visor e o render da fita) é
do complemento Sala imersiva, que também libera as peças de nuvem soltas do Asset Browser. Cada parte é um módulo com
register e unregister:

- leve: apaga das cenas as propriedades que as versões até a 1.16 gravavam.
- modo_leve: o botão Modo leve, que desenha as nuvens sem efeito direto pela placa (desenho_na_placa) e reduz as com efeito
  por um modificador só da janela (reducao), malha com o Pontos da nuvem ou nuvem de pontos nativa (pontos_da_peca).
- pecas_leves: as versões leves das peças, que o Modo leve vincula no lugar das completas; o arquivo é salvo apontando para elas.
- leves_locais: as versões leves que o próprio complemento grava, à parte e em segundo plano, para as peças sem a leve na
  biblioteca (gerar_leve).
- selecao_na_placa: o clique que seleciona a peça desenhada pela placa, com o Modo leve ligado.
- no_visor: as peças do Modo leve também no visor da Sala imersiva, quando ele está ligado.
- opcoes: as escolhas do Modo leve, guardadas nas cenas do arquivo.

Uma parte nova (por exemplo a trava das tomadas no Gitea) entra como outro módulo nesta lista.
"""
from . import (
    leve,
    leves_locais,
    modo_leve,
    no_visor,
    opcoes,
    pecas_leves,
    selecao_na_placa,
)

PARTES = (leve, leves_locais, pecas_leves, modo_leve, selecao_na_placa, no_visor)


def register() -> None:
    for parte in PARTES:
        parte.register()
    opcoes.registrar(modo_leve.definicoes(None, None))


def unregister() -> None:
    opcoes.desregistrar()
    for parte in reversed(PARTES):
        parte.unregister()
