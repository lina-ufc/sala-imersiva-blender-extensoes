"""Modo leve: as nuvens desenhadas direto pela placa de vídeo, só na janela.

O botão *Modo leve* (cabeçalho da 3D View e aba Sala, desligado ao começar) troca o jeito de desenhar: as peças sem efeito
vão pela placa (`desenho_na_placa.py`), e as com efeito, por uma cópia reduzida (`copia_reduzida.py`), com a parte dos pontos
que a mesma *Densidade* pede para ela. Desligado, a janela mostra tudo como no render. O botão e os controles ficam no Window Manager, e a escolha
do artista vai também para o `.blend` (`opcoes.py`): ao abrir o arquivo, o Modo leve religa se estava ligado. O que o
complemento muda nas peças não vai: é devolvido antes de salvar. O render (F12, `render.py`, Renderizar a fita) nunca muda:
lá só vale o Geometry Nodes, com todos os efeitos.

Uma peça é uma malha com o modificador "Pontos da nuvem" (a antiga) ou uma nuvem de pontos nativa com o atributo da cor
(`pontos_da_peca.py`, desde a 1.18.0), e é classificada:
- sem efeito (só o "Pontos da nuvem" ligado na janela, ou a nativa sem modificador ligado): vai para a placa, depois de
  enviada;
- com efeito (outro modificador ligado na janela; na nativa, qualquer um): liberada ou local, é desenhada por uma cópia
  reduzida, só da sessão (`copia_reduzida.py`), com todos os modificadores desligados na janela e a caixa no lugar. A parte
  dos pontos da cópia é a que a *Densidade* pede para a distância do olho mais perto à caixa da peça, como na placa, subida ao
  degrau seguinte de `degraus_da_copia` (a cópia só é refeita quando o degrau muda; a velha fica até a nova estar pronta).
  Enquanto a amostra é preparada, selecionada (pela caixa ou pelo Outliner), só vinculada ou no último degrau (perto, com
  *Pontos de perto* em 100%), fica inteira no Geometry Nodes. Quando os efeitos da biblioteca chegarem à placa (`efeitos_na_placa.efeitos_da_peca`), é aqui, em
  `_efeitos_ligados`, que a peça com só esses efeitos passa a ir;
- em modo de edição, escondida pelo artista ou mexida à mão: fica no Geometry Nodes.

Tirar a peça do desenho do Blender depende de ela ser editável. Liberada (Library Override) ou local: `show_viewport` do
"Pontos da nuvem" desligado (a nativa não o tem) e `display_type = 'BOUNDS'`; ela continua selecionável e se move como sempre. Só vinculada: o
Blender não deixa mexer no modificador, então o olho dela fecha (`hide_set`). O complemento guarda só o que mudou. Se o
artista mexer à mão no olho, no modificador ou no jeito de mostrar a peça, ela sai do cuidado do Modo leve até o botão ser
desligado e ligado de novo.

A peça só vinculada selecionada por clique (`selecao_na_placa`) volta ao Geometry Nodes enquanto estiver selecionada: a seleção
abre o olho dela e a declara em `devolvidas_ao_geometry_nodes()`; aqui ela deixa de ser "mexida à mão" e de ir à placa (motivo
`selecionada`), e ao perder a seleção volta à placa e o olho fecha de novo. Só este módulo fecha o olho. Enquanto o Geometry
Nodes a desenha, ela segue numerada na textura da seleção (`Entrada.so_na_selecao`), para o clique achá-la e não a peça atrás.

O que muda nas peças é devolvido antes de salvar (`save_pre`) e refeito depois (`save_post`), ao desligar e ao descarregar o
complemento; as cópias reduzidas saem junto e voltam depois, da amostra guardada na memória. Devolver é campo por campo (`marca_do_modo_leve`): só volta o campo que ainda está como o Modo leve o deixou, e
o que o artista mudou depois fica. A peça que deixa de parecer aplicada (o artista mudou o *Display As*, um desfazer) tem
devolvido na hora o que ainda é do Modo leve, antes de sair do cuidado dele. O salvamento automático não chama `save_pre` e
grava as peças aplicadas: por isso cada peça aplicada tem uma marca na camada de vista, que vai junto para o arquivo, e ao
abrir um arquivo (`load_post`), nesta sessão ou numa nova, as peças marcadas voltam ao que eram. Depois de desfazer ou
refazer (`undo_post`, `redo_post`) as referências aos objetos morrem: os objetos são buscados de novo, e o que o desfazer
voltou é aplicado outra vez, senão a peça sairia duas vezes; as cópias que o desfazer trouxe ou levou são acertadas por
`copia_reduzida.sincronizar`, que deixa uma por peça.

Um erro na classificação ou na carga (`reclassificar` e o timer `_carregar_uma`) vai ao console e ao painel e não para o
timer: se é de uma peça, ela fica no Geometry Nodes com o erro como motivo até o Modo leve ser religado; senão, o painel o
mostra numa linha própria.
"""
import traceback
from collections.abc import Callable
from dataclasses import dataclass

import blf
import bpy
import gpu
import numpy as np
from gpu_extras.batch import batch_for_shader

from . import (
    ao_vivo,
    campo_de_visao,
    copia_reduzida,
    desenho_na_placa,
    leve,
    marca_do_modo_leve,
    opcoes,
    pontos_da_peca,
    selecao_na_placa,
)
from .desenho_na_placa import Entrada
from .marca_do_modo_leve import Agora, Devolucao, Marca
from .opcoes import Propriedade

PLACA = desenho_na_placa.PLACA
PROPRIEDADE_DO_BOTAO = desenho_na_placa.PROPRIEDADE_DO_BOTAO
CONTROLES = (desenho_na_placa.PROPRIEDADE_DA_ESCALA, desenho_na_placa.PROPRIEDADE_DA_LUZ, desenho_na_placa.PROPRIEDADE_DA_CHEIA,
             desenho_na_placa.PROPRIEDADE_DA_PARTE_MINIMA, desenho_na_placa.PROPRIEDADE_DA_PARTE_PERTO)
RAIO_EM_M_POR_CM_DE_DIAMETRO = 1 / 200   # o Tamanho do ponto (cm) da peça antiga é o diâmetro


@dataclass
class Peca:
    """O que o Modo leve sabe de uma peça."""
    nome: str                       # name_full do objeto
    objeto: bpy.types.Object
    modo: str                       # "override" (editável: local ou liberada) ou "vinculada"
    aplicado: bool = False          # o complemento tirou a peça do desenho do Blender
    do_artista: bool = False        # o artista mexeu à mão depois: fora do cuidado até religar
    marca: Marca | None = None      # os valores de antes de aplicar
    destino: str = "gn"             # "placa" ou "gn"
    motivo: str = "carregando"      # chave de PLACA.motivos
    detalhe: str = ""               # o modificador do efeito ou o erro
    visivel: bool = True
    raio_m: float = 0.0             # o raio do ponto, nas coordenadas da peça
    fracao: float = 1.0             # o Pontos no render (%) da peça antiga; 1 na nativa
    parte_da_copia: float = 1.0     # o degrau da cópia reduzida que a peça com efeito pediu por último


@dataclass
class _Estado:
    ligado: bool = False
    pecas: dict[str, Peca] = None   # type: ignore[assignment]
    ocupado: bool = False
    com_handlers: bool = False
    desligando: bool = False        # o botão foi desligado e as peças voltam ao Geometry Nodes uma por vez
    progresso: float = 1.0          # a parte dos pontos que a vista pede e já está na placa (ver `_medir_o_progresso`)
    feitas: int = 0                 # ao desligar: as peças já devolvidas e o total
    total: int = 0
    em_curso: str | None = None     # a peça que a classificação ou a carga está tratando, para o erro ir a ela
    erros: dict[str, str] = None    # type: ignore[assignment]  # peça -> erro da classificação ou da carga
    erro_geral: str = ""            # o último erro que não é de uma peça
    refazer: bool = False           # um erro tirou uma peça: a próxima volta do timer classifica de novo


_M = _Estado(pecas={}, erros={})
# O "Outline Selected" de cada 3D View, como o artista o deixou, enquanto o complemento o desliga (ver `_contorno_do_blender`).
_contorno_guardado: dict[int, bool] = {}
_identificadores: dict[str, dict[str, str]] = {}   # grupo de nós -> nome da entrada -> identificador no modificador
_desenhos: list[tuple[type, object]] = []


# ---- o que é uma peça ----

def _modificador_dos_pontos(objeto: bpy.types.Object) -> bpy.types.NodesModifier | None:
    """O "Pontos da nuvem" da peça antiga; None na nativa e em qualquer objeto que não seja malha."""
    if objeto.type != "MESH":
        return None
    for modificador in objeto.modifiers:
        if modificador.type == "NODES" and modificador.node_group is not None \
                and modificador.node_group.name.startswith(PLACA.nome_do_grupo):
            return modificador
    return None


def _entrada(modificador: bpy.types.NodesModifier, nome: str) -> float | None:
    """O valor de uma entrada do modificador pelo nome que o artista vê; None se o grupo não tem a entrada (peça de antes)."""
    grupo = modificador.node_group
    tabela = _identificadores.get(grupo.name_full)
    if tabela is None:
        tabela = _identificadores[grupo.name_full] = {
            i.name: i.identifier for i in grupo.interface.items_tree if i.item_type == "SOCKET" and i.in_out == "INPUT"}
    identificador = tabela.get(nome)
    if identificador is None:
        return None
    entrada = getattr(modificador.properties.inputs, identificador, None)
    return None if entrada is None else float(entrada.value)


def _e_peca(objeto: bpy.types.Object) -> bool:
    return _modificador_dos_pontos(objeto) is not None or pontos_da_peca.e_nativa(objeto)


def _efeitos_ligados(objeto: bpy.types.Object, dos_pontos: bpy.types.Modifier | None) -> tuple[str, ...]:
    """Os nomes dos modificadores, além do "Pontos da nuvem" (na nativa, todos), ligados na janela; vazio se a peça não tem
    efeito. Os efeitos
    da biblioteca ainda não vão pela placa: quando forem, `efeitos_na_placa.efeitos_da_peca(objeto)` (hoje levanta
    NotImplementedError) decide aqui quais a placa faz, e só os outros contam."""
    return tuple(m.name for m in objeto.modifiers if m != dos_pontos and m.show_viewport)


def _colecoes_escondidas(camada: bpy.types.ViewLayer) -> set[str]:
    """Os nomes das coleções que o olho ou a tela da coleção escondem na janela, herdado pelas filhas."""
    escondidas: set[str] = set()

    def descer(no: bpy.types.LayerCollection, pai_escondido: bool) -> None:
        escondida = pai_escondido or no.hide_viewport or no.collection.hide_viewport
        if escondida:
            escondidas.add(no.collection.name_full)
        for filho in no.children:
            descer(filho, escondida)

    descer(camada.layer_collection, False)
    return escondidas


def _aparece(objeto: bpy.types.Object, peca: Peca | None, escondidas: set[str]) -> bool:
    """Se o artista veria a peça na janela. A peça vinculada que o complemento escondeu não pode perguntar ao Blender."""
    if peca is not None and peca.aplicado and peca.modo == "vinculada":
        return not objeto.hide_viewport and any(c.name_full not in escondidas for c in objeto.users_collection)
    return objeto.visible_get()


# ---- tirar e devolver a peça ----

def _agora(objeto: bpy.types.Object, camada: bpy.types.ViewLayer | None = None) -> Agora:
    """Os campos que o Modo leve muda, como a peça está; o olho, na `camada` (sem ela, na camada de vista aberta)."""
    modificador = _modificador_dos_pontos(objeto)
    return Agora(None if modificador is None else modificador.show_viewport, objeto.display_type, objeto.hide_get(view_layer=camada),
                 {m.name: m.show_viewport for m in objeto.modifiers if m != modificador})


def _por(objeto: bpy.types.Object, devolucao: Devolucao, camada: bpy.types.ViewLayer | None = None) -> None:
    if devolucao.oculto is not None:
        objeto.hide_set(devolucao.oculto, view_layer=camada)
    modificador = _modificador_dos_pontos(objeto)
    if devolucao.modificador is not None and modificador is not None:
        modificador.show_viewport = devolucao.modificador
    if devolucao.display is not None:
        objeto.display_type = devolucao.display
    for nome in devolucao.religar:
        objeto.modifiers[nome].show_viewport = True


def _parece_aplicado(peca: Peca) -> bool:
    return marca_do_modo_leve.parece_aplicada(_marca_de(peca), _agora(peca.objeto))


def _marca_de(peca: Peca) -> Marca:
    """A peça aplicada sem marca na memória (o Modo leve foi religado e um desfazer voltou a peça aplicada, sem marca na
    camada) volta aos valores de partida da Marca, como antes da 1.11.3."""
    return peca.marca if peca.marca is not None else Marca(peca.modo)


# ---- as marcas na camada de vista, que vão para o arquivo ----

def _camadas_do_arquivo() -> list[bpy.types.ViewLayer]:
    return [camada for cena in bpy.data.scenes if cena.library is None for camada in cena.view_layers]


def _marcas(camada: bpy.types.ViewLayer) -> dict[str, Marca]:
    return marca_do_modo_leve.ler(camada.get(marca_do_modo_leve.PROPRIEDADE))


def _gravar_as_marcas(camada: bpy.types.ViewLayer, marcas: dict[str, Marca]) -> None:
    if marcas:
        camada[marca_do_modo_leve.PROPRIEDADE] = marca_do_modo_leve.escrever(marcas)
    elif camada.get(marca_do_modo_leve.PROPRIEDADE) is not None:
        del camada[marca_do_modo_leve.PROPRIEDADE]


def _marcar(nome: str, marca: Marca) -> None:
    camada = bpy.context.view_layer
    marcas = _marcas(camada)
    marcas[nome] = marca
    _gravar_as_marcas(camada, marcas)


def _desmarcar(nome: str) -> None:
    for camada in _camadas_do_arquivo():
        marcas = _marcas(camada)
        if marcas.pop(nome, None) is not None:
            _gravar_as_marcas(camada, marcas)


def _devolver_pelas_marcas() -> None:
    """Devolve, campo por campo, as peças marcadas em cada camada de vista do arquivo e apaga as marcas. É o que faz voltar
    as peças de um arquivo gravado com elas aplicadas (salvamento automático), mesmo numa sessão nova, e o que sobra de
    marca de peça que o Modo leve não acompanha mais (apagada ou renomeada: a marca é pelo nome e fica sem objeto)."""
    objetos = _objetos_pelo_nome()
    for camada in _camadas_do_arquivo():
        for nome, marca in _marcas(camada).items():
            objeto = objetos.get(nome)
            if objeto is not None:
                _por(objeto, marca_do_modo_leve.o_que_devolver(marca, _agora(objeto, camada)), camada)
        _gravar_as_marcas(camada, {})


# ---- tirar e devolver a peça ----

def _aplicar(peca: Peca, modificador: bpy.types.Modifier | None, efeitos: tuple[str, ...] = ()) -> None:
    """Tira a peça do desenho do Blender. Os `efeitos` (peça em cópia reduzida) são desligados na janela junto com o
    "Pontos da nuvem" (a nativa não o tem: só a caixa a tira)."""
    if peca.aplicado:
        return
    objeto = peca.objeto
    if peca.modo == "override":
        peca.marca = Marca("override", modificador=None if modificador is None else modificador.show_viewport,
                           display=objeto.display_type, desligados=efeitos)
        if modificador is not None:
            modificador.show_viewport = False
        for nome in efeitos:
            objeto.modifiers[nome].show_viewport = False
        objeto.display_type = marca_do_modo_leve.CAIXA
    else:
        peca.marca = Marca("vinculada", oculto=objeto.hide_get())
        objeto.hide_set(True)
    _marcar(peca.nome, peca.marca)
    peca.aplicado = True


def _devolver(peca: Peca) -> None:
    """Volta ao valor de antes cada campo que ainda está como o Modo leve o deixou; o que o artista mudou depois fica. A cópia
    reduzida da peça, se houver, sai."""
    if not peca.aplicado:
        return
    peca.aplicado = False
    copia_reduzida.tirar(peca.nome)
    _desmarcar(peca.nome)
    try:
        objeto = peca.objeto
        _por(objeto, marca_do_modo_leve.o_que_devolver(_marca_de(peca), _agora(objeto)))
    except ReferenceError:
        return   # o objeto foi apagado: não há o que devolver


def _devolver_tudo() -> None:
    for peca in _M.pecas.values():
        _devolver(peca)
    copia_reduzida.apagar_copias()
    _devolver_pelas_marcas()
    _contorno_do_blender(False)


def _contorno_do_blender(desligar: bool) -> None:
    """Enquanto o Geometry Nodes desenha uma peça selecionada, o contorno de seleção do Blender (*Overlay > Outline Selected*)
    contorna cada ponto dela e a pinta toda de laranja, escondendo a nuvem; o contorno do Modo leve (`desenho_na_placa`) o
    substitui. Desligado, cada 3D View volta ao valor que o artista tinha."""
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type != "VIEW_3D":
                continue
            overlay = area.spaces.active.overlay
            chave = area.spaces.active.as_pointer()
            if desligar and chave not in _contorno_guardado:
                _contorno_guardado[chave] = overlay.show_outline_selected
                overlay.show_outline_selected = False
            elif not desligar and chave in _contorno_guardado:
                overlay.show_outline_selected = _contorno_guardado.pop(chave)
    if not desligar:
        _contorno_guardado.clear()


# ---- a classificação ----

def _modo_de_edicao(objeto: bpy.types.Object) -> str:
    if objeto.library is not None and (objeto.override_library is None or objeto.override_library.is_system_override):
        return "vinculada"
    return "override"


def _decidir(peca: Peca, modificador: bpy.types.Modifier | None, escondidas: set[str], olhos: list[np.ndarray]) -> None:
    objeto = peca.objeto

    def fica_no_gn(motivo: str, detalhe: str = "") -> None:
        _devolver(peca)
        peca.destino, peca.motivo, peca.detalhe = "gn", motivo, detalhe

    erro = _M.erros.get(peca.nome)
    if erro is not None:
        fica_no_gn("erro", erro)
        return

    if peca.nome in selecao_na_placa.devolvidas_ao_geometry_nodes():
        # O olho foi aberto pela seleção, não pelo artista: o Geometry Nodes desenha a peça até ela perder a seleção.
        peca.aplicado, peca.do_artista = False, False
        peca.destino, peca.motivo, peca.detalhe, peca.visivel = "gn", "selecionada", "", True
        return
    if peca.do_artista:
        peca.destino, peca.motivo, peca.visivel = "gn", "mexida", False
        return
    if peca.aplicado and not _parece_aplicado(peca):
        _devolver(peca)   # o campo que o artista não mudou ainda é do Modo leve: volta antes de a peça sair do cuidado dele
        peca.do_artista = True
        peca.destino, peca.motivo, peca.visivel = "gn", "mexida", False
        return
    peca.visivel = _aparece(objeto, peca, escondidas)
    if not peca.visivel:
        if not peca.aplicado:
            peca.destino, peca.motivo = "gn", "oculta"
        return
    if objeto.mode == "EDIT":
        desenho_na_placa.liberar(peca.nome)
        copia_reduzida.esquecer(peca.nome)   # a malha pode mudar: a amostra é feita de novo
        peca.detalhe = ""
        fica_no_gn("editando")
        return
    efeitos = _efeitos_ligados(objeto, modificador)
    if peca.aplicado and efeitos:
        _devolver(peca)   # um efeito foi ligado com a peça aplicada (na placa ou em cópia): ela volta e é decidida de novo
    elif peca.aplicado and _marca_de(peca).desligados:
        efeitos = _marca_de(peca).desligados   # em cópia reduzida: os efeitos estão desligados pelo Modo leve
    if efeitos:
        _decidir_com_efeito(peca, modificador, efeitos, olhos)
        return
    if modificador is None:
        raio = desenho_na_placa.raio_da_peca(peca.nome)   # a nativa: conhecido depois de preparada
        peca.raio_m, peca.fracao = (0.0 if raio is None else raio), 1.0
    else:
        if not modificador.show_viewport and not peca.aplicado:
            fica_no_gn("modificador_desligado")
            return
        tamanho = _entrada(modificador, PLACA.entrada_do_tamanho)
        if tamanho is None:
            fica_no_gn("sem_tamanho")
            return
        peca.raio_m = tamanho * RAIO_EM_M_POR_CM_DE_DIAMETRO
        fracao = _entrada(modificador, PLACA.entrada_dos_pontos)
        peca.fracao = 1.0 if fracao is None else max(0.0, min(fracao, 100.0)) / 100
    if peca.motivo in ("erro", "sem_espaco") and not desenho_na_placa.carregada(peca.nome, objeto):
        fica_no_gn(peca.motivo, peca.detalhe)
        return
    if desenho_na_placa.carregada(peca.nome, objeto):
        _aplicar(peca, modificador)
        peca.destino, peca.motivo, peca.detalhe = "placa", "placa", ""
        return
    fica_no_gn("carregando")


def _parte_da_copia(peca: Peca, olhos: list[np.ndarray]) -> float:
    """O degrau da cópia reduzida da peça com efeito: a parte que a Densidade pede para o olho mais perto da caixa dos pontos
    da peça (sem o efeito, que mudaria a caixa a cada quadro), adiantada como em `_pontos_pedidos`, subida ao degrau seguinte
    de `degraus_da_copia`. Sem olho, a de perto."""
    pd = PLACA.pela_distancia
    perto = 0.0
    if olhos:
        minimo, maximo = copia_reduzida.caixa(peca.nome, peca.objeto)
        cantos = campo_de_visao.cantos_da_caixa(minimo, maximo, np.asarray(peca.objeto.matrix_world, np.float64))
        perto = min(campo_de_visao.distancia_ate_a_caixa(o, cantos) for o in olhos) * pd.antecipacao
    parte = campo_de_visao.parte_pela_distancia(perto, *desenho_na_placa.pela_distancia())
    return campo_de_visao.degrau_acima(parte, pd.degraus_da_copia)


def _decidir_com_efeito(peca: Peca, modificador: bpy.types.Modifier | None, efeitos: tuple[str, ...],
                        olhos: list[np.ndarray]) -> None:
    """A peça com efeito: cópia reduzida, se ela é editável, não está selecionada e o degrau dela tira algum ponto; senão,
    inteira no Geometry Nodes. A amostra fica na memória no último degrau, para a peça voltar à cópia sem refazê-la."""
    objeto = peca.objeto

    def fica_no_gn(motivo: str, detalhe: str = efeitos[0]) -> None:
        _devolver(peca)
        peca.destino, peca.motivo, peca.detalhe = "gn", motivo, detalhe

    if peca.modo == "vinculada":
        fica_no_gn("efeito_vinculada")
        return
    fracao = peca.parte_da_copia = _parte_da_copia(peca, olhos)
    if fracao >= 1:
        fica_no_gn("efeito")
        return
    if objeto.select_get():
        fica_no_gn("efeito_selecionada")
        return
    copia_reduzida.pedir(peca.nome, objeto, fracao)
    erro = copia_reduzida.erro(peca.nome)
    if erro is not None:
        fica_no_gn("erro", erro)
        return
    if copia_reduzida.amostra(peca.nome, objeto) is None:
        fica_no_gn("preparando_copia")
        return
    _aplicar(peca, modificador, efeitos)
    peca.destino, peca.motivo, peca.detalhe = "gn", "copia", efeitos[0]


def _pedido_de_copia(peca: Peca) -> copia_reduzida.Pedido:
    """A cópia liga o que a peça tinha ligado antes de o Modo leve desligar e mostra a peça como ela era."""
    marca = _marca_de(peca)
    dos_pontos = _modificador_dos_pontos(peca.objeto)
    ligar = set(marca.desligados) | ({dos_pontos.name} if dos_pontos is not None and marca.modificador else set())
    return copia_reduzida.Pedido(peca.objeto, frozenset(ligar), marca.display)


def _passo() -> None:
    camada = bpy.context.view_layer
    selecao_na_placa.conferir_devolvidas()
    escondidas = _colecoes_escondidas(camada)
    olhos = _olhos()
    vistos: set[str] = set()
    luzes: list[bpy.types.Object] = []
    # Lista à parte, sem as cópias: decidir uma peça pode apagar a cópia dela, que está na mesma camada de vista.
    for objeto in [o for o in camada.objects if not copia_reduzida.e_copia(o)]:
        if objeto.type == "LIGHT":
            if objeto.visible_get():
                luzes.append(objeto)
            continue
        if not _e_peca(objeto):
            continue
        modificador = _modificador_dos_pontos(objeto)
        nome = objeto.name_full
        vistos.add(nome)
        peca = _M.pecas.get(nome)
        if peca is None:
            peca = _M.pecas[nome] = Peca(nome, objeto, _modo_de_edicao(objeto))
        peca.objeto = objeto
        _M.em_curso = nome
        _decidir(peca, modificador, escondidas, olhos)
    _M.em_curso = None
    _contorno_do_blender(any(p.motivo == "selecionada" for p in _M.pecas.values()))
    for nome in [n for n in _M.pecas if n not in vistos]:
        peca = _M.pecas[nome]
        try:
            peca.objeto.name   # noqa: B018  (só para saber se o objeto ainda existe)
        except ReferenceError:
            desenho_na_placa.liberar(nome)
            del _M.pecas[nome]
            continue
        peca.visivel = False   # fora da camada de vista: o que foi aplicado fica como está
    copia_reduzida.sincronizar({p.nome: _pedido_de_copia(p) for p in _M.pecas.values()
                                if p.motivo == "copia" and p.aplicado and p.visivel})
    entradas = [Entrada(p.nome, p.objeto, p.raio_m, p.fracao, p.visivel) for p in _M.pecas.values()
                if p.destino == "placa" and p.aplicado]
    entradas += [Entrada(p.nome, p.objeto, p.raio_m, p.fracao, True, so_na_selecao=True) for p in _M.pecas.values()
                 if p.motivo == "selecionada" and desenho_na_placa.carregada(p.nome, p.objeto)]
    desenho_na_placa.definir_a_cena(entradas, luzes, desenho_na_placa.ambiente_da_cena(bpy.context.scene))


def reclassificar() -> None:
    """Classifica de novo as peças e entrega ao desenho as que vão pela placa. Sem efeito com o Modo leve desligado. Um erro
    vai ao console e ao painel (`_registrar_o_erro`)."""
    if not _M.ligado or _M.ocupado or _M.desligando:
        return
    _M.ocupado = True
    try:
        _passo()
    except Exception as erro:   # noqa: BLE001  (vai ao console e ao painel; o handler e o timer seguem vivos)
        _registrar_o_erro(erro)
    finally:
        _M.ocupado = False
        _M.em_curso = None


def _registrar_o_erro(erro: Exception) -> None:
    """Imprime o erro no console e o põe no painel: na peça que estava sendo tratada, que fica no Geometry Nodes com ele até o
    Modo leve ser religado (a próxima volta do timer a classifica de novo), ou numa linha própria, se não é de uma peça."""
    traceback.print_exception(erro)
    texto = f"{type(erro).__name__}: {erro}"
    nome = erro.nome if isinstance(erro, copia_reduzida.ErroNaCopia) else _M.em_curso
    if nome is not None and nome in _M.pecas:
        _M.erros[nome] = texto
        peca = _M.pecas[nome]
        peca.destino, peca.motivo, peca.detalhe = "gn", "erro", texto
        _M.refazer = True
    else:
        _M.erro_geral = texto
    _redesenhar()


def estado_das_pecas() -> list[tuple[str, str]]:
    """(nome, estado em palavras) de cada peça, em ordem de nome."""
    resultado = []
    for nome in sorted(_M.pecas):
        peca = _M.pecas[nome]
        texto = PLACA.motivos[peca.motivo]
        resultado.append((nome, texto.format(modificador=peca.detalhe, erro=peca.detalhe)))
    return resultado


# ---- carregar as peças na placa, uma por vez ----

def _olhos() -> list[np.ndarray]:
    """De onde se olha: o olho de cada 3D View aberta e a câmera da cena (o visor desenha de perto dela)."""
    olhos: list[np.ndarray] = []
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type != "VIEW_3D":
                continue
            espaco = area.spaces.active
            for regiao in (espaco.region_3d, *espaco.region_quadviews):
                olhos.append(np.asarray(regiao.view_matrix.inverted().translation, np.float64))
    camera = bpy.context.scene.camera
    if camera is not None:
        olhos.append(np.asarray(camera.matrix_world.translation, np.float64))
    return olhos


def _pontos_pedidos(peca: Peca, olhos: list[np.ndarray]) -> int:
    """Quantos pontos a peça precisa na placa para o olho mais perto dela, adiantados: a parte que a distância até a caixa
    dela pediria a `antecipacao` vezes essa distância."""
    pd = PLACA.pela_distancia
    caixa = desenho_na_placa.caixa_carregada(peca.nome)
    if caixa is None or not olhos:
        return 0
    cantos = campo_de_visao.cantos_da_caixa(caixa[0], caixa[1], np.asarray(peca.objeto.matrix_world, np.float64))
    perto = min(campo_de_visao.distancia_ate_a_caixa(o, cantos) for o in olhos) * pd.antecipacao
    parte = campo_de_visao.parte_pela_distancia(perto, *desenho_na_placa.pela_distancia()) * peca.fracao
    return max(desenho_na_placa.pontos_pedidos(peca.nome, parte), 1)


def _carregar_uma() -> float | None:
    """Um passo do envio à placa, a cada `intervalo_da_carga_s`, e a medida do progresso, que o selo e o painel mostram. O
    erro vai ao console e ao painel e não derruba o timer (o Blender tira o timer que levanta exceção)."""
    if not _M.ligado or _M.desligando:
        return None
    try:
        _uma_volta_da_carga()
    except Exception as erro:   # noqa: BLE001  (vai ao console e ao painel; o timer segue)
        _registrar_o_erro(erro)
    finally:
        _M.em_curso = None
    return PLACA.intervalo_da_carga_s


def _uma_volta_da_carga() -> None:
    olhos = _olhos()
    if _M.refazer or copia_reduzida.passo() or _degrau_mudou(olhos):
        _M.refazer = False
        reclassificar()
    mudou = _passo_da_carga()
    progresso = _medir_o_progresso(olhos)
    if mudou or progresso != _M.progresso:
        _M.progresso = progresso
        _redesenhar()


def _degrau_mudou(olhos: list[np.ndarray]) -> bool:
    """Se o olho andou e alguma peça com efeito pede outro degrau da cópia reduzida. Mexer a vista não avisa o Blender, então
    o timer confere."""
    for peca in _M.pecas.values():
        if peca.motivo not in ("copia", "preparando_copia", "efeito") or not peca.visivel:
            continue
        _M.em_curso = peca.nome
        if _parte_da_copia(peca, olhos) != peca.parte_da_copia:
            return True
    _M.em_curso = None
    return False


def _medir_o_progresso(olhos: list[np.ndarray]) -> float:
    """A parte dos pontos que a vista pede e já está na placa, na média das peças que vão a ela; a peça ainda em preparo conta
    zero. Volta a cair quando a vista se aproxima e pede mais pontos."""
    partes: list[float] = []
    for peca in _M.pecas.values():
        if not peca.visivel or (peca.destino != "placa" and peca.motivo != "carregando"):
            continue
        if not desenho_na_placa.preparada(peca.nome, peca.objeto):
            partes.append(0.0)
            continue
        partes.append(min(1.0, desenho_na_placa.pontos_enviados(peca.nome) / _pontos_pedidos(peca, olhos)))
    return sum(partes) / len(partes) if partes else 1.0


def _passo_da_carga() -> bool:
    """Recolhe as peças preparadas em segundo plano, começa o preparo de uma peça nova (ler a malha é o único passo pesado na
    linha principal, uma vez por peça) ou manda um pedaço da peça que mais precisa de pontos. Diz se algo mudou na placa."""
    mudou = False
    desenho_na_placa.dar_vez_ao_preparo()
    for nome, erro in desenho_na_placa.recolher():
        peca = _M.pecas.get(nome)
        if peca is not None and erro is not None:
            print("".join(traceback.format_exception(erro)))
            peca.motivo, peca.detalhe = "erro", f"{type(erro).__name__}: {erro}"
            mudou = True
        if peca is not None:
            mudou = True
    alvo = next((p for p in _M.pecas.values() if p.motivo == "carregando" and p.destino == "gn" and p.visivel
                 and not desenho_na_placa.em_preparo(p.nome) and not desenho_na_placa.preparada(p.nome, p.objeto)), None)
    if alvo is not None:
        _M.em_curso = alvo.nome
        desenho_na_placa.preparar(alvo.nome, alvo.objeto)
        _M.em_curso = None
        reclassificar()
        return True
    olhos = _olhos()
    pedidos: dict[str, int] = {}
    faltas: list[tuple[float, Peca]] = []
    for peca in _M.pecas.values():
        if not peca.visivel or not desenho_na_placa.preparada(peca.nome, peca.objeto):
            continue
        if peca.destino != "placa" and peca.motivo != "carregando":
            continue
        pedido = pedidos[peca.nome] = _pontos_pedidos(peca, olhos)
        enviados = desenho_na_placa.pontos_enviados(peca.nome)
        if enviados < pedido:
            faltas.append(((pedido - enviados) / max(enviados, 1), peca))   # a que ainda não tem nada vem primeiro
    if faltas:
        _, peca = max(faltas, key=lambda t: t[0])
        _M.em_curso = peca.nome
        primeira = desenho_na_placa.pontos_enviados(peca.nome) == 0
        try:
            desenho_na_placa.enviar_um_pedaco(peca.nome, pedidos[peca.nome], pedidos)
            mudou = True
        except desenho_na_placa.SemEspaco:
            if primeira:
                peca.motivo, peca.detalhe = "sem_espaco", ""
        if primeira:
            reclassificar()
    return mudou


def _redesenhar() -> None:
    leve.redesenhar()
    ao_vivo.pedir()


# ---- handlers ----

@bpy.app.handlers.persistent
def _ao_mudar(_cena: bpy.types.Scene, _grafo: bpy.types.Depsgraph | None = None) -> None:
    reclassificar()


@bpy.app.handlers.persistent
def _ao_mudar_o_quadro(_cena: bpy.types.Scene, _grafo: object = None) -> None:
    reclassificar()


def _objetos_pelo_nome() -> dict[str, bpy.types.Object]:
    return {o.name_full: o for o in bpy.data.objects}


@bpy.app.handlers.persistent
def _depois_de_desfazer(_cena: bpy.types.Scene, _grafo: object = None) -> None:
    """As referências Python aos objetos morrem no desfazer e no refazer. Busca os objetos de novo e vê o que o desfazer
    deixou: a peça que voltou ao Geometry Nodes é aplicada de novo pela classificação. A que voltou com só parte do que o
    Modo leve muda (o artista mudou o resto antes do desfazer) tem devolvida essa parte e fica com o artista."""
    if not _M.ligado:
        return
    _identificadores.clear()
    objetos = _objetos_pelo_nome()
    guardadas = _marcas(bpy.context.view_layer)
    for nome in list(_M.pecas):
        peca = _M.pecas[nome]
        objeto = objetos.get(nome)
        if objeto is None or not _e_peca(objeto):
            desenho_na_placa.liberar(nome)
            del _M.pecas[nome]
            continue
        peca.objeto = objeto
        if _parece_aplicado(peca):
            peca.do_artista = False
            peca.aplicado = True
            peca.marca = guardadas.get(nome, _marca_de(peca))
            if nome not in guardadas:
                _marcar(nome, peca.marca)
            continue
        if peca.aplicado:
            if marca_do_modo_leve.o_que_devolver(_marca_de(peca), _agora(objeto)) != Devolucao():
                peca.do_artista = True
            _devolver(peca)
    reclassificar()


@bpy.app.handlers.persistent
def _antes_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    if _M.ligado:
        _devolver_tudo()   # com as marcas: o arquivo salvo não as leva


@bpy.app.handlers.persistent
def _depois_de_salvar(_arquivo: str, _grafo: object = None) -> None:
    reclassificar()


@bpy.app.handlers.persistent
def _ao_abrir(_arquivo: str, _grafo: object = None) -> None:
    """Os objetos do arquivo anterior morreram. As peças que o arquivo guarda aplicadas (salvamento automático), nesta sessão
    ou numa nova, voltam ao que eram pelas marcas da camada de vista. Um arquivo gravado aplicado antes das marcas (1.11.2)
    só volta se for desta sessão, pelo que a memória guarda das peças. Depois os controles voltam ao que o arquivo guarda (os
    valores de partida, num arquivo de antes) e o Modo leve recomeça do zero, se o arquivo o guarda ligado."""
    escolhas = opcoes.ler(bpy.context.scene, (PROPRIEDADE_DO_BOTAO, *CONTROLES))
    ligado = bool(escolhas.pop(PROPRIEDADE_DO_BOTAO))
    _contorno_guardado.clear()   # as 3D Views do arquivo anterior morreram; o arquivo novo traz o valor salvo
    copia_reduzida.apagar_restos()   # antes das marcas: as cópias têm os nomes das peças nelas
    _devolver_pelas_marcas()
    objetos = _objetos_pelo_nome()
    for peca in _M.pecas.values():
        objeto = objetos.get(peca.nome)
        if objeto is None:
            continue
        peca.objeto = objeto
        if peca.aplicado and _parece_aplicado(peca):
            _devolver(peca)
    _M.pecas.clear()
    _identificadores.clear()
    desenho_na_placa.liberar_tudo()
    selecao_na_placa.devolver_todas()
    _tirar_handlers()
    _M.ligado = _M.desligando = False
    gerenciador = bpy.context.window_manager
    for nome, valor in escolhas.items():
        if getattr(gerenciador, nome) != valor:
            setattr(gerenciador, nome, valor)
    if getattr(gerenciador, PROPRIEDADE_DO_BOTAO) != ligado:
        setattr(gerenciador, PROPRIEDADE_DO_BOTAO, ligado)   # o update liga ou só guarda o desligado
    elif ligado:
        _comecar()


HANDLERS_DA_JANELA = ((bpy.app.handlers.depsgraph_update_post, _ao_mudar), (bpy.app.handlers.frame_change_post, _ao_mudar_o_quadro),
                      (bpy.app.handlers.undo_post, _depois_de_desfazer), (bpy.app.handlers.redo_post, _depois_de_desfazer),
                      (bpy.app.handlers.save_pre, _antes_de_salvar), (bpy.app.handlers.save_post, _depois_de_salvar))


def _por_handlers() -> None:
    if _M.com_handlers:
        return
    for lista, funcao in HANDLERS_DA_JANELA:
        lista.append(funcao)
    _M.com_handlers = True


def _tirar_handlers() -> None:
    if not _M.com_handlers:
        return
    for lista, funcao in HANDLERS_DA_JANELA:
        if funcao in lista:
            lista.remove(funcao)
    _M.com_handlers = False
    if bpy.app.timers.is_registered(_carregar_uma):
        bpy.app.timers.unregister(_carregar_uma)


# ---- ligar e desligar ----

def _comecar() -> None:
    """Liga o Modo leve: as peças sem efeito vão para a placa, uma por vez, e saem do desenho do Blender."""
    _M.pecas.clear()
    _M.erros.clear()
    _M.erro_geral, _M.refazer = "", False
    _M.ligado = True
    _por_handlers()
    if not bpy.app.timers.is_registered(_carregar_uma):
        bpy.app.timers.register(_carregar_uma, first_interval=PLACA.intervalo_da_carga_s, persistent=True)
    reclassificar()
    _redesenhar()


def _parar() -> None:
    """Desliga de uma vez: devolve o que mudou nas peças e solta a placa. O botão desliga aos poucos (`_comecar_a_desligar`);
    este é o fim dele e o caminho de descarregar o complemento."""
    _devolver_tudo()
    copia_reduzida.esquecer_tudo()
    selecao_na_placa.devolver_todas()
    _M.pecas.clear()
    _M.erros.clear()
    _M.erro_geral, _M.refazer = "", False
    _M.ligado = False
    _M.desligando = False   # o `_devolver_uma` que ainda estiver registrado para sozinho
    _tirar_handlers()
    desenho_na_placa.liberar_tudo()
    _redesenhar()


def _comecar_a_desligar() -> None:
    """O botão desligado: as peças voltam ao Geometry Nodes uma por vez (`_devolver_uma`), porque devolver todas no mesmo
    instante faz o Blender calcular todas juntas e pode fechá-lo por falta de memória. Até voltar, cada peça segue pela placa;
    as que não estavam nela saem já. A carga para sozinha (`_carregar_uma` vê o `desligando`)."""
    _M.desligando = True
    for nome in [n for n, p in _M.pecas.items() if not p.aplicado]:
        desenho_na_placa.liberar(nome)
        del _M.pecas[nome]
    _M.feitas, _M.total = 0, len(_M.pecas)
    if not bpy.app.timers.is_registered(_devolver_uma):
        bpy.app.timers.register(_devolver_uma, first_interval=0.0, persistent=True)
    _redesenhar()


def _devolver_uma() -> float | None:
    """Devolve uma peça ao Geometry Nodes e solta os pedaços dela na placa; sem peça a devolver, termina de desligar."""
    if not _M.desligando:
        return None
    peca = next((p for p in _M.pecas.values() if p.aplicado), None)
    if peca is None:
        _parar()
        return None
    _devolver(peca)
    desenho_na_placa.liberar(peca.nome)
    del _M.pecas[peca.nome]
    _M.feitas += 1
    _redesenhar()
    return PLACA.intervalo_ao_desligar_s


def _retomar() -> None:
    """O botão ligado de novo antes de terminar de desligar: as peças que ainda estão na placa ficam, e as já devolvidas voltam
    a ser carregadas."""
    _M.desligando = False
    if not bpy.app.timers.is_registered(_carregar_uma):
        bpy.app.timers.register(_carregar_uma, first_interval=PLACA.intervalo_da_carga_s, persistent=True)
    reclassificar()
    _redesenhar()


def _ao_mudar_o_botao(gerenciador: bpy.types.WindowManager, _contexto: bpy.types.Context) -> None:
    opcoes.guardar(gerenciador, (PROPRIEDADE_DO_BOTAO,))
    ligado = bool(getattr(gerenciador, PROPRIEDADE_DO_BOTAO))
    if ligado and _M.desligando:
        _retomar()
    elif ligado and not _M.ligado:
        _comecar()
    elif not ligado and _M.ligado and not _M.desligando:
        _comecar_a_desligar()


def _ao_mudar_um_controle(gerenciador: bpy.types.WindowManager, _contexto: bpy.types.Context) -> None:
    opcoes.guardar(gerenciador, CONTROLES)
    _redesenhar()


# ---- a interface ----

def _desenhar_o_painel(layout: bpy.types.UILayout, contexto: bpy.types.Context, com_lista: bool) -> None:
    """O menu do cabeçalho mostra só o resumo; a aba Sala lista também as peças que ficaram no Geometry Nodes, com o motivo."""
    gerenciador = contexto.window_manager
    layout.prop(gerenciador, PROPRIEDADE_DO_BOTAO, toggle=True, icon="LIGHTPROBE_SPHERE" if _M.ligado else "POINTCLOUD_DATA")
    coluna = layout.column()
    coluna.prop(gerenciador, desenho_na_placa.PROPRIEDADE_DA_ESCALA)
    coluna.prop(gerenciador, desenho_na_placa.PROPRIEDADE_DA_LUZ)
    densidade = layout.column(align=True)
    densidade.label(text=PLACA.titulo_da_densidade)
    for nome in (desenho_na_placa.PROPRIEDADE_DA_PARTE_PERTO, desenho_na_placa.PROPRIEDADE_DA_CHEIA,
                 desenho_na_placa.PROPRIEDADE_DA_PARTE_MINIMA):
        densidade.prop(gerenciador, nome)
    caixa = layout.box().column(align=True)
    for linha in (PLACA.painel.aviso_do_modo, PLACA.painel.aviso_da_luz):
        _texto_em_linhas(caixa, linha)
    if not _M.ligado:
        return
    if _M.erro_geral:
        _texto_em_linhas(layout.box().column(align=True), PLACA.painel.erro_da_carga.format(erro=_M.erro_geral))
    estados = estado_das_pecas()
    carregando = sum(1 for p in _M.pecas.values() if p.motivo == "carregando" and p.visivel)
    if _M.desligando:
        layout.progress(factor=_M.feitas / max(_M.total, 1), type="BAR",
                        text=PLACA.painel.desligando.format(feitas=_M.feitas, total=_M.total))
    elif carregando or _M.progresso < 1:
        layout.progress(factor=_M.progresso, type="BAR", text=f"{PLACA.painel.carregando} {round(_M.progresso * 100)}%")
    motivos = [p.motivo for p in _M.pecas.values()]
    placa, copias, ocultas = motivos.count("placa"), motivos.count("copia"), motivos.count("oculta")
    contagens = layout.column(align=True)
    for texto, quantas in ((PLACA.painel.contagem_placa, placa), (PLACA.painel.contagem_copias, copias),
                           (PLACA.painel.contagem_gn, len(motivos) - placa - copias - ocultas),
                           (PLACA.painel.contagem_ocultas, ocultas)):
        contagens.label(text=texto.format(quantas=quantas))
    if not com_lista:
        return
    no_gn = [(nome, estado) for nome, estado in estados if estado not in (PLACA.motivos["placa"], PLACA.motivos["oculta"])]
    coluna = layout.column(align=True)
    for nome, estado in no_gn[:PLACA.painel.linhas_maximas]:
        coluna.label(text=nome.split(" [")[0], icon="DOT")
        _texto_em_linhas(coluna, estado)
    if len(no_gn) > PLACA.painel.linhas_maximas:
        coluna.label(text=f"… e mais {len(no_gn) - PLACA.painel.linhas_maximas}")


def _texto_em_linhas(layout: bpy.types.UILayout, texto: str) -> None:
    largura = PLACA.painel.largura_do_texto
    linha = ""
    for palavra in texto.split():
        if linha and len(linha) + 1 + len(palavra) > largura:
            layout.label(text=linha)
            linha = palavra
        else:
            linha = f"{linha} {palavra}".strip()
    if linha:
        layout.label(text=linha)


class SALA_PT_modo_leve(bpy.types.Panel):
    bl_label = PLACA.nome_do_botao
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Sala"
    bl_order = 0

    def draw(self, contexto: bpy.types.Context) -> None:
        _desenhar_o_painel(self.layout, contexto, com_lista=True)


class SALA_PT_modo_leve_menu(bpy.types.Panel):
    """O menu ao lado do botão no cabeçalho: os controles do Modo leve, sem a lista das peças."""
    bl_label = PLACA.nome_do_botao
    bl_space_type = "VIEW_3D"
    bl_region_type = "HEADER"

    def draw(self, contexto: bpy.types.Context) -> None:
        _desenhar_o_painel(self.layout, contexto, com_lista=False)


def _no_cabecalho(menu: bpy.types.Header, contexto: bpy.types.Context) -> None:
    linha = menu.layout.row(align=True)
    linha.prop(contexto.window_manager, PROPRIEDADE_DO_BOTAO, toggle=True, text=PLACA.nome_do_botao)
    linha.popover(panel=SALA_PT_modo_leve_menu.__name__, text="")


def _desenhar_o_selo() -> None:
    """O selo fixo no canto da 3D View enquanto o Modo leve está ligado. Enquanto faltam pontos para a vista, ou enquanto as
    peças voltam ao Geometry Nodes, diz isso e ganha uma barra de progresso na borda de baixo."""
    if not _M.ligado:
        return
    selo = PLACA.selo
    if _M.desligando:
        texto, barra = selo.texto_desligando.format(feitas=_M.feitas, total=_M.total), _M.feitas / max(_M.total, 1)
    elif _M.progresso < 1:
        texto, barra = selo.texto_carregando.format(porcentagem=round(_M.progresso * 100)), _M.progresso
    else:
        texto, barra = selo.texto, None
    blf.size(0, selo.tamanho_px)
    largura, altura = blf.dimensions(0, texto)
    x, y = selo.margem_px, selo.margem_px
    p = selo.preenchimento_px
    sombreador = gpu.shader.from_builtin("UNIFORM_COLOR")
    lote = batch_for_shader(sombreador, "TRI_FAN", {"pos": [(x - p, y - p), (x + largura + p, y - p), (x + largura + p, y + altura + p),
                                                          (x - p, y + altura + p)]})
    gpu.state.blend_set("ALPHA")
    sombreador.bind()
    sombreador.uniform_float("color", selo.cor_do_fundo)
    lote.draw(sombreador)
    if barra is not None:
        fim = x - p + (largura + 2 * p) * barra
        cheia = batch_for_shader(sombreador, "TRI_FAN", {"pos": [(x - p, y - p), (fim, y - p), (fim, y - p + selo.altura_da_barra_px),
                                                               (x - p, y - p + selo.altura_da_barra_px)]})
        sombreador.uniform_float("color", selo.cor_da_barra)
        cheia.draw(sombreador)
    blf.color(0, *selo.cor_do_texto)
    blf.position(0, x, y, 0)
    blf.draw(0, texto)
    gpu.state.blend_set("NONE")


def _desenhar_o_contorno() -> None:
    """No desenho 2D de cada 3D View: o contorno das peças selecionadas (da placa e do Geometry Nodes)."""
    if not _M.ligado:
        return
    regiao, dados = bpy.context.region, bpy.context.region_data
    if regiao is None or dados is None:
        return
    recorte = tuple(tuple(p) for p in dados.clip_planes) if dados.use_clip_planes else ()
    desenho_na_placa.desenhar_o_contorno(desenho_na_placa.Vista(dados.view_matrix.copy(), dados.window_matrix.copy(), regiao.width,
                                                                regiao.height, recorte))


def _desenhar_na_vista() -> None:
    """No desenho de cada 3D View: as peças da placa, com o recorte do Alt+B da vista."""
    if not _M.ligado:
        return
    regiao, dados = bpy.context.region, bpy.context.region_data
    if regiao is None or dados is None:
        return
    recorte = tuple(tuple(p) for p in dados.clip_planes) if dados.use_clip_planes else ()
    desenho_na_placa.desenhar(desenho_na_placa.Vista(dados.view_matrix.copy(), dados.window_matrix.copy(), regiao.width,
                                                     regiao.height, recorte))


CLASSES = (SALA_PT_modo_leve_menu,)


def registrar_o_painel_da_aba() -> None:
    """O painel da aba Sala é registrado antes dos outros painéis da aba (`__init__.py`): o Blender não ordena por `bl_order`
    abaixo de zero (um painel com -1 ficou depois dos de 0) e, entre painéis de mesma ordem, vale o registro."""
    bpy.utils.register_class(SALA_PT_modo_leve)


Mudanca = Callable[[bpy.types.WindowManager, bpy.types.Context], None] | None


def definicoes(ao_mudar_o_botao: Mudanca, ao_mudar_um_controle: Mudanca) -> dict[str, Propriedade]:
    """O botão e os controles do Modo leve, que o artista escolhe e o arquivo guarda, com nomes e partida do dados.json."""
    escala, pd = PLACA.escala_do_ponto, PLACA.pela_distancia
    return {
        PROPRIEDADE_DO_BOTAO: bpy.props.BoolProperty(name=PLACA.nome_do_botao, description=PLACA.descricao_do_botao,
                                                     default=False, update=ao_mudar_o_botao),
        desenho_na_placa.PROPRIEDADE_DA_ESCALA: bpy.props.FloatProperty(
            name=escala.nome, description=escala.descricao, default=escala.partida, min=escala.minimo, max=escala.maximo,
            update=ao_mudar_um_controle),
        desenho_na_placa.PROPRIEDADE_DA_LUZ: bpy.props.BoolProperty(
            name=PLACA.nome_da_luz, description=PLACA.descricao_da_luz, default=True, update=ao_mudar_um_controle),
        **{nome: bpy.props.FloatProperty(name=c.nome, description=c.descricao, default=c.partida, min=c.minimo, max=c.maximo,
                                         unit=unidade, update=ao_mudar_um_controle)
           for nome, c, unidade in ((desenho_na_placa.PROPRIEDADE_DA_PARTE_PERTO, pd.parte_perto, "NONE"),
                                    (desenho_na_placa.PROPRIEDADE_DA_CHEIA, pd.cheia_ate_m, "LENGTH"),
                                    (desenho_na_placa.PROPRIEDADE_DA_PARTE_MINIMA, pd.parte_minima, "NONE"))},
    }


def register() -> None:
    for classe in CLASSES:
        bpy.utils.register_class(classe)
    for nome, definicao in definicoes(_ao_mudar_o_botao, _ao_mudar_um_controle).items():
        setattr(bpy.types.WindowManager, nome, definicao)
    _desenhos.append((bpy.types.SpaceView3D, bpy.types.SpaceView3D.draw_handler_add(_desenhar_na_vista, (), "WINDOW", "POST_VIEW")))
    _desenhos.append((bpy.types.SpaceView3D, bpy.types.SpaceView3D.draw_handler_add(_desenhar_o_selo, (), "WINDOW", "POST_PIXEL")))
    _desenhos.append((bpy.types.SpaceView3D, bpy.types.SpaceView3D.draw_handler_add(_desenhar_o_contorno, (), "WINDOW", "POST_PIXEL")))
    bpy.app.handlers.load_post.append(_ao_abrir)
    bpy.types.VIEW3D_HT_header.append(_no_cabecalho)
    selecao_na_placa.ao_mudar_a_selecao = reclassificar


def unregister() -> None:
    selecao_na_placa.ao_mudar_a_selecao = None
    _parar()
    if _ao_abrir in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_ao_abrir)
    bpy.types.VIEW3D_HT_header.remove(_no_cabecalho)
    for espaco, desenho in _desenhos:
        espaco.draw_handler_remove(desenho, "WINDOW")
    _desenhos.clear()
    for nome in (PROPRIEDADE_DO_BOTAO, *CONTROLES):
        delattr(bpy.types.WindowManager, nome)
    for classe in reversed(CLASSES):
        bpy.utils.unregister_class(classe)
    bpy.utils.unregister_class(SALA_PT_modo_leve)
