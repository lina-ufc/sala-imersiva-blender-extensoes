"""Visor da sala: a fita das quatro paredes com o piso embaixo, como a projeção recebe.

Renderiza a cena pelas cinco câmeras da sala, com o motor e os ajustes de render da cena, numa fração da resolução, e
junta as imagens numa só, que se vê num Image Editor. As câmeras e o lugar de cada imagem na fita vêm das propriedades
gravadas nelas pelo sala-unity (resolução, recorte, espelhamento, anamorfose); os nomes e limites, de dados.json.

Na barra lateral da 3D View (N), aba "Sala": atualizar o visor, abrir a janela do visor, acompanhar o quadro, olhar por
uma superfície e olhar do ponto de vista (uma câmera no olho do público, com giro, inclinação e campo de visão).

Serve à sala vinculada direto na cena (as cenas prontas), à liberada com Library Override e à copiada pela Tomada
modelo. A sala que chegou como instância (um vazio que mostra a coleção) não serve: as câmeras dela não acompanham o
vazio, e o visor pede o Library Override.
"""
import math
import os
import tempfile

import bpy
import numpy as np

from . import dados

VISOR = dados.visor()


def _e_sala(objeto: bpy.types.Object) -> bool:
    return VISOR.propriedade_da_sala in objeto


def salas(cena: bpy.types.Scene) -> list[bpy.types.Object]:
    return [objeto for objeto in cena.objects if _e_sala(objeto)]


def instancias_de_sala(cena: bpy.types.Scene) -> list[bpy.types.Object]:
    return [objeto for objeto in cena.objects
            if objeto.instance_type == "COLLECTION" and objeto.instance_collection is not None
            and any(_e_sala(o) for o in objeto.instance_collection.all_objects)]


def sala_do_visor(cena: bpy.types.Scene) -> bpy.types.Object:
    escolhida = cena.visor_da_sala.sala
    if escolhida is not None:
        return escolhida
    encontradas = salas(cena)
    if len(encontradas) == 1:
        return encontradas[0]
    if encontradas:
        raise RuntimeError(f"A cena tem {len(encontradas)} salas: escolha uma em Sala do visor.")
    instancias = instancias_de_sala(cena)
    if instancias:
        raise RuntimeError(f'A sala "{instancias[0].name}" está como instância: selecione-a e use '
                           "Object > Library Override > Make, ou solte a sala de novo com o complemento ligado.")
    raise RuntimeError("A cena não tem sala: traga a Sala do Asset Browser (Comum > Sala).")


def cameras_da_sala(sala: bpy.types.Object) -> list[bpy.types.Object]:
    cameras = [filho for filho in sala.children if VISOR.propriedade_da_superficie in filho]
    if len(cameras) != 5:
        raise RuntimeError(f'A sala "{sala.name}" tem {len(cameras)} câmeras; esperadas 5 (quatro paredes e o piso).')
    return cameras


def por_camera(cena: bpy.types.Scene, camera: bpy.types.Object, escala: float) -> None:
    cena.camera = camera
    cena.render.resolution_x = max(1, round(camera["resolucao_x"] * escala))
    cena.render.resolution_y = max(1, round(camera["resolucao_y"] * escala))
    cena.render.resolution_percentage = 100
    cena.render.pixel_aspect_x = 1.0
    cena.render.pixel_aspect_y = camera["anamorfose"]


def renderizar(cena: bpy.types.Scene, camera: bpy.types.Object, escala: float, pasta: str) -> np.ndarray:
    """A imagem de uma câmera, em linhas de baixo para cima como o Blender guarda, RGBA em float."""
    por_camera(cena, camera, escala)
    cena.render.filepath = os.path.join(pasta, f"{camera[VISOR.propriedade_da_superficie]}.png")
    bpy.ops.render.render(write_still=True, scene=cena.name)
    imagem = bpy.data.images.load(cena.render.filepath)
    try:
        largura, altura = imagem.size
        pixels = np.empty(largura * altura * 4, np.float32)
        imagem.pixels.foreach_get(pixels)
    finally:
        bpy.data.images.remove(imagem)
    pixels = pixels.reshape(altura, largura, 4)
    return pixels[:, ::-1] if camera["espelhar_no_visor"] else pixels


def atualizar(cena: bpy.types.Scene) -> bpy.types.Image:
    """Renderiza as cinco câmeras e monta a fita com o piso centrado embaixo. Devolve a cena como estava."""
    sala = sala_do_visor(cena)
    escala = cena.visor_da_sala.escala
    largura = round(sala["largura_da_fita"] * escala)
    altura_da_fita = round(sala["altura_da_fita"] * escala)
    cameras = cameras_da_sala(sala)
    piso = next(c for c in cameras if c[VISOR.propriedade_da_superficie] == VISOR.superficie_do_piso)
    altura_do_piso = round(piso["resolucao_y"] * escala)

    render = cena.render
    antes = (cena.camera, render.resolution_x, render.resolution_y, render.resolution_percentage,
             render.pixel_aspect_x, render.pixel_aspect_y, render.filepath, render.image_settings.file_format)
    quadro = np.zeros((altura_da_fita + altura_do_piso, largura, 4), np.float32)
    quadro[..., 3] = 1.0
    try:
        render.image_settings.file_format = "PNG"
        with tempfile.TemporaryDirectory(prefix="visor-da-sala-") as pasta:
            for camera in cameras:
                imagem = renderizar(cena, camera, escala, pasta)
                altura, largura_da_imagem = imagem.shape[:2]
                if camera is piso:
                    x = max(0, (largura - largura_da_imagem) // 2)
                    quadro[:altura, x:x + largura_da_imagem] = imagem[:, :largura - x]
                    continue
                x = round(camera["recorte_x"] * escala)
                fim = min(largura, x + largura_da_imagem)
                quadro[altura_do_piso:altura_do_piso + altura, x:fim] = imagem[:, :fim - x]
    finally:
        (cena.camera, render.resolution_x, render.resolution_y, render.resolution_percentage,
         render.pixel_aspect_x, render.pixel_aspect_y, render.filepath, render.image_settings.file_format) = antes

    imagem = bpy.data.images.get(VISOR.nome_da_imagem)
    if imagem is None or tuple(imagem.size) != (largura, quadro.shape[0]):
        if imagem is not None:
            bpy.data.images.remove(imagem)
        imagem = bpy.data.images.new(VISOR.nome_da_imagem, largura, quadro.shape[0], alpha=False)
    imagem.pixels.foreach_set(quadro.ravel())
    imagem.update()
    return imagem


def ponto_de_vista(sala: bpy.types.Object) -> bpy.types.Object:
    ponto = next((filho for filho in sala.children if filho.name.startswith(VISOR.ponto_de_vista)), None)
    if ponto is None:
        raise RuntimeError(f'A sala "{sala.name}" não tem o "{VISOR.ponto_de_vista}".')
    return ponto


def giro_de_frente_para(sala: bpy.types.Object, superficie: str) -> float:
    """O giro, em graus no espaço da sala, que põe o centro da superfície no meio da vista, a partir do olho."""
    camera = next(c for c in cameras_da_sala(sala) if c[VISOR.propriedade_da_superficie] == superficie)
    para_a_frente = camera.matrix_basis.to_3x3().col[2] * -1.0
    return math.degrees(math.atan2(-para_a_frente.x, para_a_frente.y))


def primeira_parede(sala: bpy.types.Object) -> str:
    return next(c[VISOR.propriedade_da_superficie] for c in cameras_da_sala(sala)
                if c[VISOR.propriedade_da_superficie] != VISOR.superficie_do_piso)


def olhar(cena: bpy.types.Scene) -> bpy.types.Object:
    """A câmera do olho, criada na primeira vez como objeto do arquivo do artista, na coleção da cena, presa ao ponto de
    vista da sala (que pode ser vinculado), e posta no giro, na inclinação e no campo do painel."""
    sala = sala_do_visor(cena)
    ponto = ponto_de_vista(sala)
    camera = next((filho for filho in ponto.children if filho.name.startswith(VISOR.nome_do_olhar)), None)
    if camera is None:
        camera = bpy.data.objects.new(VISOR.nome_do_olhar, bpy.data.cameras.new(VISOR.nome_do_olhar))
        camera.parent = ponto
        cena.collection.objects.link(camera)
        camera.data.sensor_fit = "VERTICAL"
        camera.data.clip_start = 0.05
        camera.data.clip_end = 500.0
        camera.hide_render = False
        cena.visor_da_sala["giro"] = giro_de_frente_para(sala, primeira_parede(sala))
    visor = cena.visor_da_sala
    camera.rotation_mode = "XYZ"
    camera.rotation_euler = (math.radians(90.0 + visor.inclinacao), 0.0, math.radians(visor.giro))
    camera.data.angle_y = math.radians(visor.campo)
    return camera


def _ao_mudar_o_olhar(_grupo: "VisorDaSala", contexto: bpy.types.Context) -> None:
    if not salas(contexto.scene) and contexto.scene.visor_da_sala.sala is None:
        return
    olhar(contexto.scene)


def _encaixar_imagem(janela: bpy.types.Window, area: bpy.types.Area) -> None:
    """A fita inteira à vista. Roda depois de a janela nova ser desenhada, quando a área já tem tamanho."""
    regiao = next(r for r in area.regions if r.type == "WINDOW")
    with bpy.context.temp_override(window=janela, area=area, region=regiao):
        bpy.ops.image.view_all(fit_view=True)
    return None


def mostrar(contexto: bpy.types.Context, imagem: bpy.types.Image) -> None:
    for area in contexto.screen.areas:
        if area.type == "IMAGE_EDITOR":
            area.spaces.active.image = imagem
            area.tag_redraw()


class VisorDaSala(bpy.types.PropertyGroup):
    escala: bpy.props.FloatProperty(name="Escala", description="Fração da resolução da sala em que o visor renderiza",
                                    default=VISOR.escala, min=0.05, max=1.0)
    acompanhar: bpy.props.BoolProperty(name="Acompanhar o quadro",
                                       description="Atualiza o visor quando o quadro muda (fora da reprodução)")
    sala: bpy.props.PointerProperty(name="Sala do visor", type=bpy.types.Object,
                                    poll=lambda _grupo, objeto: _e_sala(objeto),
                                    description="Vazio: a única sala da cena")
    giro: bpy.props.FloatProperty(name="Giro", description="Para onde o público olha, em graus no espaço da sala",
                                  default=0.0, min=-180.0, max=180.0, update=_ao_mudar_o_olhar)
    inclinacao: bpy.props.FloatProperty(name="Inclinação", description="Para cima (+) ou para o piso (-), em graus",
                                        default=0.0, min=-VISOR.inclinacao_maxima, max=VISOR.inclinacao_maxima,
                                        update=_ao_mudar_o_olhar)
    campo: bpy.props.FloatProperty(name="Campo de visão", description="Campo de visão vertical, em graus",
                                   default=VISOR.campo_padrao, min=VISOR.campo_minimo, max=VISOR.campo_maximo,
                                   update=_ao_mudar_o_olhar)


class SALA_OT_atualizar_visor(bpy.types.Operator):
    bl_idname = "sala.atualizar_visor"
    bl_label = "Atualizar visor"
    bl_description = "Renderiza as cinco câmeras da sala e monta a fita com o piso"

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        try:
            imagem = atualizar(contexto.scene)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}
        mostrar(contexto, imagem)
        return {"FINISHED"}


class SALA_OT_abrir_visor(bpy.types.Operator):
    bl_idname = "sala.abrir_visor"
    bl_label = "Abrir visor"
    bl_description = "Abre uma janela com o ponto de vista em cima, ao vivo, e a fita com o piso embaixo"

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        cena = contexto.scene
        try:
            imagem = bpy.data.images.get(VISOR.nome_da_imagem) or atualizar(cena)
            camera = olhar(cena)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}

        bpy.ops.wm.window_new()
        janela = contexto.window_manager.windows[-1]
        area = max(janela.screen.areas, key=lambda a: a.width * a.height)
        area.type = "VIEW_3D"
        antes = set(janela.screen.areas)
        with contexto.temp_override(window=janela, screen=janela.screen, area=area):
            bpy.ops.screen.area_split(direction="HORIZONTAL", factor=0.4)
        # A área de antes fica em cima, e a nova, com a fração pedida, embaixo.
        nova = next(a for a in janela.screen.areas if a not in antes)
        nova.type = "IMAGE_EDITOR"
        nova.spaces.active.image = imagem
        bpy.app.timers.register(lambda: _encaixar_imagem(janela, nova), first_interval=0.0)

        vista = area.spaces.active
        vista.use_local_camera = True
        vista.camera = camera
        vista.region_3d.view_perspective = "CAMERA"
        vista.shading.type = "MATERIAL"
        return {"FINISHED"}


class SALA_OT_olhar_pela_superficie(bpy.types.Operator):
    bl_idname = "sala.olhar_pela_superficie"
    bl_label = "Olhar pela superfície"
    bl_description = "Faz da câmera desta superfície a câmera da cena, com a resolução dela, e olha por ela"

    superficie: bpy.props.StringProperty()

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        try:
            sala = sala_do_visor(contexto.scene)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}
        camera = next((c for c in cameras_da_sala(sala) if c[VISOR.propriedade_da_superficie] == self.superficie), None)
        if camera is None:
            self.report({"ERROR"}, f'Sem câmera para "{self.superficie}".')
            return {"CANCELLED"}
        por_camera(contexto.scene, camera, 1.0)
        if contexto.space_data is not None and contexto.space_data.type == "VIEW_3D":
            contexto.space_data.region_3d.view_perspective = "CAMERA"
        return {"FINISHED"}


class SALA_OT_olhar_do_ponto_de_vista(bpy.types.Operator):
    bl_idname = "sala.olhar_do_ponto_de_vista"
    bl_label = "Olhar do ponto de vista"
    bl_description = "Põe a vista na câmera do olho do público, de frente para uma superfície"

    superficie: bpy.props.StringProperty(default="")

    def execute(self, contexto: bpy.types.Context) -> set[str]:
        cena = contexto.scene
        visor = cena.visor_da_sala
        try:
            sala = sala_do_visor(cena)
            if self.superficie == VISOR.superficie_do_piso:
                visor.inclinacao = -VISOR.inclinacao_do_piso
            elif self.superficie:
                visor.giro = giro_de_frente_para(sala, self.superficie)
                visor.inclinacao = 0.0
            camera = olhar(cena)
        except RuntimeError as erro:
            self.report({"ERROR"}, str(erro))
            return {"CANCELLED"}
        cena.camera = camera
        cena.render.pixel_aspect_x = cena.render.pixel_aspect_y = 1.0
        if contexto.space_data is not None and contexto.space_data.type == "VIEW_3D":
            contexto.space_data.region_3d.view_perspective = "CAMERA"
        return {"FINISHED"}


class SALA_PT_visor(bpy.types.Panel):
    bl_label = "Visor da sala"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Sala"

    def draw(self, contexto: bpy.types.Context) -> None:
        layout = self.layout
        visor = contexto.scene.visor_da_sala
        if len(salas(contexto.scene)) > 1:
            layout.prop(visor, "sala")
        layout.prop(visor, "escala")
        layout.prop(visor, "acompanhar")
        linha = layout.row(align=True)
        linha.operator(SALA_OT_atualizar_visor.bl_idname, icon="RENDER_STILL")
        linha.operator(SALA_OT_abrir_visor.bl_idname, icon="WINDOW")
        try:
            cameras = cameras_da_sala(sala_do_visor(contexto.scene))
        except RuntimeError as erro:
            layout.label(text=str(erro), icon="ERROR")
            return
        coluna = layout.column(align=True)
        coluna.label(text="Olhar pela superfície")
        for camera in cameras:
            nome = camera[VISOR.propriedade_da_superficie]
            coluna.operator(SALA_OT_olhar_pela_superficie.bl_idname, text=nome).superficie = nome

        caixa = layout.box()
        caixa.operator(SALA_OT_olhar_do_ponto_de_vista.bl_idname, icon="HIDE_OFF").superficie = ""
        linha = caixa.row(align=True)
        linha.label(text="Encarar")
        for camera in cameras:
            nome = camera[VISOR.propriedade_da_superficie]
            rotulo = "piso" if nome == VISOR.superficie_do_piso else nome.split()[-1]
            linha.operator(SALA_OT_olhar_do_ponto_de_vista.bl_idname, text=rotulo).superficie = nome
        caixa.prop(visor, "giro")
        caixa.prop(visor, "inclinacao")
        caixa.prop(visor, "campo")


class SALA_PT_visor_na_imagem(bpy.types.Panel):
    bl_label = "Visor da sala"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Sala"

    def draw(self, contexto: bpy.types.Context) -> None:
        self.layout.prop(contexto.scene.visor_da_sala, "acompanhar")
        self.layout.operator(SALA_OT_atualizar_visor.bl_idname, icon="RENDER_STILL")


def _atualizar_depois() -> None:
    if bpy.context.screen is not None and bpy.context.screen.is_animation_playing:
        return None
    try:
        imagem = atualizar(bpy.context.scene)
    except RuntimeError as erro:
        print(f"Visor da sala: {erro}")
        return None
    for janela in bpy.context.window_manager.windows:
        for area in janela.screen.areas:
            if area.type == "IMAGE_EDITOR" and area.spaces.active.image == imagem:
                area.tag_redraw()
    return None


@bpy.app.handlers.persistent
def ao_mudar_o_quadro(cena: bpy.types.Scene, _grafo: object = None) -> None:
    if bpy.app.background or not cena.visor_da_sala.acompanhar:
        return
    if bpy.app.timers.is_registered(_atualizar_depois):
        bpy.app.timers.unregister(_atualizar_depois)
    bpy.app.timers.register(_atualizar_depois, first_interval=VISOR.atraso_s)


CLASSES = (VisorDaSala, SALA_OT_atualizar_visor, SALA_OT_abrir_visor, SALA_OT_olhar_pela_superficie,
           SALA_OT_olhar_do_ponto_de_vista, SALA_PT_visor, SALA_PT_visor_na_imagem)


def register() -> None:
    for classe in CLASSES:
        bpy.utils.register_class(classe)
    bpy.types.Scene.visor_da_sala = bpy.props.PointerProperty(type=VisorDaSala)
    bpy.app.handlers.frame_change_post.append(ao_mudar_o_quadro)


def unregister() -> None:
    bpy.app.handlers.frame_change_post.remove(ao_mudar_o_quadro)
    if bpy.app.timers.is_registered(_atualizar_depois):
        bpy.app.timers.unregister(_atualizar_depois)
    del bpy.types.Scene.visor_da_sala
    for classe in reversed(CLASSES):
        bpy.utils.unregister_class(classe)
